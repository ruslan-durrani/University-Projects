package com.RDs.Database;

import java.sql.ResultSet;
import java.sql.SQLException;


public class AdministrationArea extends Database{
    public String username;
    String password;
    public String first_name;
    public String last_name;
    public String role;
    public static String adminID;

    public AdministrationArea(String roll_num, String password) throws SQLException {
        super();
        this.username = roll_num+"";
        this.password = password;
    }
    public boolean validate() throws SQLException {
        String validationQuery = "SELECT * FROM admin";
        ResultSet rs = stmt.executeQuery(validationQuery);
        while (rs.next()){
            String id  = rs.getString("admin_id");
            String pass = rs.getString("admin_password");
            if(id.equals(username) && pass.equals(password)){
                adminID = username;
                return true;
            }
        }
        return false;
    }

}

package com.RDs.Portal_logic;


import com.RDs.Database.AdministrationArea;

import java.sql.SQLException;

public class Administration extends AdministrationArea {
    String user_name;
    String password;


    public Administration(String _user_name, String _password) throws SQLException {
        super(_user_name, _password);
        this.user_name = _user_name;
        this.password = _password;
    }

    public String getFirstName() {
        return super.first_name;
    }

    public String getLastName() {
        return super.last_name;
    }

    public String getRole() {
        return super.role;
    }

}

class Gymnast {
  final title;
  final age;
  final day;
  final month;
  final year;
  final address;
  final amountPaid;
  final contactNumber;
  Gymnast({
    required this.title,
    required this.age,
    required this.address,
    required this.day,
    required this.month,
    required this.year,
    required this.amountPaid,
    required this.contactNumber,
  });
  getTitle() {
    return this.title;
  }

  getContactNumber() {
    return this.contactNumber;
  }

  getAge() {
    return this.age;
  }

  getAddress() {
    return this.address;
  }

  getDateOfJoining() {
    return this.day;
  }

  isPending() {
    var now = DateTime.now();
    var joined = DateTime(this.year, this.month, this.day);
    Duration diff = now.difference(joined);
    if ((diff.inDays < 30)) {
      return false;
    } else {
      return true;
    }
  }

  getStatus() {
    return isPending() ? "Pending" : "Paid";
  }

  getJoiningDateTime() {
    return this.day + "/" + this.month + "/" + this.year;
  }
}

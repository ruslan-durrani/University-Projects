import 'package:action_slider/action_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get.dart';
import 'home.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(color: Colors.black),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "Your Ultimate Gym Partner",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 45,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Poppins",
                    color: Colors.white),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("./assets/images/gym_splash.png"),
                        fit: BoxFit.contain)),
              ),
              ActionSlider.standard(
                sliderBehavior: SliderBehavior.stretch,
                width: 300.0,
                child: const Text(
                  'Track Boys',
                  style: TextStyle(fontSize: 15),
                ),
                backgroundColor: Colors.white.withOpacity(.5),
                toggleColor: Colors.yellow,
                action: (controller) async {
                  controller.loading(); //starts loading animation
                  await Future.delayed(const Duration(seconds: 1));
                  controller.success(); //starts success animation
                  Get.to(Home());
                  // await Future.delayed(const Duration(seconds: 1));
                  // controller.reset(); //resets the slider
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

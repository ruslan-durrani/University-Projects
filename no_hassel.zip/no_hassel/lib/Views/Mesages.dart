import 'package:flutter/material.dart';
import 'package:no_hassel/Models/dyslexia.dart';
import 'package:no_hassel/Views/MyNavBar.dart';
import 'package:no_hassel/Views/home.dart';

import 'chatScreen.dart';

class Messages extends StatefulWidget {
  const Messages({super.key});

  @override
  _MessagesState createState() => _MessagesState();
}

class _MessagesState extends State<Messages> {
  final List<Friend> friendList = [
    Friend(
      'John',
      'Hello!',
      DateTime.now(),
    ),
    Friend('Alice', 'Hi there!', DateTime.now().subtract(Duration(hours: 2))),
    Friend('Mike', 'How are you?', DateTime.now().subtract(Duration(hours: 5))),
    Friend('Sarah', 'Long time no see!',
        DateTime.now().subtract(Duration(days: 1))),
  ];

  late List<Friend> filteredList;
  String filter = 'All';

  @override
  void initState() {
    super.initState();
    filteredList = friendList;
  }

  void _filterList(String value) {
    setState(() {
      filter = value;
      if (value == 'All') {
        filteredList = friendList;
      } else if (value == 'Recents') {
        filteredList = friendList
            .where((friend) => friend.timestamp
                .isAfter(DateTime.now().subtract(Duration(days: 7))))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: Text('Messages'),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                // Implement search logic here
                // You can filter the friendList based on the search value
              },
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 10, right: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      _filterList('All');
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color:
                            filter == 'All' ? Colors.deepOrange : Colors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: Colors.deepOrange, // Border color
                          width: 2.0, // Border width
                        ),
                      ),
                      child: Text(
                        'All',
                        style: TextStyle(
                          fontWeight:
                              Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                          color: filter == 'All'
                              ? Colors.white
                              : Colors.deepOrange,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      _filterList('Recents');
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: filter == 'Recents'
                            ? Colors.deepOrange
                            : Colors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: Colors.red, // Border color
                          width: 2.0, // Border width
                        ),
                      ),
                      child: Text(
                        'Recents',
                        style: TextStyle(
                          fontWeight:
                              Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                          color: filter == 'Recents'
                              ? Colors.white
                              : Colors.deepOrange,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredList.length,
              itemBuilder: (context, index) {
                return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.purple,
                      child: Text(
                        filteredList[index].name[0],
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      filteredList[index].name,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      filteredList[index].message,
                      style: TextStyle(
                        fontWeight:
                            Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                        color: Colors.grey[600],
                      ),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          _formatTimestamp(filteredList[index].timestamp),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: Dyslexia.on
                                ? FontWeight.bold
                                : FontWeight.normal,
                            color: Colors.grey[600],
                          ),
                        ),
                        SizedBox(height: 4),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                          color: Colors.grey[600],
                        ),
                      ],
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) {
                            print("object");
                            return const ChatScreen();
                          },
                        ),
                      );
                    });
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          height: 56.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              InkWell(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        print("object");
                        return MyNavBar();
                      },
                    ),
                  );
                },
                child: Row(
                  children: [
                    Icon(
                      Icons.home,
                      color: Colors.black,
                      weight: Dyslexia.on ? 15 : 10,
                    ),
                    Text(
                      'Home',
                      style: TextStyle(
                          fontWeight:
                              Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                          color: Colors.black),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    if (now.difference(timestamp).inDays == 0) {
      return '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';
    } else {
      return '${timestamp.day.toString().padLeft(2, '0')}/${timestamp.month.toString().padLeft(2, '0')}';
    }
  }
}

class Friend {
  final String name;
  final String message;
  final DateTime timestamp;

  Friend(this.name, this.message, this.timestamp);
}

package com.RDs.FrontEnd.Student;

import com.RDs.FrontEnd.StudentBackend;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.studentLogin;

public class StudentRegistration extends JPanel {

    JPanel jPanel, jPanelButton;
    JLabel jLabelSignUp;

    JTextField jTextFieldFirstName, jTextFieldLastName, jTextFieldRegistrationNumber;
    JPasswordField jPasswordFieldPassword;
    JSpinner jSpinnerDepartmentName, jSpinnerSemester, jSpinnerProgram;

    JButton jButtonBack, jButtonSubmit, jButtonClearAll;

    StudentBackend studentBackend;

    {
        try {
            studentBackend = new StudentBackend();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public StudentRegistration() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000,800);


        jLabelSignUp = new JLabel("Registration Form!");

        add(jLabelSignUp);

        jLabelSignUp.setFont(new Font("Monotype Sort", Font.BOLD,32));
        jLabelSignUp.setForeground(Color.WHITE);
        jLabelSignUp.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createRigidArea(new Dimension(0,10)));


        jTextFieldFirstName = new JTextField("Enter First Name");
        add(jTextFieldFirstName);
        jTextFieldFirstName.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldFirstName.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldFirstName.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldFirstName.setMaximumSize(new Dimension(900,45));

        add(Box.createRigidArea(new Dimension(0,20)));

        jTextFieldLastName = new JTextField("Enter Last Name");
        add(jTextFieldLastName);
        jTextFieldLastName.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldLastName.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldLastName.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldLastName.setMaximumSize(new Dimension(900,45));

        add(Box.createRigidArea(new Dimension(0,20)));

        jTextFieldRegistrationNumber = new JTextField("Enter Registration Number");
        add(jTextFieldRegistrationNumber);
        jTextFieldRegistrationNumber.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldRegistrationNumber.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldRegistrationNumber.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldRegistrationNumber.setMaximumSize(new Dimension(900,45));

        add(Box.createRigidArea(new Dimension(0,20)));

        jPasswordFieldPassword = new JPasswordField("Enter Password");
        add(jPasswordFieldPassword);
        jPasswordFieldPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPasswordFieldPassword.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jPasswordFieldPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPasswordFieldPassword.setMaximumSize(new Dimension(900,45));
        add(Box.createRigidArea(new Dimension(0,20)));


        JTextField jTextFieldEmailAddress = new JTextField("Enter Email Address");
        add(jTextFieldEmailAddress);
        jTextFieldEmailAddress.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldEmailAddress.setFont(new Font("Monotype Sort", Font.BOLD, 13));
        jTextFieldEmailAddress.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldEmailAddress.setMaximumSize(new Dimension(900, 45));
        add(Box.createRigidArea(new Dimension(0, 20)));

        jPanel = new JPanel();
        add(jPanel);
        jPanel.setLayout(new BoxLayout(jPanel,BoxLayout.X_AXIS));
        jPanel.setBackground(new Color(0xFF6200));

        String[] departmentArray = new String[0];
        String[] program = new String[0];
        try {
            departmentArray = new StudentBackend().getDepartment();
            for(int i=0; i<departmentArray.length; i++) System.out.println(departmentArray[i]);
//            program = new StudentBackend().getProgramName();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String[] semester = {"Select Semester", "1", "2", "3", "4", "5","6","7","8","9","10","11","12"};

        jSpinnerDepartmentName = new JSpinner(new SpinnerListModel(departmentArray));
        jPanel.add(jSpinnerDepartmentName);
        jSpinnerDepartmentName.setMinimumSize(new Dimension(440,45));
        jSpinnerDepartmentName.setMaximumSize(new Dimension(440,45));

        jPanel.add(Box.createRigidArea(new Dimension(10,0)));

        JButton jButtonOk = new JButton("OK");
        jPanel.add(jButtonOk);
        jButtonOk.setMinimumSize(new Dimension(45,45));
        jButtonOk.setBackground(Color.WHITE);
        jButtonOk.setBorderPainted(false);
        jButtonOk.setForeground(Color.GRAY);
        jButtonOk.setFocusable(false);


        jPanel.add(Box.createRigidArea(new Dimension(10,0)));

        jSpinnerProgram = new JSpinner();
        jPanel.add(jSpinnerProgram);
        jSpinnerProgram.setMinimumSize(new Dimension(440,45));
        jSpinnerProgram.setMaximumSize(new Dimension(440,45));
        jSpinnerProgram.setVisible(false);

        add(Box.createRigidArea(new Dimension(0,20)));

        jSpinnerSemester = new JSpinner(new SpinnerListModel(semester));
        jSpinnerSemester.setMaximumSize(new Dimension(600,45));
        add(jSpinnerSemester);

        add(Box.createRigidArea(new Dimension(0,20)));


        jPanelButton = new JPanel();
        add(jPanelButton);
        jPanelButton.setBackground(new Color(0xFF6200));
        jPanelButton.setLayout(new BoxLayout(jPanelButton,BoxLayout.X_AXIS));
        jPanelButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        jButtonBack = new JButton("Back");
        jButtonBack.setFocusable(false);
        jPanelButton.add(jButtonBack);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setBorderPainted(false);
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(440,45));
        jButtonBack.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jPanelButton.add(Box.createRigidArea(new Dimension(20,0)));

        jButtonSubmit = new JButton("Submit");
        jButtonSubmit.setFocusable(false);
        jPanelButton.add(jButtonSubmit);
        jButtonSubmit.setBackground(Color.WHITE);
        jButtonSubmit.setBorderPainted(false);
        jButtonSubmit.setForeground(Color.GRAY);
        jButtonSubmit.setMaximumSize(new Dimension(440,45));
        jButtonSubmit.setFont(new Font("Monotype Sort",Font.BOLD,14));
        jButtonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonClearAll = new JButton("Clear All");
        jButtonClearAll.setFocusable(false);
        add(jButtonClearAll);
        jButtonClearAll.setBackground(Color.WHITE);
        jButtonClearAll.setBorderPainted(false);
        jButtonClearAll.setForeground(Color.GRAY);
        jButtonClearAll.setMaximumSize(new Dimension(900,45));
        jButtonClearAll.setFont(new Font("Monotype Sort",Font.BOLD,14));
        jButtonClearAll.setAlignmentX(Component.CENTER_ALIGNMENT);

        jButtonBack.addActionListener(e-> {
            setVisible(false);
            studentLogin.setVisible(true);
        });


        jButtonClearAll.addActionListener(e-> {
            jTextFieldFirstName.setText("Enter First Name");
            jTextFieldLastName.setText("Enter Last Name");
            jTextFieldRegistrationNumber.setText("Enter Registration Number");
            jPasswordFieldPassword.setText("Enter Password");
            jSpinnerSemester.setValue("Select Semester");
            jSpinnerProgram.setValue("Select Program");
            jSpinnerDepartmentName.setValue("Select Department");


        });

        jButtonOk.addActionListener(e-> {
            jSpinnerProgram.setVisible(true);
            jSpinnerProgram.setModel(new SpinnerListModel(studentBackend.retrievePrograms(String.valueOf(jSpinnerDepartmentName.getValue()))));
        });

        add(Box.createRigidArea(new Dimension(0,10)));

        jButtonSubmit.addActionListener(e-> {

            String firstName = jTextFieldFirstName.getText();
            String lastName = jTextFieldLastName.getText();
            String regNumber = jTextFieldRegistrationNumber.getText();
            String programName = String.valueOf(jSpinnerProgram.getValue());
            String departmentName = String.valueOf(jSpinnerDepartmentName.getValue());
            String semester_ = String.valueOf(jSpinnerSemester.getValue());
            String password = String.valueOf(jPasswordFieldPassword.getPassword());

            if (!firstName.isEmpty() && !lastName.isEmpty() && !regNumber.isEmpty() && !programName.isEmpty() && !departmentName.isEmpty() && !semester_.isEmpty()) {

                studentBackend.studentRegistration(firstName,lastName,regNumber,departmentName,programName,semester_,password, jTextFieldEmailAddress.getText());



            }




        });







    }
}

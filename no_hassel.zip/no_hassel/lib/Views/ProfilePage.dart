import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:no_hassel/Models/dyslexia.dart';

import 'Mesages.dart';
import 'SightSaver.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: Text(
          'Profile',
          style: TextStyle(
              fontSize: 18,
              fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  CircleAvatar(
                    radius: 64.0,
                    backgroundImage: AssetImage(
                        '/Users/russi7kd/StudioProjects/no_hassel/assets/img/Dr_Madni.jpg'), // Replace with your avatar image
                  ),
                  IconButton(
                    icon: Icon(Icons.camera_alt),
                    onPressed: () {
                      // Handle camera icon button press
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Username',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Enter your username',
                labelText: 'Dr Tahir Mustafa Madni',
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Email',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Enter your email address',
                labelText: 'doctortahirmustafa@gmail.com',
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Address',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Enter your address',
                labelText: 'Islamabad, Paksitan',
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Bio',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Enter your bio',
                labelText:
                    'Assistant Professor at CS Dept. COMSATS University Islamabad with 10+ years of expertise. His research has focused upon the area of human computer interaction, and multimodal interfaces.',
              ),
              maxLines: 3,
            ),
          ],
        ),
      ),
      floatingActionButton: SpeedDial(
        backgroundColor: Colors.purpleAccent,
        foregroundColor: Colors.white,
        animatedIcon: AnimatedIcons.menu_close,
        children: [
          SpeedDialChild(
            child: Icon(Icons.view_list_outlined),
            label: 'Screen Reader',
            onTap: () {
              // Handle Email icon press
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.chat),
            label: 'Chat',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Messages(),
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.share_arrival_time_outlined),
            label: 'Read Aloud',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.insights),
            label: 'Sight Saver',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

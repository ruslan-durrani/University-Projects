class OptionCard {
  final icon;
  final title;
  final color;
  final action;
  OptionCard({
    required this.icon,
    required this.title,
    required this.color,
    required this.action,
  });
}

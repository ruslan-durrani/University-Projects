package junaid.gui;

import javax.swing.*;
import java.awt.*;

public class MainPagePanel extends JPanel {
    public MainPagePanel() {
        setVisible(true);
        setSize(500,500);
        setBackground(Color.black);
    }
}

import 'package:flutter/material.dart';
import 'package:no_hassel/Models/dyslexia.dart';
import 'package:no_hassel/Views/home.dart';
import 'package:no_hassel/Views/recents.dart';

import 'ProfilePage.dart';
import 'favourites.dart';

class MyNavBar extends StatefulWidget {
  @override
  _MyNavBarState createState() => _MyNavBarState();
}

class _MyNavBarState extends State<MyNavBar> {
  int _currentIndex = 0;

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _getBodyWidget(_currentIndex),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor:
            Colors.deepOrange, // Customize the selected item color
        unselectedItemColor: Dyslexia.on ? Colors.black : Colors.grey,
        unselectedLabelStyle: TextStyle(color: Colors.black),
        onTap: _onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favourites',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work_history_rounded),
            label: 'Recents',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _getBodyWidget(int index) {
    switch (index) {
      case 0:
        return Home();
      case 1:
        return Favourites();
      case 2:
        return Recents();
      case 3:
        return ProfilePage();
      default:
        return Container();
    }
  }
}

# Python-Project
Python Basic Projects
These are my first python projects 

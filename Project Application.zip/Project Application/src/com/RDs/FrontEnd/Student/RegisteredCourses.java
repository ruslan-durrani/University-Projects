package com.RDs.FrontEnd.Student;

import com.RDs.FrontEnd.Faculty;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.facultyHomePage;
import static com.RDs.FrontEnd.SplashScreen.studentHomePage;

public class RegisteredCourses extends JPanel {

    public static JTable jTableDetails;
    JButton jButtonBack;


    public RegisteredCourses() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0, 100)));

        jButtonBack = new JButton("BACK");
        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(180, 45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);

        add(jButtonBack);

        add(Box.createRigidArea(new Dimension(0,20)));


        jTableDetails = new JTable();

        jTableDetails = new JTable();

        add(jTableDetails);

        jTableDetails.getTableHeader().setReorderingAllowed(false);

        String[] detailColumn = new String[]{"Program Name","Course Name", "Semester","Faculty Name", "Faculty ID"};

        jTableDetails.setModel(new DefaultTableModel(new String[][]{}, detailColumn));

        JScrollPane scrollPaneNoticeboard = new JScrollPane(jTableDetails,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPaneNoticeboard.setMaximumSize(new Dimension(1000, 400));
        scrollPaneNoticeboard.setBackground(new Color(0, 0, 0, 65));

        add(scrollPaneNoticeboard);


        jButtonBack.addActionListener(e-> {
            setVisible(false);
            studentHomePage.setVisible(true);
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/FacultyPortal/facultyPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }

}

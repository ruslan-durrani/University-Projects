package com.example.no_hassel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com;//package com;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;


interface SpectatorPanel {

    boolean buyTicket(String chooseId,String stadium, String sportsDepartment, String userName) throws Exception;
    boolean deleteSpectatorTicket(String username, String stadium, String sportsDepartment) throws Exception;

}

public class Spectator implements SpectatorPanel {
    private File file;
    private String id;

    public Spectator() {

    }

    public boolean buyTicket(String chooseId, String stadium, String sportsDepartment, String userName) throws Exception {

        this.id = chooseId;

        try {
            file = new File("Spectator" + "/" + stadium + "/" + sportsDepartment + "/" + userName + ".txt");
        } catch (Exception e) {
            System.out.println("ERROR");
        }

        if (file.isFile()) {
            System.out.println("File Exists");
            return false;
        }
        else {
            Admin admin = new Admin();
            admin.showTicketData(stadium, sportsDepartment);

            for (int i = 0; i < Admin.ticketDataArray.size(); i++) {
                if ((i + 1) == Integer.parseInt(chooseId)) {
                    file = new File("Spectator" + "/" + stadium + "/" + sportsDepartment);
                    file.mkdirs();
                    FileOutputStream fos = new FileOutputStream(file.getAbsolutePath() + "/" + userName + ".txt",true);
                    fos.write((Admin.ticketDataArray.get(i)).getBytes() );
                    fos.close();
                    break;
                }

            }
            return true;
        }
    }

    public boolean checkMaxId(String id) {
        return Integer.parseInt(id) > Admin.ticketDataArray.size();
    }




    public boolean deleteSpectatorTicket( String stadium, String sportsDepartment, String username) throws FileNotFoundException {
        File file = new File("Spectator" + "/" + stadium + "/" + sportsDepartment + "/" + username + ".txt");
        if (file.exists()) {
            file.delete();
            return true;
        } else {
            return false;
        }
    }

}

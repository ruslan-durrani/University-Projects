
USE Virtual_Portal;
INSERT INTO Courses(
	courseName,
    courseID
)VALUES 
-- CS SEM 1
('Introduction to ICT','Course-CS-1'),
('English Comprehension & Composition','Course-CS-1'),
('Islamic Studies','Course-CS-1'),
('Calculus & Analytics Geometery','Course-CS-1'),
('Applied Physics for Engineers','Course-CS-1'),
-- CS SEM 2
('Programming Fundamentals','Course-CS-2'),
('Report Writing Skills','Course-CS-2'),
('Multivaribale Calculus','Course-CS-2'),
('Professional Practices for IT','Course-CS-2'),
('Discrete Structures','Course-CS-2'),
-- CS SEM 3
('Object Oriented Programming','Course-CS-3'),
('Digital Logic DEsign','Course-CS-3'),
('Statistics & Probability Theory','Course-CS-3'),
('Linear Algebra','Course-CS-3'),
-- CS SEM 4
('Data Structures & Algorithms','Course-CS-4'),
('Computer Architecture','Course-CS-4'),
('Software Enginnering Concepts','Course-CS-4'),
('Differential Equations','Course-CS-4'),
('Communication skills','Course-CS-4'),
-- CS SEM 5
('Theory of Automata','Course-CS-5'),
('Design & Analysis of Algorithms','Course-CS-5'),
('Operating Systems','Course-CS-5'),
('Database Systems I','Course-CS-5'),
('Computer Science Elective I','Course-CS-5'),
-- CS SEM 6
('Microprocess & Assembly Language','Course-CS-6'),
('Data communications and Computer Networks','Course-CS-6'),
('Human Computer Interaction','Course-CS-6'),
('Web Technologies','Course-CS-6'),
('Pakistan Studies','Course-CS-6'),
('Computer Science Elective II','Course-CS-6'),
-- CS SEM 7
('Compiler Contruction','Course-CS-7'),
('Artificial Intelligence','Course-CS-7'),
('Numerical Computing','Course-CS-7'),
('Senior Design Project I','Course-CS-7'),
('Computer Science Elective III','Course-CS-7'),
('Insitutional Elective I','Course-CS-7'),
-- CS SEM 8
('Compiler Contruction','Course-CS-8'),
('Numerical Computing','Course-CS-8'),
('Senior Design Project I','Course-CS-8'),
('Computer Science Elective IV','Course-CS-8'),
('Computer Science Elective V','Course-CS-8'),
('Insitutional Elective I','Course-CS-8'),



-- SE SEM 1
('Introduction to ICT','Course-SE-1'),
('English Comprehension & Composition','Course-SE-1'),
('Islamic Studies','Course-SE-1'),
('Fundamentals of Computer Programming','Course-SE-1'),
('Circuits & Electronics','Course-SE-1'),
-- SE SEM 2
('Discrete Structures','Course-SE-2'),
('Report Writing Skills','Course-SE-2'),
('Calculus & Analytic Geometry','Course-SE-2'),
('Programming Fundamentals','Course-SE-2'),
-- SE SEM 3
('Object Oriented Programming','Course-SE-3'),
('Digital Logic DEsign','Course-SE-3'),
('Data Structures & Algorithms','Course-SE-3'),
('Communication Skills','Course-SE-3'),
('Introduction to Software Engineering','Course-SE-3'),
-- SE SEM 4
('Statistics & Probability Theory','Course-SE-4'),
('Introduction to Management','Course-SE-4'),
('Object Software Enginnering Concepts','Course-SE-4'),
('Database Systems','Course-SE-4'),
('Operating Systems','Course-SE-4'),
-- SE SEM 5
('Software Requirement Engineering','Course-SE-5'),
('Computer Communications & Networks','Course-SE-5'),
('Software Engineering Elective I','Course-SE-5'),
('GE Elective I','Course-SE-5'),
-- SE SEM 6
('Software Quality Engineering','Course-SE-6'),
('Software Design & Architecture','Course-SE-6'),
('Formal Methods in Software Engineering','Course-SE-6'),
('GE Elective II','Course-SE-6'),
('Professional Practices for IT','Course-SE-6'),
('SE Domain Elective I','Course-SE-6'),
-- SE SEM 7
('Proect','Course-SE-7'),
('Human Computer Interaction','Course-SE-7'),
('SE Domain Elective II','Course-SE-7'),
('Design Patterns','Course-SE-7'),
('SE Elective II','Course-SE-7'),
('Software Project Management','Course-SE-7'),
-- SE SEM 8
('Project','Course-SE-8'),
('Software Testing','Course-SE-8'),
('SE Elective III','Course-SE-8'),




-- BA SEM 1
('Introduction to Computing','Course-BA-1'),
('Macro Economics','Course-BA-1'),
('Business Mathematics I','Course-BA-1'),
('Introduction to Business','Course-BA-1'),
-- BA SEM 2
('Pakistan Studies','Course-BA-2'),
('Islamic Studies','Course-BA-2'),
('Business Mathematics II','Course-BA-2'),
('Accounting I','Course-BA-2'),
-- BA SEM 3
('Human Resource Management','Course-BA-3'),
('Financial Management','Course-BA-3'),
('Business Finance','Course-BA-3'),
('Introduction to Management','Course-BA-3'),
-- BA SEM 4
('Accounting II','Course-BA-4'),
('Organizational Behavior','Course-BA-4'),
('Research Tools and Techniques','Course-BA-4'),
('Productions and Operations Management','Course-BA-4'),
-- BA SEM 5
('Organizational Behavior','Course-BA-5'),
('Research Tools and Techniques','Course-BA-5'),
('Productions and Operations Management','Course-BA-5'),
('Human Resource Management','Course-BA-5'),
-- BA SEM 6
('Entrepreneurship','Course-BA-6'),
('Project Management','Course-BA-6'),
('Marketing Management','Course-BA-6'),
('Statistical Inference','Course-BA-6'),
('Strategic Management','Course-BA-6'),
-- BA SEM 7
('Productions and Operations Management','Course-BA-7'),
('Marketing Management','Course-BA-7'),
('Corporate Law','Course-BA-7'),
('Business Communication Workshop','Course-BA-7'),
-- BA SEM 8
('Project','Course-BA-8'),
('Project Management','Course-BA-8'),


-- DESIGN SEM 1
('Foundation Studio I','Course-DESIGN-1'),
('Design and Presentation I','Course-DESIGN-1'),
('Social and Cultural Studies','Course-DESIGN-1'),
('Proportions and Geometry in ART','Course-DESIGN-1'),
-- DESIGN SEM 2
('Foundation Studio II','Course-DESIGN-2'),
('Design and Presentation II','Course-DESIGN-2'),
('Islamic Studies','Course-DESIGN-2'),
('Design for Community','Course-DESIGN-2'),
('History of Philosophy of Arts and Culture II','Course-DESIGN-2'),
-- DESIGN SEM 3
('Art Appreciation','Course-DESIGN-3'),
('Design Technologies I','Course-DESIGN-3'),
('Design Technologies III','Course-DESIGN-3'),
('English Comprehension and Composition','Course-DESIGN-3'),
('Pakistan Studies','Course-DESIGN-3'),
-- DESIGN SEM 4
('Digital Drawing and Graphics I','Course-DESIGN-4'),
('Design Technologies II','Course-DESIGN-4'),
('Design Technologies IV','Course-DESIGN-4'),
-- DESIGN SEM 5
('Digital Drawing and Graphics II','Course-DESIGN-5'),
('History of Design I','Course-DESIGN-5'),
('Internship','Course-DESIGN-5'),
-- DESIGN SEM 6
('Proportions and Geometry in ART','Course-DESIGN-6'),
('History of Design II','Course-DESIGN-6'),
-- DESIGN SEM 7
('History of Philosophy of Arts and Culture I','Course-DESIGN-7'),
('Design and Presentation III','Course-DESIGN-7'),
('Thesis (Part I)','Course-DESIGN-7'),
-- DESIGN SEM 8
('History of Philosophy of Arts and Culture II','Course-DESIGN-8'),
('Design and Presentation IV','Course-DESIGN-8'),
('Design Technologies V','Course-DESIGN-5'),


-- ARCHI SEM 1
('History and Theory of Art and Culture I','Course-ARCHI-1'),
('Environment and Energy I','Course-ARCHI-1'),
('Structures for Architects I','Course-ARCHI-1'),
-- ARCHI SEM 2
('History and Theory of Art and Culture II','Course-ARCHI-2'),
('Material and Construction I','Course-ARCHI-2'),
('Environment and Energy II','Course-ARCHI-2'),
('Structures for Architects II','Course-ARCHI-2'),
('Digital Tools for Architects II','Course-ARCHI-2'),
-- ARCHI SEM 3
('Foundation Studio I','Course-ARCHI-3'),
('Architectural Studio I','Course-ARCHI-3'),
('Material and Construction II','Course-ARCHI-3'),
('Architectural Studio III','Course-ARCHI-3'),
('Digital Tools for Architects III','Course-ARCHI-3'),
-- ARCHI SEM 4
('Foundation Studio II','Course-ARCHI-4'),
('Architectural Studio II','Course-ARCHI-4'),
('Architectural Studio IV','Course-ARCHI-4'),
-- ARCHI SEM 5
('Visual Communication I','Course-ARCHI-5'),
('Building Services and System I','Course-ARCHI-5'),
('Sustainable Design I','Course-ARCHI-5'),
-- ARCHI SEM 6
('Visual Communication II','Course-ARCHI-6'),
('Building Services and System II','Course-ARCHI-6'),
('Sustainable Design II','Course-ARCHI-6'),
-- ARCHI SEM 7
('Communication Techniques and Critical Writing','Course-ARCHI-7'),
('Architectural Studio V','Course-ARCHI-7'),
('History and Theory of Architecture V','Course-ARCHI-7'),
('Thesis Design I','Course-ARCHI-7'),
-- ARCHI SEM 8
('Urban Design Studio','Course-ARCHI-8'),
('History and Theory of Urban Design','Course-ARCHI-8'),
('Thesis Design II','Course-ARCHI-8'),
('Professional Practice','Course-ARCHI-8'),

-- PHY SEM 1
('Mechanics','Course-PHY-1'),
('Experiments in Modern Physics','Course-PHY-1'),
('Fundamentals of Biology','Course-PHY-1'),
('Economics','Course-PHY-1'),
('Solid State Physics I','Course-PHY-1'),
-- PHY SEM 2
('Experiments in Thermodynamics, Electricity and Magnetism','Course-PHY-2'),
('Electric and Magnetic Fields','Course-PHY-2'),
('Circuit Theory','Course-PHY-2'),
('Introduction to Modern Physics','Course-PHY-2'),
('Mathematical Methods in Physics','Course-PHY-2'),
-- PHY SEM 3
('Waves and Oscillations','Course-PHY-3'),
('Electronics','Course-PHY-3'),
('Atomic and Molecular Physics','Course-PHY-3'),
('Introduction to Physical Chemistry','Course-PHY-3'),
('Introduction to Biosciences','Course-PHY-3'),
-- PHY SEM 4
('Project I','Course-PHY-4'),
('Optics','Course-PHY-4'),
('Boundary Value Problems in Physics','Course-PHY-4'),
('Electromagnetic Theory I','Course-PHY-4'),
('Introduction to Management','Course-PHY-4'),
-- PHY SEM 5
('Solid State Physics II','Course-PHY-5'),
('Electromagnetic Theory II','Course-PHY-5'),
('Meteorology','Course-PHY-5'),
('Introduction to Business','Course-PHY-5'),
-- PHY SEM 6
('Statistical Physics II','Course-PHY-6'),
('Introduction to Sociology','Course-PHY-6'),
('Computational Methods in Physics','Course-PHY-6'),
-- PHY SEM 7
('Satellite Remote Sensing','Course-PHY-7'),
('General Chemistry','Course-PHY-7'),
-- PHY SEM 8
('Project II	','Course-PHY-8'),

-- EE SEM 1
('Algorithms and Data Structures','Course-EE-1'),
('Introduction to Non-linear Control','Course-EE-1'),
('Introduction to Digital Control Systems','Course-EE-1'),
('Introduction to Computer Programming','Course-EE-1'),
('Electronics I','Course-EE-1'),
-- EE SEM 2
('Computer Graphics','Course-EE-2'),
('Computer Organization','Course-EE-2'),
('Robotics','Course-EE-2'),
('Object Oriented Programming','Course-EE-2'),
('Electric Circuits Analysis I','Course-EE-2'),
-- EE SEM 3
('Database Systems','Course-EE-3'),
('Operating Systems Concepts','Course-EE-3'),
('VLSI Design','Course-EE-3'),
('Electronics II','Course-EE-3'),
-- EE SEM 4
('Distributed Computing','Course-EE-4'),
('Computer Architecture','Course-EE-4'),
('Data Communication and Computer Networks','Course-EE-4'),
('Electric Circuits Analysis II','Course-EE-4'),
-- EE SEM 5
('Systems Programming','Course-EE-5'),
('Real Time Embedded Systems','Course-EE-5'),
('Electric Machines','Course-EE-5'),
('Electrical Measurements and Instrumentation','Course-EE-5'),
-- EE SEM 6
('Software Engineering','Course-EE-6'),
('Fuzzy Logic','Course-EE-6'),
('Multivariable Control','Course-EE-6'),
('Microprocessor Systems and Interfacing','Course-EE-6'),
-- EE SEM 7
('Data Communication and Computer Networks','Course-EE-7'),
('Stochastic Control','Course-EE-7'),
('Final Year Project (Part I)','Course-EE-7'),
('Probability Methods in Engineering','Course-EE-7'),
-- EE SEM 8
('Neural Networks','Course-EE-8'),
('Artificial Intelligence','Course-EE-8'),
('Final Year Project (Part II)','Course-EE-8'),




-- AF SEM 1
('Computing for Management','Course-AF-1'),
('Macro Economics','Course-AF-1'),
('Business Mathematics I','Course-AF-1'),
('Cost and Management Accounting','Course-AF-1'),
('Principles of Accounting','Course-AF-1'),
-- AF SEM 2
('Contemporary Taxation','Course-AF-2'),
('Global Business Management','Course-AF-2'),
('Business Mathematics II','Course-AF-2'),
('Accounting I','Course-AF-2'),
('Research Tools and Techniques','Course-AF-2'),
-- AF SEM 3
('Financial Accounting','Course-AF-3'),
('Financial Management','Course-AF-3'),
('Business Finance','Course-AF-3'),
('Introduction to Management','Course-AF-3'),
('Auditing','Course-AF-3'),
-- AF SEM 4
('Accounting II','Course-AF-4'),
('Corporate Finance','Course-AF-4'),
('Research Tools and Techniques','Course-AF-4'),
('Accounting Information System','Course-AF-4'),
-- AF SEM 5
('International Financial Management','Course-AF-5'),
('Research Tools and Techniques','Course-AF-5'),
('Productions and Operations Management','Course-AF-5'),
('Financial Statement Analysis and Valuation','Course-AF-5'),
-- AF SEM 6
('Entrepreneurship','Course-AF-6'),
('Project Management','Course-AF-6'),
('Business Taxation','Course-AF-6'),
('Statistical Inference','Course-AF-6'),
('Strategic Management','Course-AF-6'),
-- AF SEM 7
('Islamic Banking and Finance','Course-AF-7'),
('Financial Econometrics','Course-AF-7'),
('Corporate Law','Course-AF-7'),
('Business Communication Workshop','Course-AF-7'),
-- AF SEM 8
('Project','Course-AF-8'),
('Project Management','Course-AF-8');



INSERT INTO SemesterCourses (
    semesterCourseID ,
    semester,
    courseID
)
VALUE
('CS-SEM',1,'Course-CS-1'),
('CS-SEM',2,'Course-CS-2'),
('CS-SEM',3,'Course-CS-3'),
('CS-SEM',4,'Course-CS-4'),
('CS-SEM',5,'Course-CS-5'),
('CS-SEM',6,'Course-CS-6'),
('CS-SEM',7,'Course-CS-7'),
('CS-SEM',8,'Course-CS-8'),

('SE-SEM',1,'Course-SE-1'),
('SE-SEM',2,'Course-SE-2'),
('SE-SEM',3,'Course-SE-3'),
('SE-SEM',4,'Course-SE-4'),
('SE-SEM',5,'Course-SE-5'),
('SE-SEM',6,'Course-SE-6'),
('SE-SEM',7,'Course-SE-7'),
('SE-SEM',8,'Course-SE-8'),


('BA-SEM',1,'Course-BA-1'),
('BA-SEM',2,'Course-BA-2'),
('BA-SEM',3,'Course-BA-3'),
('BA-SEM',4,'Course-BA-4'),
('BA-SEM',5,'Course-BA-5'),
('BA-SEM',6,'Course-BA-6'),
('BA-SEM',7,'Course-BA-7'),
('BA-SEM',8,'Course-BA-8'),


('DESIGN-SEM',1,'Course-DESIGN-1'),
('DESIGN-SEM',2,'Course-DESIGN-2'),
('DESIGN-SEM',3,'Course-DESIGN-3'),
('DESIGN-SEM',4,'Course-DESIGN-4'),
('DESIGN-SEM',5,'Course-DESIGN-5'),
('DESIGN-SEM',6,'Course-DESIGN-6'),
('DESIGN-SEM',7,'Course-DESIGN-7'),
('DESIGN-SEM',8,'Course-DESIGN-8'),


('ARCHI-SEM',1,'Course-ARCHI-1'),
('ARCHI-SEM',2,'Course-ARCHI-2'),
('ARCHI-SEM',3,'Course-ARCHI-3'),
('ARCHI-SEM',4,'Course-ARCHI-4'),
('ARCHI-SEM',5,'Course-ARCHI-5'),
('ARCHI-SEM',6,'Course-ARCHI-6'),
('ARCHI-SEM',7,'Course-ARCHI-7'),
('ARCHI-SEM',8,'Course-ARCHI-8'),


('AF-SEM',1,'Course-AF-1'),
('AF-SEM',2,'Course-AF-2'),
('AF-SEM',3,'Course-AF-3'),
('AF-SEM',4,'Course-AF-4'),
('AF-SEM',5,'Course-AF-5'),
('AF-SEM',6,'Course-AF-6'),
('AF-SEM',7,'Course-AF-7'),
('AF-SEM',8,'Course-AF-8'),

('PHY-SEM',1,'Course-PHY-1'),
('PHY-SEM',2,'Course-PHY-2'),
('PHY-SEM',3,'Course-PHY-3'),
('PHY-SEM',4,'Course-PHY-4'),
('PHY-SEM',5,'Course-PHY-5'),
('PHY-SEM',6,'Course-PHY-6'),
('PHY-SEM',7,'Course-PHY-7'),
('PHY-SEM',8,'Course-PHY-8'),


('EE-SEM',1,'Course-EE-1'),
('EE-SEM',2,'Course-EE-2'),
('EE-SEM',3,'Course-EE-3'),
('EE-SEM',4,'Course-EE-4'),
('EE-SEM',5,'Course-EE-5'),
('EE-SEM',6,'Course-EE-6'),
('EE-SEM',7,'Course-EE-7'),
('EE-SEM',8,'Course-EE-8');


INSERT INTO Programs(
    programName,
    semesterCourseID
)VALUES
('Computer Science','CS-SEM'),
('Software Engineering','SE-SEM'),
('Design','DESIGN-SEM'),
('Architecture','ARCHI-SEM'),
('Accounting Finance','AF-SEM'),
('Business Administration','BA-SEM'),
('Electrical Engineering','EE-SEM'),
('Physics','PHY-SEM');

INSERT INTO DepartmentConsists(
	depProgramID,
    programName
)
VALUES
('CS-P','Computer Science'),
('CS-P','Software Engineering'),
('Archi-P','Design'),
('Archi-P','Architecture'),
('BA-P','Accounting Finance'),
('BA-P','Business Administration'),
('EE-P','Electrical Engineering'),
-- ('EE-P','Computer Enginnering'),
('PHY-P','Physics');

INSERT INTO Departments(
	departmentName,
    depProgramID
)VALUES
('Computer Science','CS-P'),
('Architecture','Archi-P'),
('Business Administration','BA-P'),
('Electrical','EE-P'),
('Physics','PHY-P');


INSERT INTO Students(
	rollnumber ,
    password_ ,
    first_name ,
    last_name ,
    email_address,
    departmentName,
    programName,
    semester,
    isRegistered
		
)VALUES
('COMSATS-028','coding123','Zulqifal','Abbasi','syedanish39@gmail.com','Architecture','Design',1,TRUE);
-- ('COMSATS-029','coding123','Zulqifal','Abbasi','syedanish39@gmail.com','Business Administration','Accounting Finance',1,TRUE);

/**

(SELECT courseName
	FROM Students AS s
	NATURAL JOIN Programs AS p
	NATURAL JOIN SemesterCourses AS sc
	NATURAL JOIN Courses AS c
	WHERE (semester = 1 and rollnumber = 'COMSATS-094')),

**/

INSERT INTO Results (
	rollnumber,
	courseName,
    semesterID
)VALUES

('COMSATS-028','Foundation Studio I',1),
('COMSATS-028','Proportions and Geometry in ART',1),
 ('COMSATS-028','Design and Presentation I',1),
('COMSATS-028','Social and Cultural Studies',1);



INSERT INTO  Admin (
	admin_id ,
    name,
    admin_password
)
VALUES
('admin-russi','RUSLAN DURRANI', 'admin1'),
('admin-dani','DANISH RUSLAN' ,'admin2');




INSERT INTO  Verified(
	admin_id,
    rollnumber
)
VALUES 

('admin-dani','COMSATS-028');




INSERT INTO Faculty(
	facultyID,
    facultyName,
    email_address,
    password,
    departmentName,
    validate
)
VALUES 
-- CSD Faculty
('CSD-Faculty-1','Dr Asim','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-2','Dr Bajwa','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-3','Dr Azhar','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-4','Dr Basit RAZA','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-5','Dr Mukhtar Azeem','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-6','Isma Ul hassan','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-7','Dr Hammad Omer','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-8','Lailma','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-9','Abdur Rehman','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-10','Dr Ruslan','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-11','Dr Danish','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-12','Dr Qasim','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-13','Dr Basharat','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-14','Olive Yew','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-15','Dr Mehmood','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-16','Dr Ahsan','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-17','Dr Muneed','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-18','Saad Iqbal','syedanish39@gmail.com','123abc','Computer Science',true),
('CSD-Faculty-19','Umar','syedanish39@gmail.com','123abc','Computer Science',false),
('CSD-Faculty-20','Pharis','syedanish39@gmail.com','123abc','Computer Science',false),
-- BAD Faculty
('BAD-Faculty-1','Roy L. Commishun','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-2','Col Fays','123abc','syedanish39@gmail.com','Business Administration',false),
('BAD-Faculty-3','Art Decco','123abc','syedanish39@gmail.com','Business Administration',false),
('BAD-Faculty-4','Jen Tile','123abc','syedanish39@gmail.com','Business Administration',false),
('BAD-Faculty-5','Wayde N. Thabalanz','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-6','Anne T. Kwayted','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-7','Carmen Sayid','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-8','Anne Gloindian','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-9','Abdur Rehman','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-10','Dr Ruslan','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-11','Dr Danish','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-12','Neil Down','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-13','Dr Basharat','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-14','Theresa Green','syedanish39@gmail.com','123abc','Business Administration',true),
('BAD-Faculty-15','Percy Vere','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-16','Dr Ahsan','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-17','Augusta Wind','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-18','Hank R. Cheef','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-19','Paige Turner','syedanish39@gmail.com','123abc','Business Administration',false),
('BAD-Faculty-20','Rose Bush','syedanish39@gmail.com','123abc','Business Administration',false),

-- EE Faculty
('EE-Faculty-1','Nimatullah','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-2','Osama','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-3','Ruhullah','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-4','Sajjad','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-5','Talat','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-6','Khalifah','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-7','Jalal ad-Din','syedanish39@gmail.com','123abc','Electrical',true),
('EE-Faculty-8','Imtiaz','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-9','Abdur Rehman','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-10','Halim','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-11','Fakhruddin','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-12','Ayub','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-13','Laura Biding','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-14','Moeen','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-15','Percy Vere','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-16','Nabil','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-17','Mansur','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-18','Hank R. Cheef','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-19','Paige Turner','syedanish39@gmail.com','123abc','Electrical',false),
('EE-Faculty-20','Lana Lynne Creem','syedanish39@gmail.com','123abc','Electrical',false),

-- ARCHI Faculty
('ARCHI-Faculty-1','Saddam','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-2','Rifat','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-3','Ahmed Tijani','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-4','Abu Bakr','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-5','Azizullah','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-6','Burhan','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-7','Furkan','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-8','Shulam Mustafa','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-9','Hikmat','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-10','Ishaq','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-11','Isa','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-12','Iqbal','syedanish39@gmail.com','123abc','Architecture',true),
('ARCHI-Faculty-13','Ilyas','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-14','Jawad','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-15','Junayd','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-16','Hakim','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-17','Kafeel','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-18','Murtaza','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-19','Nagib','syedanish39@gmail.com','123abc','Architecture',false),
('ARCHI-Faculty-20','Mustafa','syedanish39@gmail.com','123abc','Architecture',false);


INSERT INTO  Help_desk(
    rollnumber,
    student_query
)
VALUES 
('COMSATS-028','Sir i have portal issues and my marks are not uploaded yet');





INSERT INTO  FacultyCourses(
	facultyID,
    courseName
)VALUES
-- CS Teachers
('CSD-Faculty-1','Introduction to ICT'),
('CSD-Faculty-2','English Comprehension & Composition'),
('CSD-Faculty-3','Islamic Studies'),
('CSD-Faculty-4','Calculus & Analytics Geometery'),
('CSD-Faculty-5','Applied Physics for Engineers'),
-- ('CSD-Faculty-6','Programming Fundamentals'),
('CSD-Faculty-7','Report Writing Skills'),
('CSD-Faculty-8','Multivaribale Calculus'),
-- ('CSD-Faculty-9','Professional Practices for IT'),
('CSD-Faculty-10','Discrete Structures'),
('CSD-Faculty-11','Object Oriented Programming'),
-- ('CSD-Faculty-12','Digital Logic DEsign'),
('CSD-Faculty-13','Statistics & Probability Theory'),
('CSD-Faculty-14','Linear Algebra'),
('CSD-Faculty-15','Data Structures & Algorithms'),
('CSD-Faculty-16','Computer Architecture'),
('CSD-Faculty-17','Software Enginnering Concepts'),
('CSD-Faculty-18','Differential Equations'),
('CSD-Faculty-19','Communication skills'),
('CSD-Faculty-20','Theory of Automata'),
--       
('CSD-Faculty-1','Design & Analysis of Algorithms'),
('CSD-Faculty-1','Computer Science Elective IV'),
('CSD-Faculty-2','Operating Systems'),
('CSD-Faculty-2','Computer Science Elective V'),
('CSD-Faculty-3','Database Systems I'),
('CSD-Faculty-3','Insitutional Elective I'),
('CSD-Faculty-4','Computer Science Elective I'),
('CSD-Faculty-5','Microprocess & Assembly Language'),
('CSD-Faculty-6','Data communications and Computer Networks'),
-- ('CSD-Faculty-7','Human Computer Interaction'),
('CSD-Faculty-8','Web Technologies'),
('CSD-Faculty-9','Pakistan Studies'),
('CSD-Faculty-10','Computer Science Elective II'),
('CSD-Faculty-11','Compiler Contruction'),
('CSD-Faculty-12','Artificial Intelligence'),
('CSD-Faculty-13','Numerical Computing'),
-- ('CSD-Faculty-14','Senior Design Project I'),
('CSD-Faculty-15','Computer Science Elective III'),
-- ('CSD-Faculty-16','Insitutional Elective I'),
-- ('CSD-Faculty-17','Compiler Contruction'),
-- ('CSD-Faculty-18','Artificial Intelligence'),
-- ('CSD-Faculty-19','Numerical Computing'),
('CSD-Faculty-20','Senior Design Project I'),


-- SE 

('CSD-Faculty-8','Professional Practices for IT'),
('CSD-Faculty-9','SE Domain Elective I'),
('CSD-Faculty-18','SE Elective III'),
('CSD-Faculty-17','Software Testing'),
('CSD-Faculty-1','Database Systems'),
-- ('CSD-Faculty-1','Operating Systems'),
('CSD-Faculty-2','Software Requirement Engineering'),
('CSD-Faculty-2','Computer Communications & Networks'),
('CSD-Faculty-3','Software Engineering Elective I'),
('CSD-Faculty-3','GE Elective I'),
('CSD-Faculty-4','Software Quality Engineering'),
('CSD-Faculty-5','Software Design & Architecture'),
('CSD-Faculty-6','Formal Methods in Software Engineering'),
('CSD-Faculty-7','GE Elective II'),
-- ('CSD-Faculty-13','Object Oriented Programming'),
-- ('CSD-Faculty-14','Data Structures & Algorithms'),
-- ('CSD-Faculty-16','Communication Skills'),
('CSD-Faculty-17','Introduction to Software Engineering'),
-- ('CSD-Faculty-18','Statistics & Probability Theory'),
('CSD-Faculty-19','Introduction to Management'),
('CSD-Faculty-20','Object Software Enginnering Concepts'),
('CSD-Faculty-11','Programming Fundamentals'),
('CSD-Faculty-9','Digital Logic DEsign'),
('CSD-Faculty-8','Calculus & Analytic Geometry'),
-- ('CSD-Faculty-6','Discrete Structures'),
('CSD-Faculty-5','Circuits & Electronics'),
('CSD-Faculty-4','Fundamentals of Computer Programming'),
('CSD-Faculty-16','Project'),
('CSD-Faculty-12','SE Domain Elective II'),
('CSD-Faculty-13','Design Patterns'),
('CSD-Faculty-14','SE Elective II'),
('CSD-Faculty-15','Software Project Management'),
('CSD-Faculty-11','Human Computer Interaction'),


-- BA 
('BAD-Faculty-1','Introduction to Computing'),
('BAD-Faculty-2','Macro Economics'),
('BAD-Faculty-3','Business Mathematics I'),
('BAD-Faculty-4','Introduction to Business'),
('BAD-Faculty-5','Pakistan Studies'),
('BAD-Faculty-6','Islamic Studies'),
('BAD-Faculty-7','Business Mathematics II'),
-- ('BAD-Faculty-8','Accounting I'),
-- ('BAD-Faculty-9','Human Resource Management'),
-- ('BAD-Faculty-10','Financial Management'),
-- ('BAD-Faculty-11','Business Finance'),
-- ('BAD-Faculty-12','Introduction to Management'),
-- ('BAD-Faculty-13','Accounting II'),
('BAD-Faculty-14','Organizational Behavior'),
-- ('BAD-Faculty-15','Research Tools and Techniques'),
-- ('BAD-Faculty-16','Productions and Operations Management'),
-- ('BAD-Faculty-17','Organizational Behavior'),
-- ('BAD-Faculty-18','Research Tools and Techniques'),
-- ('BAD-Faculty-19','Productions and Operations Management'),
('BAD-Faculty-20','Human Resource Management'),
-- ('BAD-Faculty-1','Entrepreneurship'),
-- ('BAD-Faculty-2','Project Management'),
('BAD-Faculty-3','Marketing Management'),
('BAD-Faculty-4','Statistical Inference'),
('BAD-Faculty-5','Strategic Management'),
-- ('BAD-Faculty-6','Productions and Operations Management'),
-- ('BAD-Faculty-7','Marketing Management'),
-- ('BAD-Faculty-8','Corporate Law'),
-- ('BAD-Faculty-9','Business Communication Workshop'),
-- ('BAD-Faculty-10','Project'),
-- ('BAD-Faculty-11','Project Management'),

-- AF subjects By BA Teachers
('BAD-Faculty-1','Computing for Management'),
-- ('BAD-Faculty-2','Macro Economics'),
-- ('BAD-Faculty-3','Business Mathematics I'),
('BAD-Faculty-4','Cost and Management Accounting'),
('BAD-Faculty-5','Principles of Accounting'),
('BAD-Faculty-6','Contemporary Taxation'),
('BAD-Faculty-7','Global Business Management'),
('BAD-Faculty-8','Business Mathematics II'),
('BAD-Faculty-9','Accounting I'),
('BAD-Faculty-10','Research Tools and Techniques'),
('BAD-Faculty-11','Financial Accounting'),
('BAD-Faculty-12','Financial Management'),
('BAD-Faculty-13','Business Finance'),
('BAD-Faculty-14','Introduction to Management'),
('BAD-Faculty-15','Auditing'),
('BAD-Faculty-16','Accounting II'),
('BAD-Faculty-17','Corporate Finance'),
-- ('BAD-Faculty-18','Research Tools and Techniques'),
('BAD-Faculty-19','Accounting Information System'),
('BAD-Faculty-20','International Financial Management'),
-- ('BAD-Faculty-1','Research Tools and Techniques'),
('BAD-Faculty-2','Productions and Operations Management'),
('BAD-Faculty-3','Financial Statement Analysis and Valuation'),
('BAD-Faculty-4','Entrepreneurship'),
-- ('BAD-Faculty-5','Project Management'),
('BAD-Faculty-6','Business Taxation'),
-- ('BAD-Faculty-7','Statistical Inference'),
-- ('BAD-Faculty-8','Strategic Management'),
('BAD-Faculty-9','Islamic Banking and Finance'),
('BAD-Faculty-10','Financial Econometrics'),
('BAD-Faculty-11','Corporate Law'),
('BAD-Faculty-12','Business Communication Workshop'),
('BAD-Faculty-13','Project'),
('BAD-Faculty-14','Project Management'),

('EE-Faculty-11','Final Year Project (Part II)'),
('EE-Faculty-10','Artificial Intelligence'),
('EE-Faculty-9','Neural Networks'),
('EE-Faculty-8','Probability Methods in Engineering'),
('EE-Faculty-7','Final Year Project (Part I)'),
('EE-Faculty-6','Stochastic Control'),
-- ('EE-Faculty-5','Data Communication and Computer Networks'),
('EE-Faculty-4','Microprocessor Systems and Interfacing'),
('EE-Faculty-3','Multivariable Control'),
('EE-Faculty-14','Distributed Computing'),
('EE-Faculty-15','Computer Architecture'),
('EE-Faculty-16','Data Communication and Computer Networks'),
('EE-Faculty-17','Real Time Embedded Systems'),
('EE-Faculty-18','Research Tools and Techniques'),
('EE-Faculty-19','Electric Machines'),
('EE-Faculty-20','Electrical Measurements and Instrumentation'),
('EE-Faculty-1','Software Engineering'),
('EE-Faculty-2','Fuzzy Logic'),
('EE-Faculty-8','Object Oriented Programming'),
('EE-Faculty-9','Electric Circuits Analysis I'),
('EE-Faculty-10','Database Systems'),
('EE-Faculty-11','Operating Systems Concepts'),
('EE-Faculty-12','VLSI Design'),
('EE-Faculty-13','Electronics II'),
('EE-Faculty-2','Introduction to Non-linear Control'),
('EE-Faculty-1','Algorithms and Data Structures'),
('EE-Faculty-3','Introduction to Digital Control Systems'),
('EE-Faculty-4','Introduction to Computer Programming'),
('EE-Faculty-5','Computer Graphics'),
('EE-Faculty-6','Computer Organization'),
('EE-Faculty-7','Robotics'),



-- ARCHI Dep Design Subjects
('ARCHI-Faculty-1','Foundation Studio I'),
('ARCHI-Faculty-2','Design and Presentation I'),
('ARCHI-Faculty-3','Social and Cultural Studies'),
('ARCHI-Faculty-4','Proportions and Geometry in ART'),
('ARCHI-Faculty-5','Foundation Studio II'),
('ARCHI-Faculty-6','Design and Presentation II'),
('ARCHI-Faculty-7','Islamic Studies'),
('ARCHI-Faculty-8','Design for Community'),
-- ('ARCHI-Faculty-9','History of Philosophy of Arts and Culture II'),
('ARCHI-Faculty-10','Art Appreciation'),
('ARCHI-Faculty-11','Design Technologies I'),
('ARCHI-Faculty-12','Design Technologies III'),
('ARCHI-Faculty-13','English Comprehension and Composition'),
('ARCHI-Faculty-14','Digital Drawing and Graphics I'),
('ARCHI-Faculty-15','Pakistan Studies'),
('ARCHI-Faculty-16','Design Technologies II'),
('ARCHI-Faculty-17','Design Technologies IV'),
('ARCHI-Faculty-18','Digital Drawing and Graphics II'),
('ARCHI-Faculty-19','History of Design I'),
('ARCHI-Faculty-20','Internship'),
-- ('ARCHI-Faculty-1','Proportions and Geometry in ART'),
('ARCHI-Faculty-2','History of Design II'),
('ARCHI-Faculty-3','History of Philosophy of Arts and Culture I'),
('ARCHI-Faculty-4','Design and Presentation III'),
('ARCHI-Faculty-5','Thesis (Part I)'),
('ARCHI-Faculty-6','History of Philosophy of Arts and Culture II'),
('ARCHI-Faculty-7','Design and Presentation IV'),
('ARCHI-Faculty-8','Design Technologies V'),

-- Archi Teacher Teach Archjitecture
('ARCHI-Faculty-1','History and Theory of Art and Culture I'),
('ARCHI-Faculty-2','Environment and Energy I'),
('ARCHI-Faculty-3','Structures for Architects I'),
('ARCHI-Faculty-4','History and Theory of Art and Culture II'),
('ARCHI-Faculty-5','Material and Construction I'),
('ARCHI-Faculty-6','Environment and Energy II'),
('ARCHI-Faculty-7','Structures for Architects II'),
('ARCHI-Faculty-8','Digital Tools for Architects II'),
-- ('ARCHI-Faculty-9','Foundation Studio I'),
('ARCHI-Faculty-10','Architectural Studio I'),
('ARCHI-Faculty-11','Material and Construction II'),
('ARCHI-Faculty-12','Architectural Studio III'),
('ARCHI-Faculty-13','Digital Tools for Architects III'),
-- ('ARCHI-Faculty-14','Foundation Studio II'),
('ARCHI-Faculty-15','Architectural Studio II'),
('ARCHI-Faculty-16','Architectural Studio IV'),
('ARCHI-Faculty-17','Visual Communication I'),
('ARCHI-Faculty-18','Building Services and System I'),
('ARCHI-Faculty-19','Sustainable Design I'),
('ARCHI-Faculty-20','Visual Communication II'),
('ARCHI-Faculty-1','Building Services and System II'),
('ARCHI-Faculty-2','Sustainable Design II'),
('ARCHI-Faculty-3','Communication Techniques and Critical Writing'),
('ARCHI-Faculty-4','Architectural Studio V'),
('ARCHI-Faculty-5','Thesis Design I'),
('ARCHI-Faculty-6','History and Theory of Urban Design'),
('ARCHI-Faculty-7','Thesis Design II'),
('ARCHI-Faculty-8','Professional Practice');





INSERT INTO NoticeBoard(
	notice_message,
    admin_id
)VALUES(
'CSS Society k liye Zakat Jama kro',
'admin-russi'
);




/**

-- BAF
('BAF-Faculty-1','Introduction to Computing'),
('BAF-Faculty-2','Macro Economics'),
('BAF-Faculty-3','Business Mathematics I'),
('BAF-Faculty-4','Introduction to Business'),
('BAF-Faculty-5','Pakistan Studies'),
('BAF-Faculty-6','Islamic Studies'),
('BAF-Faculty-7','Business Mathematics II'),
-- ('BAD-Faculty-8','Accounting I'),
-- ('BAD-Faculty-9','Human Resource Management'),
-- ('BAD-Faculty-10','Financial Management'),
-- ('BAD-Faculty-11','Business Finance'),
-- ('BAD-Faculty-12','Introduction to Management'),
-- ('BAD-Faculty-13','Accounting II'),
('BAF-Faculty-14','Organizational Behavior'),
-- ('BAD-Faculty-15','Research Tools and Techniques'),
-- ('BAD-Faculty-16','Productions and Operations Management'),
-- ('BAD-Faculty-17','Organizational Behavior'),
-- ('BAD-Faculty-18','Research Tools and Techniques'),
-- ('BAD-Faculty-19','Productions and Operations Management'),
('BAF-Faculty-20','Human Resource Management'),
-- ('BAD-Faculty-1','Entrepreneurship'),
-- ('BAD-Faculty-2','Project Management'),
('BAF-Faculty-3','Marketing Management'),
('BAF-Faculty-4','Statistical Inference'),
('BAF-Faculty-5','Strategic Management'),
-- ('BAD-Faculty-6','Productions and Operations Management'),
-- ('BAD-Faculty-7','Marketing Management'),
-- ('BAD-Faculty-8','Corporate Law'),
-- ('BAD-Faculty-9','Business Communication Workshop'),
-- ('BAD-Faculty-10','Project'),
-- ('BAD-Faculty-11','Project Management'),

-- AF subjects By BA Teachers
('BAF-Faculty-1','Computing for Management'),
-- ('BAD-Faculty-2','Macro Economics'),
-- ('BAD-Faculty-3','Business Mathematics I'),
('BAF-Faculty-4','Cost and Management Accounting'),
('BAF-Faculty-5','Principles of Accounting'),
('BAF-Faculty-6','Contemporary Taxation'),
('BAF-Faculty-7','Global Business Management'),
('BAF-Faculty-8','Business Mathematics II'),
('BAF-Faculty-9','Accounting I'),
('BAF-Faculty-10','Research Tools and Techniques'),
('BAF-Faculty-11','Financial Accounting'),
('BAF-Faculty-12','Financial Management'),
('BAF-Faculty-13','Business Finance'),
('BAF-Faculty-14','Introduction to Management'),
('BAF-Faculty-15','Auditing'),
('BAF-Faculty-16','Accounting II'),
('BAF-Faculty-17','Corporate Finance'),
-- ('BAD-Faculty-18','Research Tools and Techniques'),
('BAF-Faculty-19','Accounting Information System'),
('BAF-Faculty-20','International Financial Management'),
-- ('BAD-Faculty-1','Research Tools and Techniques'),
('BAF-Faculty-2','Productions and Operations Management'),
('BAF-Faculty-3','Financial Statement Analysis and Valuation'),
('BAF-Faculty-4','Entrepreneurship'),
-- ('BAD-Faculty-5','Project Management'),
('BAF-Faculty-6','Business Taxation'),
-- ('BAD-Faculty-7','Statistical Inference'),
-- ('BAD-Faculty-8','Strategic Management'),
('BAF-Faculty-9','Islamic Banking and Finance'),
('BAF-Faculty-10','Financial Econometrics'),
('BAF-Faculty-11','Corporate Law'),
('BAF-Faculty-12','Business Communication Workshop'),
('BAF-Faculty-13','Project'),
('BAF-Faculty-14','Project Management')
**/
/**


Teachers Wala Rola
------------------
SELECT   (courseName) as a, count(courseName)
FROM FacultyCourses
WHERE (facultyID LIKE 'CSD-Faculty%')
GROUP BY a
ORDER BY courseName;

SELECT   (courseName) as a, count(courseName)
FROM FacultyCourses
WHERE (facultyID LIKE 'BAD-Faculty%')
GROUP BY a
ORDER BY courseName;

SELECT   (courseName) as a, count(courseName)
FROM FacultyCourses
WHERE (facultyID LIKE 'EE-Faculty%')
GROUP BY a
ORDER BY courseName;

SELECT   (courseName) as a, count(courseName)
FROM FacultyCourses
WHERE (facultyID LIKE 'ARCHI-Faculty%')
GROUP BY a
ORDER BY courseName;
------------------
------------------
------------------
------------------
------------------
-- SELECT DISTINCT facultyID, courseName, rollnumber
-- FROM faculty
-- NATURAL JOIN FacultyCourses
-- NATURAL JOIN Courses
-- NATURAL JOIN Departments
-- Natural JOIN Programs
-- JOIN students
-- ON (semester)
-- NATURAL JOIN semestercourses
-- WHERE facultyID = 'ARCHI-Faculty-1';


-- ------------------------------------------
-- ------------------------------------------
-- ------------------------------------------
-- Faculty Pabandii
SELECT DISTINCT facultyID, courseName, rollnumber, course_score
FROM faculty
NATURAL JOIN FacultyCourses
NATURAL JOIN Courses
NATURAL JOIN Departments
Natural JOIN Programs
JOIN students
ON (semester)
NATURAL JOIN semestercourses
NATURAL JOIN Results
-- WHERE facultyID = 'ARCHI-Faculty-1';
-- ------------------------------------------
-- ------------------------------------------
-- ------------------------------------------
-- Studnet k COurses

SELECT *
FROM Courses
NATURAL JOIN SemesterCourses
NATURAL JOIN Students AS s
NATURAL JOIN programs
WHERE (s.semester = 1 and rollnumber = 'COMSATS-028');


-- =========================
-- =========================
-- =========================
-- Student k result -- Where laga daina specific student k liye
SELECT * FROM virtual_portal.results;
-- =========================
-- ------------------------------------------

**/
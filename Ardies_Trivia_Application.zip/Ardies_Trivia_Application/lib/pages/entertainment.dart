import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
import 'package:ardies_trivia_application/categories/categoriesTutorials.dart';
class Entertainment extends StatefulWidget {
  const Entertainment({Key? key}) : super(key: key);

  @override
  State<Entertainment> createState() => _EntertainmentState();
}

class _EntertainmentState extends State<Entertainment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.orange,
            ),
          ),
          title: Padding(
            padding: EdgeInsets.all(7),
            child: Text("Entertainment!",style: TextStyle(color: Colors.grey),),
          ),
          centerTitle: false,
          elevation: 0.0,
          backgroundColor: Colors.grey.shade50,

        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut1.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut2.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut3.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut4.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut5.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut6.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                margin: EdgeInsets.all(10),
                height: 230,
                width: 340,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/tut7.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
            ],
          ),
        )
    );;
  }
}

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../Models/dyslexia.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

import 'dart:convert';

class SightSaverDetails extends StatefulWidget {
  const SightSaverDetails({Key? key}) : super(key: key);

  @override
  State<SightSaverDetails> createState() => _SightSaverDetailsState();
}

Future<List<String>> fetchImages() async {
  try {
    final response = await Dio().get('https://picsum.photos/v2/list');
    List<dynamic> data = response.data;
    List<String> images = [];
    data.forEach((item) {
      String imageUrl = item['download_url'];
      images.add(imageUrl);
    });
    return images;
  } catch (error) {
    throw Exception('Failed to fetch images');
  }
}

class _SightSaverDetailsState extends State<SightSaverDetails> {
  bool fav = false;

  late Future<List<String>> _imagesFuture;

  @override
  void initState() {
    super.initState();
    _imagesFuture = fetchImages();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20),
        child: ListView(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                  ),
                ),
                Spacer(),
                Text(
                  "Add Favourites",
                  style: TextStyle(
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                      fontSize: 16,
                      color: Colors.black),
                ),
                Switch(
                    value: fav,
                    onChanged: (e) {
                      setState(() {
                        fav = e;
                      });
                    })
              ],
            ),
            SizedBox(
              height: 20,
              child: Divider(
                height: 5,
                color: Colors.grey,
              ),
            ),
            Text(
              "Images Extracted From File",
              style: TextStyle(
                  fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.w500,
                  fontSize: 16,
                  color: Colors.black),
            ),
            SizedBox(
              height: 14,
            ),
            FutureBuilder<List<String>>(
              future: _imagesFuture,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<String>? images = snapshot.data;
                  return CarouselSlider.builder(
                    itemCount: images?.length,
                    itemBuilder: (context, index, realIndex) {
                      final imageUrl = images![index];
                      return Image.network(
                        imageUrl,
                        fit: BoxFit.cover,
                      );
                    },
                    options: CarouselOptions(
                      autoPlay: true,
                      aspectRatio: 16 / 9,
                      enlargeCenterPage: true,
                    ),
                  );
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                } else {
                  return CircularProgressIndicator();
                }
              },
            ),
            SizedBox(
              height: 14,
            ),
            Text(
              "Text Extracted From File",
              style: TextStyle(
                  fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.w500,
                  fontSize: 16,
                  color: Colors.black),
            ),
            Text(
              "Assistant Professor at CS Dept. COMSATS University Islamabad with 10+ years of expertise. His research has focused upon the area of human computer interaction, and multimodal interfaces.Assistant Professor at CS Dept. COMSATS University Islamabad with 10+ years of expertise. His research has focused upon the area of human computer interaction, and multimodal interfaces.Assistant Professor at CS Dept. COMSATS University Islamabad with 10+ years of expertise. His research has focused upon the area of human computer interaction, and multimodal interfaces.",
              style: TextStyle(
                  fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                  fontSize: 12,
                  color: Colors.black),
            ),
            SizedBox(
              height: 14,
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                primary:
                    Colors.deepOrange, // Set the button color to deep orange
              ),
              onPressed: () {
                // Add your logic here for the speak button
              },
              icon: Icon(Icons.surround_sound_outlined),
              label: Text('Speak'),
            )
          ],
        ),
      ),
    );
  }
}

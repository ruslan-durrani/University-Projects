import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
import 'package:ardies_trivia_application/widgets/two_side_rounded_button.dart';
import 'package:ardies_trivia_application/widgets/rounded_button.dart';
import 'package:ardies_trivia_application/widgets/book_rating.dart';
import "dart:core";
import 'package:ardies_trivia_application/widgets/rounded_button.dart';
import 'package:ardies_trivia_application/widgets/reading_card_list.dart';
import 'package:ardies_trivia_application/categories/categoryBooks.dart';
class Lessons extends StatefulWidget {
  const Lessons({Key? key}) : super(key: key);

  @override
  State<Lessons> createState() => _LessonsState();
}

class _LessonsState extends State<Lessons> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // floatingActionButton: FloatingActionButton(
      //   onPressed: (){},
      //   child: Icon(Icons.help,size: 30,),
      //   backgroundColor: Colors.orange,
      // ),

      appBar: AppBar(
        leading: InkWell(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back,
            color: Colors.deepOrangeAccent,
          ),
        ),
        title: Padding(
          padding: EdgeInsets.all(7),
          child: Text("Hello Ardie!",style: TextStyle(color: Colors.grey),),
        ),
        centerTitle: false,
        elevation: 0.0,
        backgroundColor: Colors.grey.shade50,
        actions: [
          Stack(
            children: [
              Container(
                margin: EdgeInsets.all(17),
                // padding: EdgeInsets.fromLTRB(7,14,16,01),
                child: InkWell(
                  child: Icon(
                    Icons.notifications_active_sharp,
                    color: Colors.grey,
                  ),
                  onTap: (){
                    Navigator.pushNamed(context, '/view_lessons');
                  },
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  margin: EdgeInsets.all(17),
                  padding: EdgeInsets.fromLTRB(7,14,16,01),
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                      color: Colors.red,
                    borderRadius: BorderRadius.circular(20)
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(20,10,20,0),
              child: Text(
                "Let's Boost Your",
                style: TextStyle(
                    color: Colors.black87,
                    fontSize: 30,
                    fontWeight: FontWeight.bold
                ),
              ),
            ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(20,3,20,0),
                  child: Text(
                    "Brain Power",
                    style: TextStyle(
                        color: Colors.black87,
                        fontSize: 25,
                        fontWeight: FontWeight.normal
                    ),
                  ),
                ),
                for(int i = 0 ; i < 4 ; i++) Icon(
                  Icons.star_half_outlined,
                  color: Colors.deepOrangeAccent,
                  size: 20+(i*4),
                ),
              ],
            ),
            Container(
              width: double.infinity,
              height: 50,
              margin: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              padding: EdgeInsets.symmetric( horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 15),
                    blurRadius: 30,
                    color: Color(0xFF666666).withOpacity(.11),
                  ),
                ],
              ),
              child: Center(
                child: TextField(
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search,color: Colors.deepOrangeAccent,),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.clear,),
                        onPressed: () {
                          /* Clear the search field */
                        },
                      ),
                      hintText: 'Search...',
                      border: InputBorder.none),
                ),
              ),
            ),
            Container(
                margin: EdgeInsets.only(left: 15,right: 15,top: 5,bottom: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [Text("Top weekly Lessons",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600,color: Colors.black54),),InkWell(
                    onTap: (){
                      Navigator.pushNamed(context, '/view_lessons');
                    },
                    child: Container(
                      alignment: Alignment.center,
                      height: 30,
                      width: 64,
                      child: Text("View all",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                      decoration: BoxDecoration(
                        color: Colors.deepOrangeAccent,
                        borderRadius: BorderRadius.circular(20)
                      ),
                    ),
                  )],
                )
            ),
            // SingleChildScrollView(
            //   scrollDirection: Axis.horizontal,
            //   child: Row(
            //     children: <Widget>[
            //       ReadingListCard(
            //         image: "img/book-2.png",
            //         title: "Top Ten Business Hacks",
            //         auth: "Herman Joel",
            //         rating: 4.8,
            //         pressDetails: () {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (context) {
            //                 return DetailsScreen();
            //               },
            //             ),
            //           );
            //         },
            //         pressRead: (){},
            //       ),
            //       ReadingListCard(
            //         image: "img/book-1.png",
            //         title: "Crushing & Influence",
            //         auth: "Gary Venchuk",
            //         rating: 4.9,
            //         pressDetails: () {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (context) {
            //                 return DetailsScreen();
            //               },
            //             ),
            //           );
            //         },
            //         pressRead: (){},
            //       ),
            //       ReadingListCard(
            //         image: "img/book-3.png",
            //         title: "Education Today",
            //         auth: "Herman Joel",
            //         rating: 4.8,
            //         pressDetails: () {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (context) {
            //                 return DetailsScreen();
            //               },
            //             ),
            //           );
            //         },
            //         pressRead: (){},
            //       ),
            //       ReadingListCard(
            //         image: "img/book-1.png",
            //         title: "Political",
            //         auth: "Herman Joel",
            //         rating: 4.8,
            //         pressDetails: () {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (context) {
            //                 return DetailsScreen();
            //               },
            //             ),
            //           );
            //         },
            //         pressRead: (){},
            //       ),
            //       SizedBox(width: 30),
            //     ],
            //   ),
            // ),
            // Stack()
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 20,top: 10),
                    height: 260,
                    width: 200,
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(20),

                    ),
                    child: Column(
                      children: [
                        Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Image.asset("img/boy.png",fit: BoxFit.cover,),
                            )
                        ),
                        Expanded(flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\nWilliam Shakespare",style: TextStyle(fontWeight: FontWeight.bold),),
                                  Text("\ndata"),
                                ],
                              ),
                              SizedBox(height: 8,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [for (int i = 0 ; i < 4; i++) Icon(Icons.star,size: 15+(i*2),color: Colors.orange,),],),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    height: 20,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrangeAccent,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Text("Read",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20,top: 10),
                    height: 260,
                    width: 200,
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Image.asset("img/girl.png",fit: BoxFit.cover,),
                            )
                        ),
                        Expanded(flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\nHafeez Jalandri",style: TextStyle(fontWeight: FontWeight.bold),),
                                  Text("\ndata"),
                                ],
                              ),
                              SizedBox(height: 8,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [for (int i = 0 ; i < 4; i++) Icon(Icons.star,size: 15+(i*2),color: Colors.orange,),],),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    height: 20,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrangeAccent,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Text("Read",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20,top: 10),
                    height: 260,
                    width: 200,
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Image.asset("img/pen.png",fit: BoxFit.fill,),
                            )
                        ),
                        Expanded(flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\nImran Khan",style: TextStyle(fontWeight: FontWeight.bold),),
                                  Text("\nAzadi March"),
                                ],
                              ),
                              SizedBox(height: 8,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [for (int i = 0 ; i < 4; i++) Icon(Icons.star,size: 15+(i*2),color: Colors.orange,),],),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    height: 20,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrangeAccent,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Text("Read",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20,top: 10),
                    height: 260,
                    width: 200,
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Image.asset("img/teacher.png",fit: BoxFit.cover,),
                            )
                        ),
                        Expanded(flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\nAhmed Shah Abdali",style: TextStyle(fontWeight: FontWeight.bold),),
                                  Text("\nTeacher"),
                                ],
                              ),
                              SizedBox(height: 8,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [for (int i = 1 ; i < 4; i++) Icon(Icons.star,size: 15+(i*2),color: Colors.orange,),],),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    height: 20,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrangeAccent,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Text("Read",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20,top: 10),
                    height: 260,
                    width: 200,
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Image.asset("img/learn.png",fit: BoxFit.cover,),
                            )
                        ),
                        Expanded(flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("\nMaria Farooq",style: TextStyle(fontWeight: FontWeight.bold),),
                                  Text("\n Communication"),
                                ],
                              ),
                              SizedBox(height: 8,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [for (int i = 0 ; i < 4; i++) Icon(Icons.star,size: 15+(i*2),color: Colors.orange,),],),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    height: 20,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrangeAccent,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Text("Read",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ],
              ),
            ),
            Container(

              margin: EdgeInsets.only(left: 15),
              child: Text("You Were Reading ",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
            ),
            // SizedBox(height: 10,),
            Container(
              margin: EdgeInsets.all(10),
              height: 80,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(38.5),
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 10),
                    blurRadius: 33,
                    color: Color(0xFFD3D3D3).withOpacity(.84),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(38.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: Padding(
                        padding:
                        EdgeInsets.only(left: 30, right: 20),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                mainAxisAlignment:
                                MainAxisAlignment.end,
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Imported Government",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    "Imran Khan",
                                    style: TextStyle(
                                      color: kLightBlackColor,
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                    Alignment.bottomRight,
                                    child: Text(
                                      "Chapter 7 of 10",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: kLightBlackColor,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                ],
                              ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(38.5),
                              child: Image.asset(
                                "img/pen.png",
                                width: 55,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: 7,
                      width: 20,
                      decoration: BoxDecoration(
                        color: kProgressIndicator,
                        borderRadius: BorderRadius.circular(7),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.all(10),
              height: 80,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(38.5),
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 10),
                    blurRadius: 33,
                    color: Color(0xFFD3D3D3).withOpacity(.84),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(38.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: Padding(
                        padding:
                        EdgeInsets.only(left: 30, right: 20),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                mainAxisAlignment:
                                MainAxisAlignment.end,
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Dedication | Success",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    "Imran Khan",
                                    style: TextStyle(
                                      color: kLightBlackColor,
                                    ),
                                  ),
                                  Align(
                                    alignment:
                                    Alignment.bottomRight,
                                    child: Text(
                                      "Chapter 7 of 10",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: kLightBlackColor,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                ],
                              ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(38.5),
                              child: Image.asset(
                                "img/learn.png",
                                width: 55,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: 7,
                      width: 20,
                      decoration: BoxDecoration(
                        color: kProgressIndicator,
                        borderRadius: BorderRadius.circular(7),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}

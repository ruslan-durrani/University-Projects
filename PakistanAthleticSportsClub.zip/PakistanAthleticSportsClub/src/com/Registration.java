package com;

import java.io.*;

import java.util.Date;
import java.util.Scanner;


interface SportsAthleteData  {
	String stadiumName();
	String athleteUserID();
	String athleteName();
	String sportsDepartment();
	boolean isStadiumValid();
	boolean isSportsCategoryValid();

}
public class Registration  implements SportsAthleteData , StadiumsCategoriesDepartments, Serializable{
	public String[] credentials = {"Name: ", "Athlete ID: ", "Password: ", "Stadium Name: ","Sports Department: "};
	//extends Sport
	public String athleteID;
	private String athleteName;
	private String password;
	private String stadium;
	private String sportsDep;
	private Date date;
	public static File pakistanAthletesRegistrationFile = new File("All Pakistan Registered User");
	//	Stadium object ;
	static File athletesSerializedFiles = new File("Athletes Serialized Files");
	static String registrationFilePath = "Registered User.txt";


	public Registration(String atheleteId, String athleteName) throws IOException {
		this.athleteName = athleteName;
		this.athleteID = atheleteId;
		File file = new File("text.txt");
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(this);
		oos.close();
		fos.close();
	}
	private static final Scanner scanner = new Scanner(System.in);

	public Registration(String name,String username, String password, String sportsDepartment, String stadium) throws Exception {
		this.athleteName = name;
		this.athleteID = username;
		this.password = password;
		this.sportsDep = sportsDepartment;
		this.stadium = stadium;
		date = new Date();
		getInput();
		pakistanAthletesRegistrationFile.mkdir();
		File file = new File(pakistanAthletesRegistrationFile.getAbsolutePath()+"/"+registrationFilePath);
		file.createNewFile();
		writeRegisteredUsers(credentials);
		athletesSerializedFiles.mkdir();
		athletesSerializedFiles = new File(athletesSerializedFiles.getAbsolutePath()+"/"+athleteID);
		FileOutputStream fos = new FileOutputStream(athletesSerializedFiles);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(new Stadium(athleteName, athleteID, password, stadium, sportsDep));
		oos.close();
		fos.close();
		////
		new StadiumRegistrationDataBase( stadium , sportsDepartment , athleteID, credentials );
		athletesSerializedFiles = new File("Athletes Serialized Files");
	}




	private void getInput() {
		for (int i = 0; i < credentials.length; i++) {
			if(credentials[i].equalsIgnoreCase("Name: ")) {

				credentials[i] += this.athleteName;

			}
			else if(credentials[i].equalsIgnoreCase("Sports Department: ")) {

				credentials[i] += this.sportsDep;
			}
			else if(credentials[i].equalsIgnoreCase("Stadium Name: ")) {


				credentials[i] += this.stadium;

			}
			else if (credentials[i].equalsIgnoreCase("Password: ")) {

				credentials[i] += this.password;

			}
			else if (credentials[i].equalsIgnoreCase("Athlete ID: ")) {

				credentials[i] += this.athleteID;
			}

			scanner.reset();
		}



	}
	private void writeRegisteredUsers(String[] credentials) {
		pakistanAthletesRegistrationFile = new File(pakistanAthletesRegistrationFile.getAbsolutePath());

		try {
			FileWriter fw = new FileWriter(pakistanAthletesRegistrationFile.getAbsoluteFile()+"/"+registrationFilePath, true);
			for (String i : credentials) {
				fw.write(i + "\n");
			}
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static boolean isRegisteredUser(String id, String pass) throws FileNotFoundException {
		Scanner readData;
		System.out.println(pakistanAthletesRegistrationFile.getAbsolutePath()+"/"+registrationFilePath);
		File f = new File(pakistanAthletesRegistrationFile.getAbsolutePath()+"/"+registrationFilePath);
		try {
			readData = new Scanner(f);
			if(f.exists()){
				System.out.println("File Exists");
			}
			while (readData.hasNextLine()) {
				String s  = readData.nextLine();
				if(s.startsWith("Name: ")){continue;}
				if (s.endsWith(id)) {
					s  = readData.nextLine();
					System.out.println(s);
					if (s.endsWith(pass)){
						return true;
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Exception");
			return false;
		}

		readData.close();
		return false;
	}

	public static boolean isAdminRegistered(String username, String password) throws IOException {
		File file = new File("Admin" + "/" + "Registered Admin" + "/" + "Registered Admin.txt");
		FileInputStream fis = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		String[] line;
		String s;
		try {
			while ((s = br.readLine()) != null){
				line = s.split(" ");
				if (line[line.length-1].equalsIgnoreCase(username)){
					s = br.readLine();
					line = s.split(" ");
					if (line[line.length-1].equalsIgnoreCase(password)){
						return true;
					}
				}
			}
			return false;
		}catch (Exception e) {
			System.out.println("Login failed");
			return false;

		}

	}

	@Override
	public String stadiumName() {
		// TODO Auto-generated method stub
		return stadium;
	}

	@Override
	public String athleteUserID() {
		// TODO Auto-generated method stub
		return athleteID;
	}

	@Override
	public String athleteName() {
		// TODO Auto-generated method stub
		return athleteName;
	}

	@Override
	public String sportsDepartment() {
		// TODO Auto-generated method stub
		return sportsDep;
	}
	public String toString() {
		return credentials.toString();
	}
	@Override
	public boolean isStadiumValid() {

		return contains(stadium , PAK_STADIUM);
	}
	@Override
	public boolean isSportsCategoryValid() {
		return contains(sportsDep , STADIUM_CATEGORIES);
	}


	public static boolean contains(String s, String[] arr) {
		for(int i = 0 ; i < arr.length ; i++) {
			if(s.equalsIgnoreCase(arr[i])) {
				return true;
			}
		}
		return false;
	}

}
package com.RDs.FrontEnd;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import static com.RDs.FrontEnd.SplashScreen.*;

public class MainPagePanel extends JPanel {

    JLabel jLabelTitle;
    public static NoticeboardFrontEnd jPanelNoticeBoard = new NoticeboardFrontEnd();

    JButton jButtonAdmin, jButtonFaculty, jButtonStudent;



    public MainPagePanel() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000,800);


        add(Box.createRigidArea(new Dimension(0,150)));

        add(jPanelNoticeBoard);

        JScrollPane scrollPaneNoticeboard = new JScrollPane(jPanelNoticeBoard,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        add(scrollPaneNoticeboard);
        scrollPaneNoticeboard.setMaximumSize(new Dimension(600, 200));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonAdmin = new JButton("ADMINISTRATION");

        add(jButtonAdmin);

        jButtonAdmin.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonAdmin.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonAdmin.setForeground(Color.GRAY);
        jButtonAdmin.setMaximumSize(new Dimension(180,45));
        jButtonAdmin.setBorderPainted(false);
        jButtonAdmin.setBackground(Color.WHITE);
        jButtonAdmin.setFocusable(false);

        add(Box.createRigidArea(new Dimension(0,10)));

        jButtonFaculty = new JButton("FACULTY");

        add(jButtonFaculty);

        jButtonFaculty.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonFaculty.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonFaculty.setForeground(Color.GRAY);
        jButtonFaculty.setMaximumSize(new Dimension(180,45));
        jButtonFaculty.setBorderPainted(false);
        jButtonFaculty.setBackground(Color.WHITE);
        jButtonFaculty.setFocusable(false);

        add(Box.createRigidArea(new Dimension(0,10)));

        jButtonStudent = new JButton("STUDENT");

        add(jButtonStudent);

        jButtonStudent.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonStudent.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonStudent.setForeground(Color.GRAY);
        jButtonStudent.setMaximumSize(new Dimension(180,45));
        jButtonStudent.setBorderPainted(false);
        jButtonStudent.setBackground(Color.WHITE);
        jButtonStudent.setFocusable(false);


        jButtonAdmin.addActionListener(e -> {
            setVisible(false);
            administrationLogin.setVisible(true);

        });

        jButtonStudent.addActionListener(e-> {
            setVisible(false);
            studentLogin.setVisible(true);
        });

        jButtonFaculty.addActionListener(e-> {
            setVisible(false);
            facultyLogin.setVisible(true);
        });







    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/backgroundMain.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }
}

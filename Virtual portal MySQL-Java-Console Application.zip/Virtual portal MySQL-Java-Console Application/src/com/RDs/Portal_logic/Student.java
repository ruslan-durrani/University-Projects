package com.RDs.Portal_logic;

import com.RDs.Database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Student extends Database {

    public ArrayList<ArrayList<String>> studentDynamic = new ArrayList<>();
    public String[][] studentDetail;

    public Student() throws SQLException {

    }

    public String[][] fillStudentTable() {

        String validationQuery = "SELECT * FROM Students WHERE isRegistered = 0";

        // rollnumber, password_, first_name, last_name, departmentName, programName, semester, isRegistered
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            int i = 0;
            while (rs.next()) {
//                facultyID, facultyName, password, departmentName

                String studentId = rs.getString("rollnumber");
                String first_name = rs.getString("first_name");
                String last_name = rs.getString("last_name");
                String departmentName = rs.getString("departmentName");
                String programName = rs.getString("programName");
                String semester = rs.getString("semester");
                studentDynamic.add(new ArrayList<>());
                studentDynamic.get(i).add(studentId);
                studentDynamic.get(i).add(first_name);
                studentDynamic.get(i).add(last_name);
                studentDynamic.get(i).add(departmentName);
                studentDynamic.get(i).add(programName);
                studentDynamic.get(i).add(semester);
                i++;


            }

            if (studentDynamic.isEmpty()) return new String[][]{};

            studentDetail = new String[studentDynamic.size()][studentDynamic.get(0).size()];

            for (int j = 0; j < studentDynamic.size(); j++) {

                for (int k = 0; k < studentDynamic.get(j).size(); k++) {
                    studentDetail[j][k] = studentDynamic.get(j).get(k);
                }
            }

            return studentDetail;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new String[][]{};
    }


    public boolean verifyStudent(String registrationNumber) {


        String sql = "SELECT * FROM Students WHERE rollnumber = '" + registrationNumber + "'";

        try {
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            String departmentName = rs.getString("departmentName");
            String programName = rs.getString("programName");
            String registrationNumber_ = rs.getString("rollnumber");
            int semesterID = rs.getInt("semester");

            System.out.println(departmentName +": " + programName + ":" + registrationNumber);

            if (!registrationNumber_.equalsIgnoreCase(registrationNumber)) return false;
            String sql_0 = "UPDATE Students SET isRegistered = 1 WHERE rollnumber = '" + registrationNumber + "'";
            stmt.executeUpdate(sql_0);

            String sql1 = "SELECT * FROM Departments NATURAL JOIN departmentconsists NATURAL JOIN Programs NATURAL JOIN Courses NATURAL JOIN SemesterCourses WHERE departmentName = '" + departmentName + "' and programName = '" + programName + "' AND semester= " + semesterID;

            ResultSet rs_1 = stmt.executeQuery(sql1);

            while (rs_1.next()) {

                String courseName = rs_1.getString("courseName");

                String sql_3 = "INSERT INTO Results (rollnumber, courseName, semesterID) VALUES (?,?,?)";

                PreparedStatement preparedStatement= connection.prepareStatement(sql_3);
                preparedStatement.setString(1,registrationNumber);
                preparedStatement.setString(2,courseName);
                preparedStatement.setInt(3,semesterID);
                preparedStatement.execute();


            }
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;


    }

    public boolean disapproveStd(String rollNumber) {
        String sql = "DELETE FROM Students Where rollnumber='" + rollNumber + "'";

        try {
            return stmt.executeUpdate(sql) > 0;
        } catch (SQLException e) {
            System.out.println("Error ! Disapproving Student");
        }

        return false;

    }
}


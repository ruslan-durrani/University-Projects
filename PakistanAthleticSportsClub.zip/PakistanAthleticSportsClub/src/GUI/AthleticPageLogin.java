package GUI;

import com.Login;
import com.Stadium;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import static GUI.Frame.*;

public class AthleticPageLogin extends JPanel {

    JButton buttonLogin, buttonBack;
    public static JButton buttonRegister;
    public JLabel adminTitle;
    JPasswordField passwordField;
    JTextField usernameField;
//
//    public Stadium stadium = new Stadium();


    public AthleticPageLogin() {

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(500, 500);
        setBackground(new Color(0xFF6200));
        setVisible(true);


        adminTitle = new JLabel("ATHLETIC LOGIN");
        adminTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminTitle.setVisible(true);
        adminTitle.setFont(new Font("Monotype Sort", Font.BOLD, 24));
        adminTitle.setForeground(Color.WHITE);
        add(adminTitle);

        add(Box.createRigidArea(new Dimension(0, 100)));


        usernameField = new JTextField("Enter Username");
        usernameField.setVisible(true);
        usernameField.setMinimumSize(new Dimension(180, 40));
        usernameField.setMaximumSize(new Dimension(180, 40));
        add(usernameField);
        add(Box.createRigidArea(new Dimension(0, 10)));

        JPanel jPanel1 = new JPanel();
        jPanel1.setVisible(true);
        add(jPanel1);
        jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.X_AXIS));
        jPanel1.setBackground(new Color(0xFF6200));

        passwordField = new JPasswordField("Enter Password");
        passwordField.setVisible(true);
        passwordField.setMinimumSize(new Dimension(180, 40));
        passwordField.setMaximumSize(new Dimension(180, 40));
        add(passwordField);
        add(Box.createRigidArea(new Dimension(0, 10)));


        JPanel jPanel = new JPanel();
        jPanel.setVisible(true);
        add(jPanel);
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.X_AXIS));
        jPanel.setBackground(new Color(0xFF6200));


        // Login Button
        buttonLogin = new JButton("Login");
        jPanel.add(buttonLogin);
        buttonLogin.setVisible(true);
        buttonLogin.setMaximumSize(new Dimension(80,40));
        buttonLogin.setMinimumSize(new Dimension(80,40));
        buttonLogin.setFocusable(false);
        buttonLogin.setBackground(new Color(252, 69, 31));
        buttonLogin.setForeground(Color.WHITE);
        buttonLogin.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonLogin.setBorderPainted(false);
        // BACK Button

        jPanel.add(Box.createRigidArea(new Dimension(10,0)));

        buttonBack = new JButton("Back");
        jPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setMaximumSize(new Dimension(80,40));
        buttonBack.setMinimumSize(new Dimension(80,40));
        buttonBack.setFocusable(false);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setBorderPainted(false);

        add(Box.createRigidArea(new Dimension(  0,10)));

        buttonRegister = new JButton("Register");
        buttonRegister.setVisible(true);
        add(buttonRegister);
        buttonRegister.setAlignmentX(Component.CENTER_ALIGNMENT);
//        buttonRegister.setBounds(170, 280, 85, 30);
        buttonRegister.setFocusable(false);
        buttonRegister.setMaximumSize(new Dimension(85,40));
        buttonRegister.setMinimumSize(new Dimension(85,40));
        buttonRegister.setBackground(new Color(252, 69, 31));
        buttonRegister.setForeground(Color.WHITE);
        buttonRegister.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonRegister.setBorderPainted(false);

        buttonLogin.addActionListener(e -> {

            Login login = new Login();

            try {

                String username = usernameField.getText();
                String password = String.valueOf(passwordField.getPassword());
                System.out.println(password + " " + username);

                if (password.isEmpty() && username.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Password and Username field is empty!");

                } else if (username.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Username field is empty!");
                } else if (password.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Password field is empty!");
                } else if (login.loginAthlete(username, password)) {
//                    System.out.println(login.isAdminUser(username, password));
                    JOptionPane.showMessageDialog(this, "Logged In Successfully");
                    usernameField.setVisible(false);
                    passwordField.setVisible(false);
                    buttonRegister.setVisible(false);
                    buttonBack.setVisible(false);
                    buttonLogin.setVisible(false);
                    adminTitle.setVisible(false);
                    add(new AthleteHomePage());

                } else {
                    JOptionPane.showMessageDialog(this, "Username Or Password is Incorrect");
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        });

        buttonBack.addActionListener(e -> {
            int exitDialog = JOptionPane.showConfirmDialog(this, "Sure? You want to go back?", "Back to Main Menu",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (exitDialog == JOptionPane.YES_OPTION) {
                setVisible(false);
                mainPagePanel.setVisible(true);

            }
        });

        buttonRegister.addActionListener(e -> {
            setVisible(false);
            athleticRegistration.setVisible(true);
        });

    }

}

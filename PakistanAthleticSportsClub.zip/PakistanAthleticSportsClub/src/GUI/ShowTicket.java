package GUI;

import com.Admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import static GUI.Frame.adminLoginHomePage;

public class ShowTicket extends JPanel {

    JLabel ticketName, data;
    JSpinner jSpinnerDepartment, jSpinnerStadium;
    JButton buttonSubmit, buttonBack;
    JTable showTicketTable;
    JScrollPane scrollPaneTable;

    public ShowTicket() {

        setVisible(true);
        setSize(500, 500);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        String[] ticketColumn = new String[]{"ID:","Department: ", "Title: ", "Stadium: ", "Day: ", "Time: "};

        ticketName = new JLabel("Show Ticket");
        ticketName.setVisible(true);
        add(ticketName);
        ticketName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        ticketName.setForeground(Color.WHITE);
        ticketName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));

        String[] departmentArray = {"Select Department","Cricket", "Football","Tennis","Volley Ball","Table Tennis"};
        String[] stadiumArray = {"Select Stadium","Islamabad", "KPK", "Karachi", "Baluchistan"};
        jSpinnerDepartment = new JSpinner(new SpinnerListModel(departmentArray));
        jSpinnerDepartment.setVisible(true);
        add(jSpinnerDepartment);
        jSpinnerDepartment.setMaximumSize(new Dimension(180, 40));
        jSpinnerDepartment.setMinimumSize(new Dimension(180, 40));
        add(Box.createRigidArea(new Dimension(0, 11)));

        jSpinnerStadium = new JSpinner(new SpinnerListModel(stadiumArray));
        add(jSpinnerStadium);
        jSpinnerStadium.setMaximumSize(new Dimension(180, 40));
        jSpinnerStadium.setMinimumSize(new Dimension(180, 40));
        jSpinnerStadium.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 18)));


        JPanel buttonPanel = new JPanel();
        add(buttonPanel);
        buttonPanel.setVisible(true);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(0xFF6200));

        buttonBack = new JButton("Back");
        buttonPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(90, 40));
        buttonBack.setMinimumSize(new Dimension(90, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
        buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));

        buttonSubmit = new JButton("Submit");
        buttonPanel.add(buttonSubmit);
        buttonSubmit.setVisible(true);
        buttonSubmit.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonSubmit.setMaximumSize(new Dimension(90, 40));
        buttonSubmit.setMinimumSize(new Dimension(90, 40));
        buttonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSubmit.setForeground(Color.white);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setBorderPainted(false);
        buttonSubmit.setFocusable(false);



        data = new JLabel("Data:");
        add(data);
        data.setVisible(true);
        data.setForeground(Color.white);
        data.setFont(new Font("Monotype Sort", Font.BOLD, 18));
        add(Box.createRigidArea(new Dimension(0, 11)));
        data.setAlignmentX(Component.CENTER_ALIGNMENT);

        buttonPanel.add(Box.createRigidArea(new Dimension(0, 18)));



        showTicketTable = new JTable();
        scrollPaneTable = new JScrollPane();

        showTicketTable.getTableHeader().setReorderingAllowed(false);

        showTicketTable.setModel(new DefaultTableModel(new String[][]{},
                ticketColumn));

        scrollPaneTable.setViewportView(showTicketTable);
        add(scrollPaneTable);


        buttonSubmit.addActionListener(e -> {

            String department = String.valueOf(jSpinnerDepartment.getValue());
            String stadium = String.valueOf(jSpinnerStadium.getValue());

//            System.out.println(showTicketTable.getModel().getRowCount());

            Admin admin = null;
            try {
                admin = new Admin();
                if (!(admin.showTicketData(stadium, department))){
                    JOptionPane.showMessageDialog(this,"No Record Found");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            assert admin != null;
            showTicketTable.setModel(new DefaultTableModel(admin.ticket2DArray, ticketColumn));
        });

        buttonBack.addActionListener(e ->

        {
            ((DefaultTableModel) showTicketTable.getModel()).setRowCount(0);
            setVisible(false);
            adminLoginHomePage.setVisible(true);
        });


    }

}

package com.RDs.Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DATABASE_URL = "jdbc:mysql://localhost/virtual_portal";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "Realmadridcr7@";
    public Connection connection;
    public Statement stmt;

    public Database() throws SQLException {
        System.out.println("Connected");
        connection = DriverManager.getConnection(DATABASE_URL, USER, PASS);
        stmt = connection.createStatement();
    }
}
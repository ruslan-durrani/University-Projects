package GUI;

import com.Registration;
import com.Stadium;

import javax.swing.*;
import java.awt.*;
import java.io.*;

import static GUI.Frame.athleticPageLogin;

public class AthleteHomePage extends JPanel {

    JLabel welcome, athleteName, athleteUsername, athleteStadium, athleteDepartment;
    Stadium stadium;
    JButton buttonLogOut;

    public AthleteHomePage() {

        setVisible(true);
        setSize(500, 500);
        setBackground(new Color(0x8FF6200));
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        try {
            stadium = readObj();
        } catch (Exception e) {
            e.printStackTrace();
        }

        welcome = new JLabel("Welcome");
        welcome.setVisible(true);
        add(welcome);
        welcome.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        welcome.setForeground(Color.WHITE);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));


        athleteName = new JLabel("Name: " + stadium.getName());
        athleteName.setAlignmentX(Component.CENTER_ALIGNMENT);
        athleteName.setFont(new Font("Monotype Sort", Font.BOLD,15));
        athleteName.setForeground(Color.WHITE);
        add(athleteName);
        athleteName.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));


        athleteUsername = new JLabel("Username: " + stadium.getId());
        athleteUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
        athleteUsername.setFont(new Font("Monotype Sort", Font.BOLD,15));
        athleteUsername.setForeground(Color.WHITE);
        add(athleteUsername);
        athleteUsername.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));

        athleteStadium = new JLabel("Stadium: " + stadium.getStadium());
        athleteStadium.setAlignmentX(Component.CENTER_ALIGNMENT);
        athleteStadium.setFont(new Font("Monotype Sort", Font.BOLD,15));
        athleteStadium.setForeground(Color.WHITE);
        add(athleteStadium);
        athleteStadium.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));

        athleteDepartment = new JLabel("Department: " + stadium.getDep());
        athleteDepartment.setAlignmentX(Component.CENTER_ALIGNMENT);
        athleteDepartment.setFont(new Font("Monotype Sort", Font.BOLD,15));
        athleteDepartment.setForeground(Color.WHITE);
        add(athleteDepartment);
        athleteDepartment.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));

        buttonLogOut = new JButton("Log out");
        buttonLogOut.setVisible(true);
        buttonLogOut.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonLogOut.setMaximumSize(new Dimension(90, 40));
        buttonLogOut.setMinimumSize(new Dimension(90, 40));
        buttonLogOut.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonLogOut.setForeground(Color.white);
        buttonLogOut.setBackground(new Color(252, 69, 31));
        buttonLogOut.setBorderPainted(false);
        buttonLogOut.setFocusable(false);
        add(buttonLogOut);

        buttonLogOut.addActionListener(e-> {
            setVisible(false);

            athleticPageLogin.usernameField.setVisible(true);
            athleticPageLogin.passwordField.setVisible(true);
            AthleticPageLogin.buttonRegister.setVisible(true);
            athleticPageLogin.buttonBack.setVisible(true);
            athleticPageLogin.buttonLogin.setVisible(true);
            athleticPageLogin.adminTitle.setVisible(true);

            athleticPageLogin.usernameField.setText("");
            athleticPageLogin.passwordField.setText("");



        });


    }


    public Stadium readObj() throws Exception {
//        System.out.println(athleticPageLogin.usernameField.getText());

        File file = new File("Athletes Serialized Files" + "/" + athleticPageLogin.usernameField.getText());
        FileInputStream fis = new FileInputStream(file);
        ObjectInputStream ois = new ObjectInputStream(fis);
        return (Stadium) ois.readObject();
    }
}

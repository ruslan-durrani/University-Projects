package GUI;

import javax.swing.*;
import java.awt.*;

import static GUI.Frame.*;

public class SpectatorPanel extends JPanel {

    JLabel spectatorName;
    JButton buttonBuyTicket, buttonDeleteTicket, buttonBack;


    public SpectatorPanel() {
        setVisible(true);
        setSize(500,500);
        setBackground(new Color(0xFF86200));
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

        spectatorName = new JLabel("Delete Ticket");
        spectatorName.setVisible(true);
        add(spectatorName);
        spectatorName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        spectatorName.setForeground(Color.WHITE);
        spectatorName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 100)));

        buttonBuyTicket = new JButton("Buy Ticket");
        add(buttonBuyTicket);
        buttonBuyTicket.setVisible(true);
        buttonBuyTicket.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBuyTicket.setMaximumSize(new Dimension(180, 40));
        buttonBuyTicket.setMinimumSize(new Dimension(180, 40));
        buttonBuyTicket.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBuyTicket.setForeground(Color.white);
        buttonBuyTicket.setBackground(new Color(252, 69, 31));
        buttonBuyTicket.setBorderPainted(false);
        buttonBuyTicket.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0, 10)));


        buttonDeleteTicket = new JButton("Delete Ticket");
        add(buttonDeleteTicket);
        buttonDeleteTicket.setVisible(true);
        buttonDeleteTicket.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonDeleteTicket.setMaximumSize(new Dimension(180, 40));
        buttonDeleteTicket.setMinimumSize(new Dimension(180, 40));
        buttonDeleteTicket.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonDeleteTicket.setForeground(Color.white);
        buttonDeleteTicket.setBackground(new Color(252, 69, 31));
        buttonDeleteTicket.setBorderPainted(false);
        buttonDeleteTicket.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0, 10)));


        buttonBack = new JButton("Back");
        add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(180, 40));
        buttonBack.setMinimumSize(new Dimension(180, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
//        add(Box.createRigidArea(new Dimension(5, 0)));

        buttonBack.addActionListener(e-> {
            setVisible(false);
            mainPagePanel.setVisible(true);
        });


        buttonBuyTicket.addActionListener(e-> {
            setVisible(false);
            buyTicketSpectator.setVisible(true);
        });

        buttonDeleteTicket.addActionListener(e->{
            setVisible(false);
            refundTicket.setVisible(true);
        });





    }
}

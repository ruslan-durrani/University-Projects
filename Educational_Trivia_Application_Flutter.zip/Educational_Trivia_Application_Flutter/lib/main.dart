import 'package:ardies_trivia_application/pages/welcome_page.dart';
import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/pages/splash.dart';
import 'package:ardies_trivia_application/categories/categoryQuiz.dart';
import 'package:ardies_trivia_application/categories/categoryBooks.dart';
import 'package:ardies_trivia_application/categories/categoryLessons.dart';
import 'package:ardies_trivia_application/categories/categoriesTutorials.dart';
import 'package:ardies_trivia_application/categories/categoryLessons.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
import 'package:ardies_trivia_application/login_signup/login_screen.dart';
import 'package:ardies_trivia_application/login_signup/sign_up.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
import 'package:ardies_trivia_application/pages/view_lessons.dart';
import 'package:ardies_trivia_application/pages/entertainment.dart';
import 'package:ardies_trivia_application/pages/educational.dart';
import 'package:ardies_trivia_application/pages/settings.dart';
import 'package:ardies_trivia_application/pages/progress.dart';
import 'package:percent_indicator/percent_indicator.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ardies',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        textTheme: Theme.of(context).textTheme.apply(
          displayColor: kBlackColor,
        ),
      ),
      initialRoute: '/',
      routes: {
        // '/': (context) => Books(),
        '/': (context) => SplashScreen(),
        '/login': (context) => Login(),
        '/signup': (context) => Signup(),
        '/welcome': (context) => WelcomePage(),
        '/books': (context) => Books(),
        '/quiz':(context) => Quiz(),
        '/lessons':(context) => Lessons(),
        '/view_lessons':(context) => ViewLessons(),
        '/tutorials':(context) => Tutorials(),
        '/entertainment':(context) => Entertainment(),
        '/settings':(context) => Settings(),
        '/progress':(context) => Progress(),
        '/educational':(context) => Educational(),
        // '/': (context) => SplashScreen(),
        // '/welcome': (context) => WelcomePage(),
      },
      // home:  WelcomePage(),
    );
  }
}
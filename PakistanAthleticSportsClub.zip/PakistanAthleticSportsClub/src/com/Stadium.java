package com;

import java.io.Serializable;

public class Stadium implements Serializable {
    String name;
    String id;
    String pass;

    String stadium;
    String dep;

    public Stadium() {
    }

    public Stadium(String name, String id, String pass, String stadium, String dep) {
        this.dep = dep;
        this.stadium = stadium;
        this.id = id;
        this.name = name;
        this.pass = pass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getStadium() {
        return stadium;
    }

    public void setStadium(String stadium) {
        this.stadium = stadium;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }


}

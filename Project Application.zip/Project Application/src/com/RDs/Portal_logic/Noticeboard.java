package com.RDs.Portal_logic;

import com.RDs.Database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static com.RDs.Database.AdministrationArea.adminID;
import static com.RDs.FrontEnd.Faculty.facultyID;

public class Noticeboard extends Database {

    public ArrayList<ArrayList<String>> noticeboardDynamicDetails = new ArrayList<>();
    public String[][] noticeboardDetails;

    public Noticeboard() throws SQLException {
    }

    public String getNoticeBoard() throws SQLException {
        StringBuilder description = new StringBuilder();

        String validationQuery = "SELECT * FROM noticeboard";
        description.append("<html><br><br><br><br>");
        ResultSet rs = stmt.executeQuery(validationQuery);
        while(rs.next()) {
            description.append("<br>");
            String noticeMessage = rs.getString("notice_message");
            String adminName = rs.getString("admin_id");
            int id = rs.getInt("noticeID");
            if (noticeMessage.length() > 100) {
                int mid = noticeMessage.length()/2;
                String[] parts = {noticeMessage.substring(0,mid),noticeMessage.substring(mid)};
                description.append(parts[0]).append("-<br>").append(parts[1]);
            }
            else {
                description.append(noticeMessage);
            }
            description.append("<br><br>");
            description.append("Posted By: ").append(adminName).append("<br>");
        }
        description.append("</html>");

        return description.toString();
    }


    public String[][] fillTableNoticeboard() {
        noticeboardDynamicDetails = new ArrayList<>();

        String validationQuery = "SELECT * FROM noticeboard";
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            int i = 0;


            while (rs.next()) {
                String noticeMessage = rs.getString("notice_message");
                String adminName = rs.getString("admin_id");
                String id = String.valueOf(rs.getInt("noticeID"));

                noticeboardDynamicDetails.add(new ArrayList<>());

                noticeboardDynamicDetails.get(i).add(id);
                noticeboardDynamicDetails.get(i).add(noticeMessage);
                noticeboardDynamicDetails.get(i).add(adminName);

                i++;
            }

            if (noticeboardDynamicDetails.isEmpty()) return new String[][]{};

            noticeboardDetails = new String[noticeboardDynamicDetails.size()][noticeboardDynamicDetails.get(0).size()];

            for (int j=0; j<noticeboardDynamicDetails.size(); j++) {

                for (int k=0; k<noticeboardDynamicDetails.get(j).size(); k++){
                    noticeboardDetails[j][k] = noticeboardDynamicDetails.get(j).get(k);
                }
            }

            return noticeboardDetails;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new String[][]{};
    }

    public boolean postNoticeboard(int noticeID,String noticeDesc) {
        String sql = "INSERT INTO Noticeboard (noticeID, notice_message, admin_id) VALUES (?,?,?)";

        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,noticeID);
            preparedStatement.setString(2,noticeDesc);
            preparedStatement.setString(3,adminID);
            boolean i = preparedStatement.execute();
            System.out.println(i);
            return true;
        } catch (SQLException e) {
            System.out.println("Error Exception: Post Error");
        }
        return false;
    }


    public boolean updatePost(int id, String description) {
        String sql = "UPDATE Noticeboard SET notice_message = '" + description +"', admin_id = '" + adminID + "' WHERE noticeID =" + id ;

        try {
            return stmt.executeUpdate(sql) > 0;
        } catch (SQLException e) {
            System.out.println("Error Exception: Update Error");
        }

        return false;
    }

    public boolean deleteNoticeboard(int id) {
        String sql = "DELETE FROM Noticeboard WHERE noticeID =" + id ;

        try {
            return stmt.executeUpdate(sql) > 0;
        } catch (SQLException e) {
            System.out.println("Error Exception: Delete Error");
        }
        return false;
    }

}

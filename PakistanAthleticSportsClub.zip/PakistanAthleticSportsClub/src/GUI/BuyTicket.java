package GUI;

import com.Admin;
import com.Spectator;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import static GUI.Frame.adminLoginHomePage;
import static GUI.Frame.spectatorPanel;

public class BuyTicket extends JPanel {

    JLabel ticketName;

    JTextField jTextFieldId, jTextFieldUsername;
    JSpinner jSpinnerStadium, jSpinnerDepartment;

    JButton buttonSearch, buttonBack, buttonSubmit;

    JTable showTicketTable;
    JScrollPane scrollPaneTable;

    public BuyTicket() {
        setVisible(true);
        setSize(500, 500);
        setBackground(new Color(0xFF86200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
//        String chooseId, String stadium, String sportsDepartment, String userName

        ticketName = new JLabel("Buy Ticket");
        ticketName.setVisible(true);
        add(ticketName);
        ticketName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        ticketName.setForeground(Color.WHITE);
        ticketName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));

        String[] stadiumArray = {"Select Stadium", "Islamabad", "KPK", "Karachi", "Baluchistan"};
        String[] departmentArray = {"Select Department", "Cricket", "Football", "Tennis", "Volley Ball", "Table Tennis"};
        JPanel panel1 = new JPanel();

        jSpinnerDepartment = new JSpinner(new SpinnerListModel(departmentArray));
        jSpinnerDepartment.setVisible(true);
        jSpinnerDepartment.setMinimumSize(new Dimension(180, 40));
        jSpinnerDepartment.setMaximumSize(new Dimension(180, 40));
//        jSpinnerDepartment.setAlignmentX(Component.CENTER_ALIGNMENT);

        jSpinnerStadium = new JSpinner(new SpinnerListModel(stadiumArray));
        jSpinnerStadium.setVisible(true);
        jSpinnerStadium.setMinimumSize(new Dimension(180, 40));
        jSpinnerStadium.setMaximumSize(new Dimension(180, 40));

        panel1.add(jSpinnerDepartment);
        panel1.add(Box.createRigidArea(new Dimension(10, 0)));
        panel1.add(jSpinnerStadium);
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
        panel1.setBackground(new Color(0xFF6200));
        add(panel1);
        panel1.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));


        JPanel buttonPanel = new JPanel();
        add(buttonPanel);
        buttonPanel.setVisible(true);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(0xFF6200));

        buttonBack = new JButton("Back");
        buttonPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(90, 40));
        buttonBack.setMinimumSize(new Dimension(90, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
        buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));

        buttonSearch = new JButton("Search");
        buttonPanel.add(buttonSearch);
        buttonSearch.setVisible(true);
        buttonSearch.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonSearch.setMaximumSize(new Dimension(90, 40));
        buttonSearch.setMinimumSize(new Dimension(90, 40));
        buttonSearch.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSearch.setForeground(Color.white);
        buttonSearch.setBackground(new Color(252, 69, 31));
        buttonSearch.setBorderPainted(false);
        buttonSearch.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0, 10)));

        JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2, BoxLayout.X_AXIS));
        panel2.setBackground(new Color(0xFF6200));

        jTextFieldId = new JTextField("Enter Id");
        jTextFieldId.setVisible(false);
        add(panel2);
        jTextFieldId.setMinimumSize(new Dimension(180, 40));
        jTextFieldId.setMaximumSize(new Dimension(180, 40));
        panel2.add(jTextFieldId);
        panel2.add(Box.createRigidArea(new Dimension(10, 0)));

        jTextFieldUsername = new JTextField("Enter Username");
        jTextFieldUsername.setVisible(false);
        jTextFieldUsername.setMinimumSize(new Dimension(180, 40));
        jTextFieldUsername.setMaximumSize(new Dimension(180, 40));
        panel2.add(jTextFieldUsername);

        add(Box.createRigidArea(new Dimension(0, 10)));
        buttonSubmit = new JButton("Buy");
        add(buttonSubmit);
        buttonSubmit.setVisible(false);
        buttonSubmit.setFont(new Font("Monotype Sott", Font.BOLD, 12));
        buttonSubmit.setMaximumSize(new Dimension(90, 40));
        buttonSubmit.setMinimumSize(new Dimension(90, 40));
        buttonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSubmit.setForeground(Color.white);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setBorderPainted(false);
        buttonSubmit.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0, 10)));

        String[] ticketColumn = new String[]{"ID","Department: ", "Title: ", "Stadium: ", "Day: ", "Time: "};

        showTicketTable = new JTable();
        scrollPaneTable = new JScrollPane();

        showTicketTable.getTableHeader().setReorderingAllowed(false);

        showTicketTable.setModel(new DefaultTableModel(new String[][]{},
                ticketColumn));

        scrollPaneTable.setViewportView(showTicketTable);
        add(scrollPaneTable);

        buttonBack.addActionListener(e ->

        {
            ((DefaultTableModel) showTicketTable.getModel()).setRowCount(0);
            setVisible(false);
            spectatorPanel.setVisible(true);
            buttonSubmit.setVisible(false);
            jTextFieldId.setVisible(false);
            jTextFieldUsername.setVisible(false);
        });

        buttonSearch.addActionListener(e -> {
//            ((DefaultTableModel)showTicketTable.getModel()).setRowCount(0);
            String department = String.valueOf(jSpinnerDepartment.getValue());
            String stadium = String.valueOf(jSpinnerStadium.getValue());

            if (department.isEmpty() || department.equalsIgnoreCase("Enter Department") || stadium.isEmpty() || stadium.equalsIgnoreCase("Enter Stadium")) {
                JOptionPane.showMessageDialog(this, "Please Fill all fields");
            } else {
                Admin admin = null;
                try {
                    admin = new Admin();
                    boolean check = admin.showTicketData(stadium, department);
                    if (!check){
                        JOptionPane.showMessageDialog(this,"Record not found");
                    }
                    else {
                        showTicketTable.setModel(new DefaultTableModel(admin.ticket2DArray, ticketColumn));
                        buttonSubmit.setVisible(true);
                        jTextFieldUsername.setVisible(true);
                        jTextFieldId.setVisible(true);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                assert admin != null;

            }

        });

        buttonSubmit.addActionListener(e-> {
            Spectator spectator = new Spectator();
//            String chooseId, String stadium, String sportsDepartment, String userName
            String department = String.valueOf(jSpinnerDepartment.getValue());
            String stadium = String.valueOf(jSpinnerStadium.getValue());
            String id = jTextFieldId.getText();
            String userName = jTextFieldUsername.getText();

            if (department.isEmpty() || department.equalsIgnoreCase("Enter Department") || stadium.isEmpty() || stadium.equalsIgnoreCase("Enter Stadium") ||
                id.isEmpty() || id.equalsIgnoreCase("Enter Id") || userName.isEmpty() || userName.equalsIgnoreCase("Enter Username")) {
                JOptionPane.showMessageDialog(this,"Please fill all fields");
            }


            else {
                try {
                    if (spectator.checkMaxId(id)){
                        JOptionPane.showMessageDialog(this,"Wrong Id");
                    }
                    else {
                        if (spectator.buyTicket(id,stadium,department,userName)) {
                            JOptionPane.showMessageDialog(this,"Ticket Bought Successfully");
                        }
                        else {
                            JOptionPane.showMessageDialog(this, """
                                    Username already exists.
                                    Delete to buy new ticket.
                                    """);
                        }

                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }

        });


    }
}

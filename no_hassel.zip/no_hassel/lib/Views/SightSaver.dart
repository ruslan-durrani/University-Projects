import 'package:flutter/material.dart';
import 'package:no_hassel/Models/dyslexia.dart';
import 'package:no_hassel/Views/SightSaverDetails.dart';

class SightSaver extends StatelessWidget {
  const SightSaver({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0.0,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        title: Text(
          "Sight Saver",
          style: TextStyle(
            fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
      body: Container(
        color: Colors.black,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: MediaQuery.of(context).size.height / 1.5,
              child: Icon(
                Icons.document_scanner_outlined,
                color: Colors.white,
                size: 140,
              ),
            ),
            Spacer(),
            Container(
              padding: EdgeInsets.only(bottom: 20),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return ListView(
                            children: [
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Students In Canada",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Jobs and Education",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Terminal Exam BSE-6B",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "HCI Students",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Comsats University Files",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Students Terminal Exam",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Newspaper file",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Students Terminal Exam",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Newspaper file",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Students Terminal Exam",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Pakistan Corrupt Politicians",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Leader Imran Khan",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Diaries",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "My Work Diary",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "Hadees",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Sahih Bukhari",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                              ListTile(
                                  leading: CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      child: Icon(
                                        Icons.upload,
                                        color: Colors.white,
                                      )),
                                  title: Text(
                                    "BSE 6B Students",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "Students Projects",
                                    style: TextStyle(
                                      fontWeight: Dyslexia.on
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  trailing: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(height: 4),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 16,
                                        color: Colors.grey[600],
                                      ),
                                    ],
                                  ),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          print("object");
                                          return SightSaverDetails();
                                        },
                                      ),
                                    );
                                  }),
                            ],
                          );
                        },
                      );
                    },
                    child: Column(
                      children: [
                        Icon(
                          Icons.upload,
                          color: Colors.deepOrange,
                        ),
                        Text(
                          "Upload",
                          style: TextStyle(
                            fontWeight: Dyslexia.on
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const SightSaverDetails();
                              },
                            ),
                          );
                        },
                        child: Icon(
                          Icons.circle_sharp,
                          color: Colors.red,
                        ),
                      ),
                      Text("Capture",
                          style: TextStyle(
                            fontWeight: Dyslexia.on
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ))
                    ],
                  ),
                  Column(
                    children: [
                      Icon(
                        Icons.flip_camera_ios,
                        color: Colors.red,
                        size: 30,
                      ),
                      Text("Camera",
                          style: TextStyle(
                            fontWeight: Dyslexia.on
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ))
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}


from scheduler import Scheduler


class RR(Scheduler):
    def __init__(self, process_input_list, cpu_count, quantum):
        super().__init__(process_input_list, cpu_count)
        self.quantum = quantum

    def run(self):
        cur_time = 0
        finish_processes_count = 0
        at_idx = 0
        sorted_processes = sorted(self.processes, key=lambda x: x.at)
        # It runs until the number of finished processes equals the total number of processes.
        while finish_processes_count < self.process_count:
            # Queue the process to arrive at the current time
            for process_idx in range(at_idx, self.process_count):
                process = sorted_processes[process_idx]
                if process.at == cur_time:
                    print("processe arrived - cur_time:", cur_time, " p_id :", process.id)
                    self.ready_queue.append(process)
                elif process.at > cur_time:
                    at_idx = process_idx
                    break

            # history record
            self.record_history(self.ready_queue[:], self.cpus, self.processes)

            cpu_keep_working_count = self.get_cpu_keep_working_count(self.quantum)
            # spinning the cpus
            for cpu in self.cpus:
                # when the cpu is done
                if cpu.is_finished(self.quantum):
                    # If the process runs out of time, it is put back into the queue.
                    # If the number of processes in the queue is less than or equal to the number of idle 
		    # CPUs, leave it as is. or go ahead
                    if cpu.process.remain_bt > 0:
                        # If you can keep doing it, keep it going.
                        if cpu_keep_working_count > 0:
                            cpu_keep_working_count -= 1
                            cpu.work_time = 0
                            continue
                        self.ready_queue.append(cpu.process)
                        print("processe arrived again - cur_time:", cur_time, " p_id :", cpu.process.id)
                    else:
                        # When the process completes, each time is calculated based on the current time.
                        # Increase the number of finished processes by 1
                        print("processe finished - cur_time:", cur_time, " p_id :", cpu.process.id)
                        cpu.process.calculate_finished_process(cur_time)
                        finish_processes_count += 1
                    # After work, the CPU is allowed to rest.
                    cpu.set_idle()

                # cpu is resting
                if cpu.is_idle():
                    # If there is more than one process in the queue
                    if self.ready_queue:
                        cpu.set_process(self.ready_queue.pop(0))

            # increase current time
            cur_time += 1
            super().work()

package GUI;

import com.Admin;
import com.Registration;
import com.Stadium;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import static GUI.Frame.athleticPageLogin;

class Frame extends JFrame {

    public static JPanel mainPagePanel;
    public static AthleticPageLogin athleticPageLogin = new AthleticPageLogin();
    public static AthleteRegistration athleticRegistration = new AthleteRegistration();
    public static AdminLoginHomePage adminLoginHomePage = new AdminLoginHomePage();
    public static ShowTicket showTicket = new ShowTicket();
    public static AddTicket addTicket = new AddTicket();
    public static UpdateTicket updateTicket = new UpdateTicket();
    public static DeleteTicket deleteTicket = new DeleteTicket();
    public static SpectatorPanel spectatorPanel = new SpectatorPanel();
    public static BuyTicket buyTicketSpectator = new BuyTicket();
    public static RefundTicket refundTicket = new RefundTicket();
//    public static AthleteHomePage athleteHomePage = new AthleteHomePage();

    public Frame(){

        add(athleticRegistration);
        athleticRegistration.setVisible(false);

        add(adminLoginHomePage);
        adminLoginHomePage.setVisible(false);

        add(showTicket);
        showTicket.setVisible(false);

        add(addTicket);
        addTicket.setVisible(false);

        add(updateTicket);
        updateTicket.setVisible(false);

        add(deleteTicket);
        deleteTicket.setVisible(false);

        add(spectatorPanel);
        spectatorPanel.setVisible(false);

        add(athleticPageLogin);
        athleticPageLogin.setVisible(false);

        add(buyTicketSpectator);
        buyTicketSpectator.setVisible(false);

        add(refundTicket);
        refundTicket.setVisible(false);

//        add(athleteHomePage);
//        athleteHomePage.setVisible(false);

        setTitle("Ardies Pakistan Athletic Club");
        setVisible(true);
        ImageIcon imageTitle = new ImageIcon("oopLogo.png");
        ImageIcon favicon = new ImageIcon("titleIconPng.png");
        setSize(500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(0xFF6200));
        setIconImage(favicon.getImage());
        setLayout(null);

        mainPagePanel = new JPanel();
        add(mainPagePanel);
        mainPagePanel.setVisible(true);
        mainPagePanel.setLayout(null);
        mainPagePanel.setBackground(new Color(0xFF6200));
        mainPagePanel.setSize(500,500);

        JLabel label = new JLabel("WELCOME TO ARDIES ATHLETIC CLUB");
        mainPagePanel.add(label);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVisible(true);
        label.setVerticalAlignment(JLabel.TOP);
        label.setFont(new Font("Monotype Sorts",Font.BOLD,16));
        label.setBackground(new Color(0xFF6200));
        label.setForeground(Color.WHITE);
        label.setOpaque(true);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setIconTextGap(20);
        label.setBounds(0,0,500,200);
        imageTitle = new ImageIcon(imageTitle.getImage().getScaledInstance(120,150,Image.SCALE_SMOOTH));
        label.setIcon(imageTitle);

        JButton adminButton = new JButton("ADMIN");
        mainPagePanel.add(adminButton);
        adminButton.setVisible(true);
        adminButton.setBounds(175,225,150,35);
        adminButton.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        adminButton.setForeground(Color.white);
        adminButton.setBackground(new Color(252, 69, 31));
        adminButton.setBorderPainted(false);
        adminButton.setFocusable(false);

        JButton athleteButton = new JButton("ATHLETE");
        mainPagePanel.add(athleteButton);
        athleteButton.setVisible(true);
        athleteButton.setBounds(175,270,150,35);
        athleteButton.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        athleteButton.setForeground(Color.white);
        athleteButton.setBackground(new Color(252, 69, 31));
        athleteButton.setBorderPainted(false);
        athleteButton.setFocusable(false);

        JButton spectatorButton = new JButton("SPECTATOR");
        mainPagePanel.add(spectatorButton);
        spectatorButton.setVisible(true);
        spectatorButton.setBounds(175,315,150,35);
        spectatorButton.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        spectatorButton.setForeground(Color.white);
        spectatorButton.setBackground(new Color(252, 69, 31));
        spectatorButton.setBorderPainted(false);
        spectatorButton.setFocusable(false);




        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPagePanel.setVisible(false);
                add(new AdminPageLogin());
            }
        });

        athleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPagePanel.setVisible(false);
                athleticPageLogin.setVisible(true);
            }
        });

        spectatorButton.addActionListener(e->{
            mainPagePanel.setVisible(false);
            spectatorPanel.setVisible(true);
        });

    }
}


class AdminPageFrame extends JFrame {


    public AdminPageFrame() {
    }
}

public class Main {
    public static void main(String[] args) throws Exception {
        new Frame();

        Admin admin = new Admin();
        ArrayList<String> ar = admin.getTicketData1d();

        for (int i=0;i<ar.size(); i++)
            System.out.print(ar.get(i));

//        File file = new File("Athletes Serialized Files" + "/" + "syedanish39");
//        FileInputStream fis = new FileInputStream(file);
//        ObjectInputStream ois = new ObjectInputStream(fis);
//        Stadium stadium = (Stadium) ois.readObject();
//        System.out.println(stadium.getName());


    }
}

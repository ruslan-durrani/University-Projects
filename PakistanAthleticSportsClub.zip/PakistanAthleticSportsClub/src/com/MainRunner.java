package com;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MainRunner {
	public static final Scanner input = new Scanner(System.in);
	public static void main(String[] args) throws Exception {
		//you front page should have
//		String[] users = {"1: Athlete","2: com.Spectator","3: com.Admin","0: Exit"};
//		int choice = -1;
//		do {
//			for(String i : users) {
//				System.out.print("\n"+i);
//			}
//			try {
//				choice = input.nextInt();
//			}catch(InputMismatchException e) {
//				System.out.print("\nInvalid input. Try with correct option\n");
//				continue;
//			}
//			switch(choice) {
//			case 1: athleteModule();break;
//			case 2: spectatorModule();break;
//			case 3: adminModule();break;
//			}
//		}while(choice != 0);
//	}

//	private static void adminModule() throws Exception {
//		String[] adminOptions = {"Add Tickets","Show Tickets","Delete Tickets","Update Ticket Data"};
//		Login adminLo = new Login();
//		if(adminLo.adminLogin("syed","sa")){
//
//			for (int i = 0; i < adminOptions.length; i++) {
//				System.out.println((i+1)+") "+adminOptions[i]);
//			}
//			int choice = input.nextInt() ;
//			Admin admin = new Admin();
//			switch (choice){
//				case 1: {
//					input.nextLine();
//					System.out.println("Enter com.Stadium Name :");
//					String s = input.nextLine();
//					while(!Registration.isStadiumValid(s)){
//						System.out.println("wrong com.Stadium selected ");
//						System.out.println("Enter com.Stadium Name :");
//						s = input.nextLine();
//					}
//					System.out.println("Enter Department Name :");
//					String d = input.nextLine();
//					while(!Registration.isSportsCategoryValid(d)){
//						System.out.println("wrong department ");
//						System.out.println("Enter Department Name :");
//						d = input.nextLine();
//					}
//					admin.addTicketData();
//					Admin.showTicketData(s,d);
//					System.out.println("Ticket Added");
//					adminModule();
//				}break;
//				case 2: {
//					input.nextLine();input.nextLine();
//					System.out.println("com.Stadium: ");
//					String stadium = input.nextLine();
//					while(!Registration.isStadiumValid(stadium)){
//						System.out.println("com.Stadium: ");
//						stadium = input.nextLine();
//					}
//					System.out.println("Department: ");
//					String dep = input.nextLine();
//					while(!Registration.isSportsCategoryValid(dep)){
//						System.out.println("Department: ");
//						dep = input.nextLine();
//					}
//					Admin.showTicketData(stadium, dep);
//					adminModule();
//				}break;
//				case 3: {
//					System.out.println("Enter Ticket Title: ");
//					String s= new String(input.nextLine());
//					admin.deleteTicketData(s);
//					adminModule();
//				}break;
//				case 4: {
//					System.out.println("com.Stadium: ");
//					String stadium = input.nextLine();
//					while(!Registration.isStadiumValid(stadium)){
//						System.out.println("com.Stadium: ");
//						stadium = input.nextLine();
//					}
//					System.out.println("Department: ");
//					String dep = input.nextLine();
//					while(!Registration.isSportsCategoryValid(dep)){
//						System.out.println("Department: ");
//						dep = input.nextLine();
//					}
//					admin.updateTicketData(stadium, dep);
//					adminModule();
//				}break;
//			}
//		}
//	}
//
//	private static void spectatorModule() throws Exception {
//		//com.Spectator Module comes here
//		System.out.println("Welcome specatotor");
//		int choice = -1;
////		do{
//			System.out.println("1. Buy Ticket\n2.Delete Ticket\n0: Close");
//			choice = input.nextInt();
//			input.nextLine();
////
////		}while(!(choice >= 1 && choice <4));
//			Spectator sp = new Spectator();
//			switch (choice){
//				case 1: {
//					System.out.println("com.Stadium: ");
//					String stadium = input.nextLine();
//					while(!Registration.isStadiumValid(stadium)){
//						System.out.println("Wrong com.Stadium");
//						Registration.stadiumsAre();
//						System.out.println("com.Stadium: ");
//						stadium = input.nextLine();
//					}
//					System.out.println("Department: ");
//					String dep = input.nextLine();
//					while(!Registration.isSportsCategoryValid(dep)){
//						System.out.println("Wrong Department");
//						Registration.sportDepsAre();
//						System.out.println("Department: ");
//						dep = input.nextLine();
//					}
//					boolean isTicketAvailable = Admin.showTicketData(stadium,dep);
//					if(isTicketAvailable){
//						String userN = new String(input.nextLine());
//						sp.buyTicket(stadium, dep, userN);
//					}
//					else{
//						System.out.println("No Ticket Is Generated Yet");
//					}
//					spectatorModule();
//				}break;
//				case 2: {
//					String stadium = input.nextLine();
//					while(!Registration.isStadiumValid(stadium)){
//						System.out.println("com.Stadium: ");
//						stadium = input.nextLine();
//					}
//					System.out.println("Department: ");
//					String dep = input.nextLine();
//					while(!Registration.isSportsCategoryValid(dep)){
//						System.out.println("Department: ");
//						dep = input.nextLine();
//					}
//					System.out.println("User Name: ");
//					String s = new String(input.nextLine());
//					sp.deleteTicket(stadium, dep, s);
//					spectatorModule();
//				}break;
//				case 0 : return;
//		}
//		return;
//	}
//	private static void athleteModule() throws Exception {
//		//Athlete Options Module--------------------------
//		String[] athleteOptions = {"1: Login","2: Register","3: Show All pakistan com.Stadium and Athletes","0: Exit"};
//		int athletehoice = -1;
//		do {
//			for(String i : athleteOptions) {
//				System.out.print("\n"+i);
//			}
//			try {
//				athletehoice = input.nextInt();
//			}catch(InputMismatchException e) {
//				System.out.print("\nInvalid input. Try with correct option\n");
//				continue;
//			}
//			switch(athletehoice) {
//			case 1: login();break;
//			case 2: register();break;
//			case 3: StadiumRegistrationDataBase.traverseThruFiles();break;
//			}
//		}while(athletehoice != 0);
//	}
//	//com.Registration---------
//	private static void register() throws Exception {
//		Registration register = new Registration();
//	}
//	private static void login() throws Exception {
//
//		//Login Method To Verify Validity of an ahlete
//		System.out.print("Enter Athlete ID: ");
//		String s = input.next();
//		System.out.print("Enter password: ");
//		String password = input.next();
//		Login login = new Login(s,password);
//
//
		//Deserealization Of an Objet
//		if(login.isValidUser()) {
//			//Deserialization after object has been logged in to his file
////			System.out.println("------ DeSearialization -------");
//			Stadium obj = getSerializedObject(s);
//
//
//		}
//		//You Are not registered not either your file is created
//		else {
//			System.out.print("You Are not registered");
//			return;
//		}
//	}
//
//	private static Stadium getSerializedObject(String s) throws IOException, ClassNotFoundException {
//		File f = new File(Registration.athletesSerializedFiles.getAbsolutePath()+"/"+s);
//		FileInputStream fileInputStream = new FileInputStream(f);
//		ObjectInputStream objectInputStream  = new ObjectInputStream(fileInputStream);
////		com.Stadium o = (com.Stadium)objectInputStream.readObject();
//		return (Stadium)objectInputStream.readObject();
	}
}

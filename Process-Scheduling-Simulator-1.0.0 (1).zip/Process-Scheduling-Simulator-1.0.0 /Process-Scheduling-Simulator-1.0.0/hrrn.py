
from scheduler import Scheduler


class HRRN(Scheduler):
    def run(self):
        cur_time = 0
        finish_processes_count = 0
        at_idx = 0
        sorted_processes = sorted(self.processes, key=lambda x: x.at)
        while finish_processes_count < self.process_count:
            # Put the process that matches the current time and AT to the queue
            for process_idx in range(at_idx, self.process_count):
                process = sorted_processes[process_idx]
                if process.at == cur_time:
                    print("process arrived - cur_time:", cur_time, " p_id :", process.id)
                    self.ready_queue.append(process)
                elif process.at > cur_time:  # Exit because there is no need to check any more
                    at_idx = process_idx
                    break

            # history record
            self.record_history(self.ready_queue[:], self.cpus, self.processes)

            for cpu in self.cpus:
                # If the cpu is finished, it saves the output of 
		# the finished process and allows the cpu to rest.
                if cpu.is_finished():
                    print("process finished - cur_time:", cur_time, " p_id :", cpu.process.id)
                    cpu.process.calculate_finished_process(cur_time)
                    finish_processes_count += 1
                    cpu.set_idle()

                # Select the next process. (The one with the highest response ratio among the queue queues)
                if cpu.is_idle():
                    if self.ready_queue:
                        max_response_ratio = float("-inf")
                        for process in self.ready_queue:
                            response_ratio = (process.wt + process.bt) / process.bt
                            if response_ratio > max_response_ratio:
                                max_response_ratio = response_ratio
                                next_process = process
                        self.ready_queue.remove(next_process)  # Delete the selected process from the queue queue
                        cpu.set_process(next_process)

            # ready_queue Add WT of all processes in
            for process in self.ready_queue:
                process.wt += 1

            # Increase current time by 1
            cur_time += 1
            super().work()

package com.RDs.FrontEnd.FacultyPortal;

import com.RDs.FrontEnd.Faculty;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.*;

public class FacultyProfileInfo extends JPanel {

    public JLabel jLabel;
    public JSpinner jSpinnerUpdate;
    JTextField jTextFieldUpdate;
    JButton jButtonSubmit, jButtonBack;


    public FacultyProfileInfo() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setAlignmentX(Component.CENTER_ALIGNMENT);
        setAlignmentY(Component.CENTER_ALIGNMENT);

        add(Box.createRigidArea(new Dimension(0, 100)));


        jLabel = new JLabel("", SwingConstants.CENTER);

        add(jLabel);
        jLabel.setForeground(Color.WHITE);
        jLabel.setFont(new Font("Monotype Sort", Font.BOLD, 18));
        jLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        jLabel.setAlignmentY(Component.CENTER_ALIGNMENT);

        add(Box.createRigidArea(new Dimension(0, 20)));


        JLabel update = new JLabel("Update: ", SwingConstants.CENTER);
        update.setFont(new Font("Monotype Sort", Font.BOLD, 18));
        update.setAlignmentX(Component.CENTER_ALIGNMENT);
        update.setAlignmentY(Component.CENTER_ALIGNMENT);
        add(update);
        update.setForeground(Color.WHITE);
        add(Box.createRigidArea(new Dimension(0, 10)));

        jSpinnerUpdate = new JSpinner(new SpinnerListModel(new String[]{"Full Name", "Email Address"}));
        add(jSpinnerUpdate);
        jSpinnerUpdate.setMaximumSize(new Dimension(440, 45));
        add(Box.createRigidArea(new Dimension(0, 10)));

        jTextFieldUpdate = new JTextField();
        add(jTextFieldUpdate);
        jTextFieldUpdate.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldUpdate.setFont(new Font("Monotype Sort", Font.BOLD, 13));
        jTextFieldUpdate.setMaximumSize(new Dimension(440, 45));

        add(Box.createRigidArea(new Dimension(0, 10)));

        jButtonBack = new JButton("BACK");
        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(440, 45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);


        jButtonSubmit = new JButton("SUBMIT");
        jButtonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonSubmit.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonSubmit.setForeground(Color.GRAY);
        jButtonSubmit.setMaximumSize(new Dimension(440, 45));
        jButtonSubmit.setBorderPainted(false);
        jButtonSubmit.setBackground(Color.WHITE);
        jButtonSubmit.setFocusable(false);

        add(jButtonSubmit);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(jButtonBack);

        jTextFieldUpdate.setText("Enter Value");


        jButtonSubmit.addActionListener(e -> {

            if (String.valueOf(jSpinnerUpdate.getValue()).equalsIgnoreCase("Email Address")) {

                if (!jTextFieldUpdate.getText().equalsIgnoreCase("Enter Value") && !jTextFieldUpdate.getText().isEmpty() &&
                        jTextFieldUpdate.getText().endsWith("@gmail.com")) {
                    try {
                        if (new Faculty().updateEmailAddress(jTextFieldUpdate.getText())) {

                            JOptionPane.showMessageDialog(this, "Email Address Updated Successfully");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }

                } else {
                    JOptionPane.showMessageDialog(this, "Email Address Not Updated Successfully");
                }
            } else if (String.valueOf(jSpinnerUpdate.getValue()).equalsIgnoreCase("Full Name")) {
                // for first name last name
                if (!jTextFieldUpdate.getText().equalsIgnoreCase("Enter Value") && !jTextFieldUpdate.getText().isEmpty() &&
                        !jTextFieldUpdate.getText().endsWith("@gmail.com")) {
                    try {
                        if (new Faculty().updateFullName(jTextFieldUpdate.getText())) {

                            JOptionPane.showMessageDialog(this, "Full Name Updated Successfully");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }

                } else {
                    JOptionPane.showMessageDialog(this, "Full Name Not Updated Successfully");
                }
            }

            try {
                facultyProfileInfo.jLabel.setText(new Faculty().getProfileInfo());
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        jButtonBack.addActionListener(e -> {
            setVisible(false);
            facultyHomePage.setVisible(true);
        });


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Student/studentPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }


}

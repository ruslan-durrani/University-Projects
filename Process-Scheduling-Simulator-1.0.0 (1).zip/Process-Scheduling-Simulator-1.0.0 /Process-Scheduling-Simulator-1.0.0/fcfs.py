
from scheduler import Scheduler


class FCFS(Scheduler):
    def run(self):
        cur_time = 0
        finish_processes_count = 0
        at_idx = 0
        sorted_processes = sorted(self.processes, key=lambda x: x.at)

        # It runs until the number of finished processes equals the total number of processes.

        while finish_processes_count < self.process_count:
            # queue the process to arrive at the current time
            for process_idx in range(at_idx, self.process_count):
                process = sorted_processes[process_idx]
                if process.at == cur_time:
                    print("process arrived - cur_time:", cur_time, " p_id :", process.id)
                    self.ready_queue.append(process)
                elif process.at > cur_time:
                    at_idx = process_idx
                    break

            # record history
            self.record_history(self.ready_queue[:], self.cpus, self.processes)

            # spinning the cpu
            for cpu in self.cpus:
                # when the cpu is done
                if cpu.is_finished():

                    # When the process completes, each time is calculated based on the current time.

                    # Increase the number of finished processes by 1

                    print("process finished - cur_time:", cur_time, " p_id :", cpu.process.id)
                    cpu.process.calculate_finished_process(cur_time)
                    finish_processes_count += 1

                    # After work, the CPU is allowed to rest.

                    cpu.set_idle()

		# cpu is resting
                
        if cpu.is_idle():
		
		# If there is more than one process in the queue
                    if self.ready_queue:
                        cpu.set_process(self.ready_queue.pop(0))

		# Increase current time
        super().work()
        cur_time += 1

package junaid.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {

//    public static MainPagePanel mainPagePanel = new MainPagePanel();

    JPanel mainPagePanel;
    JButton manager, customer;

    public MainFrame() throws HeadlessException {

        setSize(500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
//        setLayout(null);

        mainPagePanel = new JPanel(); // like container you have to treat it like Frame set its everything
        mainPagePanel.setVisible(true);
        add(mainPagePanel);
        mainPagePanel.setBackground(Color.gray);
        setVisible(true);
        mainPagePanel.setLayout(new BoxLayout(mainPagePanel,BoxLayout.Y_AXIS)); // layout line linear layout with orientation vertical

        mainPagePanel.add(Box.createRigidArea(new Dimension(0,200))); // like padding or margin // chashmish isko khtm krdena phr jidr space chora hain waha icon lgadena apna
        manager = new JButton("MANAGER");
        manager.setVisible(true);
        manager.setAlignmentX(Component.CENTER_ALIGNMENT);
        manager.setMaximumSize(new Dimension(180,40));
        manager.setBackground(Color.WHITE); // meri adhi biwi isko phr change krlena
        manager.setFont(new Font("Monotype Sort",Font.BOLD,12));
        manager.setBorderPainted(false);
        mainPagePanel.add(manager);
        manager.setFocusable(false);
        mainPagePanel.add(Box.createRigidArea(new Dimension(0,12))); // margin 12 smja kr russi brwe ki kasm

        customer = new JButton("CUSTOMER");
        customer.setVisible(true);
        mainPagePanel.add(customer);
        customer.setAlignmentX(Component.CENTER_ALIGNMENT);
        customer.setMaximumSize(new Dimension(180,40));
        customer.setBackground(Color.WHITE);
        customer.setFont(new Font("Monotype Sort",Font.BOLD,12));
        customer.setBorderPainted(false);
        customer.setFocusable(false);
        mainPagePanel.add(Box.createRigidArea(new Dimension(0,12)));



        manager.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // perform actions here bro e,g agr manager pr click kya toh is panel ko disable krde or jo dusra panel hain usko visible krde

            }
        });

        customer.addActionListener(e-> { // lambda expression bitch harami mukhtar doesnt know

        });
    }



    public static void main(String[] args) {
        new MainFrame();
    }
}

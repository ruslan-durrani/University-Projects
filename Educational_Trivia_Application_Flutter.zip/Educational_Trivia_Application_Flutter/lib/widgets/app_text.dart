import 'package:flutter/cupertino.dart';
import 'package:ardies_trivia_application/misc/colors.dart';
import 'dart:ui';
class AppText extends StatelessWidget {
  double size ;
  String text  ;
  // Colors color ;
  AppText({Key? key,
    required this.text ,
    required this.size
    // required this.color ,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
        text,
        style:TextStyle(
            fontSize: size,
            fontWeight:FontWeight.normal
        )
    );
  }
}

import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
class ViewLessons extends StatefulWidget {
  const ViewLessons({Key? key}) : super(key: key);

  @override
  State<ViewLessons> createState() => _ViewLessonsState();
}

class _ViewLessonsState extends State<ViewLessons> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.orange,
            ),
          ),
          title: Padding(
            padding: EdgeInsets.all(7),
            child: Text("Hello Ardie!",style: TextStyle(color: Colors.grey),),
          ),
          centerTitle: false,
          elevation: 0.0,
          backgroundColor: Colors.grey.shade50,

        ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(

            children: [
        Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "What is Foreign Policy",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Imran Khan",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/book-3.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Litreature",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Qasim Durrani",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/learn.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Psychology",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Maria Farooq",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/girl.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Rights & Welfares",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Ahsan Kausar",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/boy.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Islam and Islamophobia",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Imran Khan",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/book-1.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Dedication | Prevasiveness",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Ardies Students",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/teacher.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
      Container(
        margin: EdgeInsets.all(10),
        height: 80,
        width: double.maxFinite,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(38.5),
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 10),
              blurRadius: 33,
              color: Color(0xFFD3D3D3).withOpacity(.84),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(38.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 30, right: 20),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.end,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "A Hollow Man",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Eliot",
                              style: TextStyle(
                                color: kLightBlackColor,
                              ),
                            ),
                            Align(
                              alignment:
                              Alignment.bottomRight,
                              child: Text(
                                "Chapter 7 of 10",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: kLightBlackColor,
                                ),
                              ),
                            ),
                            SizedBox(height: 5),
                          ],
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(38.5),
                        child: Image.asset(
                          "img/book-3.png",
                          width: 55,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 7,
                width: 20,
                decoration: BoxDecoration(
                  color: kProgressIndicator,
                  borderRadius: BorderRadius.circular(7),
                ),
              ),
            ],
          ),
        ),
      ),
    ],
        ),
      )
      );
  }
}

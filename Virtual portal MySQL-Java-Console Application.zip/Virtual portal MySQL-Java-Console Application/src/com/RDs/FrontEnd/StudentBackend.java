package com.RDs.FrontEnd;

import com.RDs.Database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StudentBackend extends Database {
    public static String registrationNumber;
    public ArrayList<ArrayList<String>> registeredCourses = new ArrayList<>();
    private final ArrayList<String> arrayTokenID = new ArrayList<>();
    public static String[] tokenID;

    public StudentBackend() throws SQLException {

    }

    public boolean validateStudent(String registrationNumber, String password) {
        String validationQuery = "SELECT * FROM Students";

        try {
            ResultSet rs = stmt.executeQuery(validationQuery);

            while (rs.next()) {
                //rollnumber, password_, first_name, last_name, email_address, departmentName, programName, semester, isRegistered
                String regNumber = rs.getString("rollnumber");
                String password_ = rs.getString("password_");
                boolean isRegistered = rs.getBoolean("isRegistered");

                if (isRegistered) {
                    if (registrationNumber.equals(regNumber) && password.equals(password_)) {
                        StudentBackend.registrationNumber = regNumber;
//                        System.out.println(this.registrationNumber);
                        return true;

                    }
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;

    }

    public String getProfileInfo() {
        //rollnumber, password_, first_name, last_name, email_address, departmentName, programName, semester, isRegistered
        StringBuilder desc = new StringBuilder();
//        String[] temp = new String[8];


        String validationQuery = "SELECT * FROM Students";
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            while (rs.next()) {
                String registrationNumber = rs.getString("rollnumber");
                String firstName = "First Name: " + rs.getString("first_name");
                String lastName = "Last Name: " + rs.getString("last_name");
                String emailAddress = "Email Address: " + rs.getString("email_address");
                String departmentName = "Department Name: " + rs.getString("departmentName");
                String programName = "Program Name: " + rs.getString("programName");
                String semester = "Semester: " + rs.getString("semester");

                if (StudentBackend.registrationNumber.equals(registrationNumber)) {

                    desc.append("<html><br>");
                    desc.append("Registration Number: ").append(registrationNumber).append("<br>").append(firstName).append("<br>").append(lastName).append("<br>").append(emailAddress).append("<br>").append(departmentName).append("<br>").append(programName).append("<br>").append(semester);
                    desc.append("</html>");
                    return desc.toString();
                }


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return desc.toString();


    }


    public boolean updateEmailAddress(String emailAddress) {
        String validation = "UPDATE Students SET email_address = '" + emailAddress + "' WHERE rollnumber = '" + StudentBackend.registrationNumber + "'";

        try {
            stmt.executeUpdate(validation);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFirstName(String firstName) {
        String validation = "UPDATE Students SET first_name = '" + firstName + "' WHERE rollnumber = '" + StudentBackend.registrationNumber + "'";

        try {
            stmt.executeUpdate(validation);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateLastName(String lastName) {
        String validation = "UPDATE Students SET last_name = '" + lastName + "' WHERE rollnumber = '" + StudentBackend.registrationNumber + "'";

        try {
            stmt.executeUpdate(validation);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String[][] registeredCourses() {

        String validation = "SELECT * FROM Students NATURAL JOIN SemesterCourses NATURAL JOIN Courses NATURAL JOIN Programs NATURAL JOIN Faculty NATURAL JOIN FacultyCourses WHERE rollnumber = '" + StudentBackend.registrationNumber + "' AND validate = 1";
        try {
            ResultSet rs = stmt.executeQuery(validation);
            int count = 0;

            while (rs.next()) {
                String courseName = rs.getString("courseName");
                String programName = rs.getString("programName");
                String facultyID = rs.getString("facultyID");
                String semester = rs.getString("semester");
                String facultyName = rs.getString("facultyName");
//                String registrationNumber = rs.getString("rollnumber");
                boolean flag = false;

                if (registeredCourses.isEmpty()) {
                    registeredCourses.add(new ArrayList<>());
                    registeredCourses.get(0).add(programName);
                    registeredCourses.get(0).add(courseName);
                    registeredCourses.get(0).add(semester);
                    registeredCourses.get(0).add(facultyName);
                    registeredCourses.get(0).add(facultyID);
                    System.out.println(registeredCourses.size() + " : " + registeredCourses.get(count).size());

                } else {
//                    System.out.println(registeredCourses.size() + " : " + registeredCourses.get(count).size());
                    for (int i = 0; i < registeredCourses.size(); i++) {
                        if (registeredCourses.get(i).contains(courseName)) {
                            flag = true;
                            break;
                        }
                    }

                    if (!flag) {
                        count++;
//                        System.out.println(count);
                        registeredCourses.add(new ArrayList<>());
                        registeredCourses.get(count).add(programName);
                        registeredCourses.get(count).add(courseName);
                        registeredCourses.get(count).add(semester);
                        registeredCourses.get(count).add(facultyName);
                        registeredCourses.get(count).add(facultyID);

                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

//
//        for (int i=0; i<registeredCourses.size(); i++ ) {
//            for (int j=0; j<registeredCourses.get(i).size(); j++) System.out.println(registeredCourses.get(i).get(j));
//        }

        return convertArrayListToArray();
    }


    private String[][] convertArrayListToArray() {
        String[][] regCourses = new String[registeredCourses.size()][5];

        for (int i = 0; i < registeredCourses.size(); i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println(i + ":" + j);
                System.out.println(registeredCourses.get(i).get(j));
                regCourses[i][j] = registeredCourses.get(i).get(j);
            }
        }

        return regCourses;

    }

    public String studentHelpDesk() {
        String validation = "SELECT * FROM help_desk";
        StringBuilder desc = new StringBuilder();
        arrayTokenID.add("Select Token");

        try {
            ResultSet rs = stmt.executeQuery(validation);
            desc.append("<html>");

            while (rs.next()) {

                // tokenID, rollnumber, student_query, respondedQuery, facultyID
                String tokenID = rs.getString("tokenID");
                String rollNumber = rs.getString("rollnumber");
                String studentQuery = rs.getString("student_query");
                String respondedQuery = rs.getString("respondedQuery");
                String facultyID = rs.getString("facultyID");
                desc.append("Token ID: ").append(tokenID).append("<br>").append("Registration Number: ").append("<br>").append(rollNumber);
                desc.append("<br>").append("Student Query: ").append(studentQuery).append("<br>").append("Responded Query: ").append(respondedQuery);
                arrayTokenID.add(tokenID);

                if (!(facultyID == null)) {
                    desc.append("<br>").append("Faculty ID: ").append(facultyID);
                }
                else {
                    desc.append("<br><br>");
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        desc.append("</html>");

        return desc.toString();
    }



    public boolean postStudentMessage(String message) {
        String sql = "INSERT INTO Help_desk (rollnumber, student_query) VALUES (?, ?)";

        try {
            PreparedStatement preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setString(1,registrationNumber);
            preparedStmt.setString(2,message);
            preparedStmt.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  false;

    }


    public String[] getDepartment() {
        String sql = "SELECT * FROM Departments";
        ArrayList<String> arr = new ArrayList<>();
        ResultSet rs = null;
        String[] str = null;
        try {
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String department = rs.getString("departmentName");
                arr.add(department);
            }

            str = new String[arr.size()];
            for (int i=0; i<arr.size(); i++) {
                str[i] = arr.get(i);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return str;
    }

    public String[] retrievePrograms(String department) {
        String sql = "SELECT * FROM Departments NATURAL JOIN DepartmentConsists NATURAL JOIN Programs WHERE departmentName= '" + department +  "'";
        ArrayList<String> arrayList = new ArrayList<>();
        String[] programs = new String[0];

        try {

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                String program_ = rs.getString("programName");

                arrayList.add(program_);

            }

            programs = new String[arrayList.size()];
            for (int i=0; i<arrayList.size(); i++){
                programs[i] = arrayList.get(i);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return programs;


    }


    public boolean studentRegistration(String firstName, String lastName, String registrationNumber, String department, String program, String semester, String password, String emailAddress) {

        String sql = "INSERT INTO Students (first_name, last_name, rollnumber, departmentName, programName, semester, password_, email_address) VALUES (?,?,?,?,?,?,?,?)" ;

        try {
            PreparedStatement preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setString(1,firstName);
            preparedStmt.setString(2,lastName);
            preparedStmt.setString(3,registrationNumber);
            preparedStmt.setString(4,department);
            preparedStmt.setString(5,program);
            preparedStmt.setString(6,semester);
            preparedStmt.setString(7,password);
            preparedStmt.setString(8,emailAddress);
            preparedStmt.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }


}

package com.RDs.FrontEnd.FacultyPortal;

import com.RDs.FrontEnd.Faculty;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

//import static com.RDs.FrontEnd.FacultyPortal.AddStudentMarks.jSpinnerProgramP;
import static com.RDs.FrontEnd.FacultyPortal.StudentInfo.jSpinnerProgram;
import static com.RDs.FrontEnd.SplashScreen.*;

public class FacultyHomePage extends JPanel {

    JButton jButtonProfileInfo, jButtonManageStd, jButtonStdResults, jButtonHelpDesk, jButtonLogout,jButtonMarks;
    String[] retrieveProgram;


    public FacultyHomePage() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);

        add(Box.createRigidArea(new Dimension(0,100)));

        jButtonProfileInfo = new JButton("PROFILE INFO");
        add(jButtonProfileInfo);
        jButtonProfileInfo.setBackground(Color.WHITE);
        jButtonProfileInfo.setBorderPainted(false);
        jButtonProfileInfo.setFocusable(false);
        jButtonProfileInfo.setForeground(Color.GRAY);
        jButtonProfileInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonProfileInfo.setMaximumSize(new Dimension(200,45));
        jButtonProfileInfo.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonManageStd = new JButton("ASSIGNED STUDENTS");
        add(jButtonManageStd);
        jButtonManageStd.setBackground(Color.WHITE);
        jButtonManageStd.setBorderPainted(false);
        jButtonManageStd.setFocusable(false);
        jButtonManageStd.setForeground(Color.GRAY);
        jButtonManageStd.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonManageStd.setMaximumSize(new Dimension(200,45));
        jButtonManageStd.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonMarks = new JButton("ADD STUDENT MARKS");
        add(jButtonMarks);
        jButtonMarks.setBackground(Color.WHITE);
        jButtonMarks.setBorderPainted(false);
        jButtonMarks.setFocusable(false);
        jButtonMarks.setForeground(Color.GRAY);
        jButtonMarks.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonMarks.setMaximumSize(new Dimension(200,45));
        jButtonMarks.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonStdResults = new JButton("STUDENT RESULT");
        add(jButtonStdResults);
        jButtonStdResults.setBackground(Color.WHITE);
        jButtonStdResults.setBorderPainted(false);
        jButtonStdResults.setFocusable(false);
        jButtonStdResults.setForeground(Color.GRAY);
        jButtonStdResults.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonStdResults.setMaximumSize(new Dimension(200,45));
        jButtonStdResults.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonHelpDesk = new JButton("HELP DESK");
        add(jButtonHelpDesk);
        jButtonHelpDesk.setBackground(Color.WHITE);
        jButtonHelpDesk.setBorderPainted(false);
        jButtonHelpDesk.setFocusable(false);
        jButtonHelpDesk.setForeground(Color.GRAY);
        jButtonHelpDesk.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonHelpDesk.setMaximumSize(new Dimension(200,45));
        jButtonHelpDesk.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonLogout = new JButton("LOG OUT");
        add(jButtonLogout);
        jButtonLogout.setBackground(Color.WHITE);
        jButtonLogout.setBorderPainted(false);
        jButtonLogout.setFocusable(false);
        jButtonLogout.setForeground(Color.GRAY);
        jButtonLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonLogout.setMaximumSize(new Dimension(200,45));
        jButtonLogout.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jButtonLogout.addActionListener(e-> {

            int receive = JOptionPane.showConfirmDialog(this,"Would you like to log out?","LOG OUT", JOptionPane.YES_NO_OPTION);
            if (receive == 0) {
                setVisible(false);
                facultyLogin.setVisible(true);
            }
        });

        jButtonHelpDesk.addActionListener(e-> {
            setVisible(false);
            facultyHelpDesk.setVisible(true);
        });

        jButtonManageStd.addActionListener(e-> {
            setVisible(false);
            studentInfo.setVisible(true);
            try {
                Faculty faculty = new Faculty();
                jSpinnerProgram.setModel(new SpinnerListModel(faculty.retrieveProgram()));


            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        });

        jButtonMarks.addActionListener(e-> {
            Faculty faculty = null;
            try {
                faculty = new Faculty();
                addStudentMarks.jSpinnerProgramP.setModel(new SpinnerListModel(faculty.retrieveProgram()));
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        jButtonMarks.addActionListener(e-> {
            setVisible(false);
            addStudentMarks.setVisible(true);

        });

        jButtonStdResults.addActionListener(e-> {
            try {
                Faculty faculty = new Faculty();
                showStudentMarks.jSpinnerProgramP.setModel(new SpinnerListModel(faculty.retrieveProgram()));
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            setVisible(false);
            showStudentMarks.setVisible(true);
        });

        jButtonProfileInfo.addActionListener(e-> {
            setVisible(false);
            facultyProfileInfo.setVisible(true);
            try {
                facultyProfileInfo.jLabel.setText(new Faculty().getProfileInfo());
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });





    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/FacultyPortal/facultyPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }
}

import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:no_hassel/Models/dyslexia.dart';

import 'Mesages.dart';
import 'SightSaver.dart';

class Favourites extends StatefulWidget {
  const Favourites({Key? key}) : super(key: key);

  @override
  State<Favourites> createState() => _FavouritesState();
}

class _FavouritesState extends State<Favourites> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Favourites",
          style: TextStyle(
              fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal,
              fontSize: 18),
        ),
        backgroundColor: Colors.deepOrange,
      ),
      body: ListView(
        children: [
          ...List.generate(10, (index) {
            return Container(
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(
                  color: Colors.red, // Border color
                  width: 2.0, // Border width
                ),
              ),
              child: ListTile(
                contentPadding: EdgeInsets.all(5),
                selectedColor: Colors.green,
                leading: const CircleAvatar(
                  radius: 18,
                  backgroundImage: AssetImage(
                      '/Users/russi7kd/StudioProjects/no_hassel/assets/img/Dr_Madni.jpg'), // Replace with your image path
                ),
                title: Text(
                  "This is title description",
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.w400,
                      color: Colors.black),
                ),
                subtitle: Text(
                  "This is sub title",
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.w400,
                      color: Colors.black),
                ),
                trailing: Column(
                  children: [
                    Icon(
                      Icons.read_more_sharp,
                      color: Colors.deepOrange,
                      size: 20,
                    ),
                    Text(
                      "Read Again",
                      style: TextStyle(
                          fontWeight:
                              Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                          fontSize: 10),
                    ),
                  ],
                ),
              ),
            );
          })
        ],
      ),
      floatingActionButton: SpeedDial(
        backgroundColor: Colors.purpleAccent,
        foregroundColor: Colors.white,
        animatedIcon: AnimatedIcons.menu_close,
        children: [
          SpeedDialChild(
            child: Icon(Icons.view_list_outlined),
            label: 'Screen Reader',
            onTap: () {
              // Handle Email icon press
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.chat),
            label: 'Chat',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Messages(),
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.share_arrival_time_outlined),
            label: 'Read Aloud',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.insights),
            label: 'Sight Saver',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

import 'package:date_field/date_field.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:gymzilla/pages/update.dart';

class UpdateDetails extends StatefulWidget {
  var gymnastKey;
  UpdateDetails({required this.gymnastKey});
  @override
  State<UpdateDetails> createState() => _UpdateDetailsState();
}

class _UpdateDetailsState extends State<UpdateDetails> {
  // bool isChecked = false.obs as bool;
  final nameController = TextEditingController();
  final ageController = TextEditingController();
  final contactNumberController = TextEditingController();
  final addressController = TextEditingController();
  final paymentController = TextEditingController();
  var dateTimeController;
  late DatabaseReference dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref().child("Gymnasts");
    getGymnastData();
  }

  getGymnastData() async {
    DataSnapshot snapshot = (await dbRef.child(widget.gymnastKey).get());
    Map gymnastData = snapshot.value as Map;
    print(gymnastData);
    nameController.text = gymnastData["title"];
    ageController.text = gymnastData["age"];
    contactNumberController.text = gymnastData["contactNumber"];
    addressController.text = gymnastData["address"];
    paymentController.text = "";
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    nameController.dispose();
    ageController.dispose();
    contactNumberController.dispose();
    addressController.dispose();
    paymentController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text("Update Gymnast"),
        leading: InkWell(
            onTap: () {
              Get.back();
            },
            child: Icon(Icons.arrow_back)),
      ),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(15.w),
          child: SingleChildScrollView(
            child: Form(
              child: Column(
                children: <Widget>[
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      icon: Icon(Icons.person),
                      hintText: 'What do people call you?',
                      labelText: 'Name *',
                    ),
                    onSaved: (String? value) {
                      // This optional block of code can be used to run
                      // code when the user saves the form.
                    },
                    validator: (String? value) {
                      return (value != null && value.contains('@'))
                          ? 'Do not use the @ char.'
                          : null;
                    },
                  ),
                  SizedBox(height: 25.h),
                  TextFormField(
                    controller: ageController,
                    decoration: const InputDecoration(
                      icon: Icon(Icons.access_time_filled),
                      hintText: 'How old are you?',
                      labelText: 'Age *',
                    ),
                    onSaved: (String? value) {
                      // This optional block of code can be used to run
                      // code when the user saves the form.
                    },
                    validator: (String? value) {
                      return (value != null && value.contains('@'))
                          ? 'Do not use the @ char.'
                          : null;
                    },
                  ),
                  SizedBox(height: 25.h),
                  TextFormField(
                    controller: contactNumberController,
                    decoration: const InputDecoration(
                      icon: Icon(Icons.numbers),
                      hintText: 'What your contact number',
                      labelText: 'Contact Number *',
                    ),
                    onSaved: (String? value) {
                      // This optional block of code can be used to run
                      // code when the user saves the form.
                    },
                    validator: (String? value) {
                      return (value != null && value.length == 11)
                          ? 'Enter accurate number count'
                          : null;
                    },
                  ),
                  SizedBox(height: 25.h),
                  TextFormField(
                    controller: addressController,
                    decoration: const InputDecoration(
                      icon: Icon(Icons.home),
                      hintText: 'Where do you live',
                      labelText: 'Address *',
                    ),
                    onSaved: (String? value) {
                      // This optional block of code can be used to run
                      // code when the user saves the form.
                    },
                    validator: (String? value) {
                      return (value != null && value.length > 5)
                          ? 'Enter proper address'
                          : null;
                    },
                  ),
                  SizedBox(height: 25.h),
                  DateTimeFormField(
                    decoration: const InputDecoration(
                      hintStyle: TextStyle(color: Colors.black45),
                      errorStyle: TextStyle(color: Colors.redAccent),
                      border: OutlineInputBorder(),
                      suffixIcon: Icon(Icons.event_note),
                      labelText: 'Date of Joining',
                    ),
                    autovalidateMode: AutovalidateMode.always,
                    onDateSelected: (DateTime value) {
                      dateTimeController = value;
                    },
                  ),
                  SizedBox(height: 25.h),
                  TextFormField(
                    controller: paymentController,
                    decoration: const InputDecoration(
                      icon: Icon(Icons.home),
                      hintText: 'Payment made?',
                      labelText: 'Monthly Fee',
                    ),
                    onSaved: (String? value) {
                      // This optional block of code can be used to run
                      // code when the user saves the form.
                    },
                    validator: (String? value) {
                      return (value != null) ? 'Enter payment' : null;
                    },
                  ),
                  SizedBox(height: 25.h),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.green, onPrimary: Colors.white),
                      onPressed: () async {
                        try {
                          if (nameController.text != "") {
                            if (ageController.text != "") {
                              if (contactNumberController.text != "") {
                                if (addressController.text != "") {
                                  if (dateTimeController != null) {
                                    if (paymentController.text != "") {
                                      var obj = {
                                        "title": nameController.text,
                                        "age": ageController.text,
                                        "contactNumber":
                                            contactNumberController.text,
                                        "address": addressController.text,
                                        "day": dateTimeController.day,
                                        "month": dateTimeController.month,
                                        "year": dateTimeController.year,
                                        "amountPaid":
                                            paymentController.text.toString(),
                                      };
                                      dbRef
                                          .child(widget.gymnastKey)
                                          .update(obj);

                                      Get.snackbar(
                                          "Gymnast",
                                          nameController.text.toString() +
                                              " is Updated successfully");
                                      await Future.delayed(
                                              const Duration(seconds: 2))
                                          .then((value) => Get.to(Update()));
                                    } else {
                                      Get.snackbar("Payment",
                                          "Kindly receive monthly payment");
                                    }
                                  } else {
                                    Get.snackbar(
                                        "Date Time", "Date is not entered");
                                  }
                                } else {
                                  Get.snackbar(
                                      "Address", "Kindly fill up the address");
                                }
                              } else {
                                Get.snackbar("Contact Number",
                                    "Kindly enter contact number");
                              }
                            } else {
                              Get.snackbar("Age", "Kindly age gymnast age");
                            }
                          } else {
                            Get.snackbar("Name", "Kindly enter gymnast name");
                          }
                        } catch (e) {
                          print("Fcuked Up");
                        }
                      },
                      child: Padding(
                        padding: EdgeInsets.all(20.w),
                        child: Text(
                          "Update Gymnast",
                          style: TextStyle(
                              fontWeight: FontWeight.normal, fontSize: 21.sp),
                        ),
                      ))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

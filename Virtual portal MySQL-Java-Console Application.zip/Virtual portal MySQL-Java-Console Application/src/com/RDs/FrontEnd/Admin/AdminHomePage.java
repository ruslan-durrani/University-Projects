package com.RDs.FrontEnd.Admin;

import com.RDs.Portal_logic.Noticeboard;
import com.RDs.Portal_logic.Student;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.Admin.ManageNoticeboard.jTableNoticeboardDetail;
import static com.RDs.FrontEnd.Admin.ValidateStudent.jTableValidateStdDetail;
import static com.RDs.FrontEnd.SplashScreen.*;

public class AdminHomePage extends JPanel {

    JButton jButtonNoticeboard, jButtonValidateStudents, jButtonValidateFaculty, jButtonLogout;

    public AdminHomePage() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0,150)));

        jButtonNoticeboard = new JButton("Manage Noticeboard");

        jButtonNoticeboard.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonNoticeboard.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonNoticeboard.setForeground(Color.GRAY);
        jButtonNoticeboard.setMaximumSize(new Dimension(180,45));
        jButtonNoticeboard.setBorderPainted(false);
        jButtonNoticeboard.setBackground(Color.WHITE);
        jButtonNoticeboard.setFocusable(false);

        add(jButtonNoticeboard);

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonValidateStudents = new JButton("Validate Students");

        jButtonValidateStudents.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonValidateStudents.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonValidateStudents.setForeground(Color.GRAY);
        jButtonValidateStudents.setMaximumSize(new Dimension(180,45));
        jButtonValidateStudents.setBorderPainted(false);
        jButtonValidateStudents.setBackground(Color.WHITE);
        jButtonValidateStudents.setFocusable(false);

        add(jButtonValidateStudents);

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonLogout = new JButton("Log Out");

        jButtonLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonLogout.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonLogout.setForeground(Color.GRAY);
        jButtonLogout.setMaximumSize(new Dimension(180,45));
        jButtonLogout.setBorderPainted(false);
        jButtonLogout.setBackground(Color.WHITE);
        jButtonLogout.setFocusable(false);

        add(jButtonLogout);



        jButtonLogout.addActionListener(e -> {

            int receive = JOptionPane.showConfirmDialog(null,
                    "Do you want to proceed?", "Log out",JOptionPane.YES_NO_OPTION);
            if(receive == 0) {
                setVisible(false);
                administrationLogin.setVisible(true);
            }

        });


        jButtonNoticeboard.addActionListener(e-> {
            manageNoticeboard.setVisible(true);
            setVisible(false);
            try {
                String[] detailColumn = new String[]{"ID", "Description", "Posted By"};
                jTableNoticeboardDetail.setModel(new DefaultTableModel(new Noticeboard().fillTableNoticeboard(),detailColumn));
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });



        jButtonValidateStudents.addActionListener(e-> {
            setVisible(false);
            validateStudent.setVisible(true);
            String[][] studentDetail = null;

            Student student = null;
            try {
                student = new Student();
                studentDetail = student.fillStudentTable();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            String[] detailColumn = new String[]{"Roll Number","First Name", "Last Name", "Department", "Program", "Semester"};
            jTableValidateStdDetail.setModel(new DefaultTableModel(studentDetail,
                    detailColumn));



        });


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Admin/admin.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }
}
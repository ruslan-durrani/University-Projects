// CHECKED

package com.RDs.FrontEnd.Admin;

import com.RDs.Portal_logic.Administration;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;

import static com.RDs.FrontEnd.SplashScreen.*;


public class AdministrationLogin extends JPanel {

    JLabel jLabelUsername, jLabelPassword;
    JTextField jTextFieldUsername;
    JPasswordField jPasswordFieldPassword;
    JButton jButtonLogin, jButtonBack;

    JPanel jPanelUsername, jPanelPassword, jPanelButton;

    public AdministrationLogin() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000,800);

//        add(Box.createRigidArea(new Dimension(0,30)));

        add(Box.createRigidArea(new Dimension(0,100)));

        jPanelUsername = new JPanel();
        add(jPanelUsername);
        jPanelUsername. setOpaque(false);
        jPanelUsername.setVisible(true);
        jPanelUsername.setLayout(new BoxLayout(jPanelUsername,BoxLayout.X_AXIS));
        jPanelUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
//        jPanelUsername.setBackground(new Color(0xFF6200));


        jLabelUsername = new JLabel("USERNAME: ");

        jPanelUsername.add(jLabelUsername);
        jLabelUsername.setForeground(Color.WHITE);
        jLabelUsername.setFont(new Font("Monotype Sort",Font.BOLD,14));


        jPanelUsername.add(Box.createRigidArea(new Dimension(5,0)));

        jTextFieldUsername = new JTextField();
        jPanelUsername.add(jTextFieldUsername);
        jTextFieldUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldUsername.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldUsername.setMaximumSize(new Dimension(180,45));



        // PASSWORD PLACE

        add(Box.createRigidArea(new Dimension(0,20)));

        jPanelPassword = new JPanel();
        add(jPanelPassword);
        jPanelPassword.setVisible(true);
        jPanelPassword.setLayout(new BoxLayout(jPanelPassword,BoxLayout.X_AXIS));
        jPanelPassword.setOpaque(false);
        jPanelPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
//        jPanelPassword.setBackground(new Color(0xFF6200));

        jLabelPassword = new JLabel("PASSWORD: ");

        jPanelPassword.add(jLabelPassword);
        jLabelPassword.setForeground(Color.WHITE);
        jLabelPassword.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jPanelPassword.add(Box.createRigidArea(new Dimension(5,0)));

        jPasswordFieldPassword = new JPasswordField();
        jPanelPassword.add(jPasswordFieldPassword);
        jPasswordFieldPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPasswordFieldPassword.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jPasswordFieldPassword.setMaximumSize(new Dimension(180,45));

        add(Box.createRigidArea(new Dimension(0,20)));

        jPanelButton = new JPanel();
        add(jPanelButton);
        jPanelButton.setOpaque(false);
//        jPanelButton.setBackground(new Color(0xFF6200));
        jPanelButton.setLayout(new BoxLayout(jPanelButton,BoxLayout.X_AXIS));
        jPanelButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        jButtonLogin = new JButton("LOGIN");
        jPanelButton.add(jButtonLogin);
        jButtonLogin.setBackground(Color.WHITE);
        jButtonLogin.setBorderPainted(false);
        jButtonLogin.setFocusable(false);
        jButtonLogin.setForeground(Color.GRAY);
        jButtonLogin.setMaximumSize(new Dimension(130,45));
        jButtonLogin.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jPanelButton.add(Box.createRigidArea(new Dimension(10,0)));

        jButtonBack = new JButton("BACK");

        jPanelButton.add(jButtonBack);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setBorderPainted(false);
        jButtonBack.setFocusable(false);
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(130,45));
        jButtonBack.setFont(new Font("Monotype Sort",Font.BOLD,14));


        jButtonBack.addActionListener(e-> {
            mainPagePanel.setVisible(true);
            administrationLogin.setVisible(false);

        });
        jButtonLogin.addActionListener(e-> {

            String username = jTextFieldUsername.getText();
            String password = String.valueOf(jPasswordFieldPassword.getPassword());

            try {
                Administration admin = new Administration(username,password);
                boolean validate = admin.validate();

                if (validate) {
                    JOptionPane.showMessageDialog(this,"Logged In Successful");
                    setVisible(false);
                    adminHomePage.setVisible(true);
                    jTextFieldUsername.setText("");
                    jPasswordFieldPassword.setText("");

                }
                else {
                    JOptionPane.showMessageDialog(this,"Username or Password is incorrect.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        });

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Admin/admin.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }


}

import 'package:date_field/date_field.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:gymzilla/business%20login/Gymnast.dart';
import 'package:gymzilla/pages/track_detail.dart';

class Track extends StatefulWidget {
  const Track({Key? key}) : super(key: key);

  @override
  State<Track> createState() => _TrackState();
}

class _TrackState extends State<Track> {
  Query dbRef = FirebaseDatabase.instance.ref().child("Gymnasts");
  var searchController = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text("Track & View Gymnasts"),
        leading: InkWell(
          onTap: () {
            Get.back();
          },
          child: Icon(Icons.arrow_back),
        ),
      ),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(10.w),
          child: Column(
            children: <Widget>[
              Expanded(
                flex: 2,
                child: Column(
                  children: [
                    TextField(
                      onChanged: (v) {
                        print(v);
                        setState(() {
                          searchController = v.toString().toUpperCase();
                        });
                      },
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0.r),
                        ),
                        hintText: 'Search gymnast',
                        suffixIcon: IconButton(
                            icon: Icon(Icons.clear), onPressed: () {}),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(10.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          CircleAvatar(
                            radius: 4.r,
                            backgroundColor: Colors.red,
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          Text("Past due date"),
                          SizedBox(
                            width: 15.w,
                          ),
                          CircleAvatar(
                            radius: 4.r,
                            backgroundColor: Colors.green,
                          ),
                          SizedBox(
                            width: 5.w,
                          ),
                          Text("No Pending Dues"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 40.h),
              Expanded(
                flex: 10,
                child: Column(
                  children: <Widget>[
                    Flexible(
                      child: FirebaseAnimatedList(
                        query: dbRef,
                        itemBuilder: (BuildContext context,
                            DataSnapshot snapshot,
                            Animation<double> animation,
                            int index) {
                          Map gymnast = snapshot.value as Map;
                          print(gymnast);
                          gymnast["key"] = snapshot.key;
                          var gymnastObject = new Gymnast(
                            title: gymnast["title"],
                            age: gymnast["age"],
                            address: gymnast["address"],
                            day: gymnast["day"],
                            month: gymnast["month"],
                            year: gymnast["year"],
                            amountPaid: gymnast["amountPaid"],
                            contactNumber: gymnast["contactNumber"],
                          );
                          if ((gymnastObject.title
                                  .toString()
                                  .toUpperCase()
                                  .contains(searchController
                                      .toString()
                                      .toUpperCase())) ||
                              (gymnastObject.contactNumber
                                  .toString()
                                  .contains(searchController.toString()))) {
                            return ListTile(
                              onTap: () {
                                Get.to(TrackDetails(
                                    gymnastOptions: gymnastObject));
                              },
                              leading: Icon(
                                Icons.access_time_filled,
                                color: gymnastObject.isPending()
                                    ? Colors.red
                                    : Colors.green,
                              ),
                              title: Text(
                                gymnastObject.title.toString().toUpperCase(),
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 21.sp),
                              ),
                              subtitle: Text(
                                "Date: " +
                                    gymnastObject.day.toString() +
                                    "/" +
                                    gymnastObject.month.toString() +
                                    "/" +
                                    gymnastObject.year.toString(),
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.normal),
                              ),
                              trailing: Column(
                                children: [
                                  Text(
                                    "Age: " + gymnastObject.age.toString(),
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12),
                                  ),
                                ],
                              ),
                            );
                          } else {
                            return Container();
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

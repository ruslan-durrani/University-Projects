import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';
import 'package:ardies_trivia_application/categories/categoriesTutorials.dart';
class Educational extends StatefulWidget {
  const Educational({Key? key}) : super(key: key);

  @override
  State<Educational> createState() => _EducationalState();
}

class _EducationalState extends State<Educational> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.orange,
            ),
          ),
          title: Padding(
            padding: EdgeInsets.all(7),
            child: Text("Entertainment!",style: TextStyle(color: Colors.grey),),
          ),
          centerTitle: false,
          elevation: 0.0,
          backgroundColor: Colors.grey.shade50,

        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                margin: EdgeInsets.all(20),
                height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu1.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu2.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu3.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu4.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu5.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu6.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu7.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
              Container(
                  margin: EdgeInsets.all(20),
                  height: 220,
                decoration: BoxDecoration(
                    color: Colors.white60,
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(
                        image: AssetImage(
                            "img/edu8.png"
                        ),
                        fit: BoxFit.fill
                    )
                ),

              ),
            ],
          ),
        )
    );
  }
}

import 'dart:core';
import 'package:flutter/material.dart';
class deals {
  String _imageUrl;
  String _name;
  String _discount;

  deals(this._imageUrl, this._name, this._discount);

  String get discount => _discount;

  String get name => _name;

  String get imageUrl => _imageUrl;
}
class Tutorials extends StatefulWidget {
  const Tutorials({Key? key}) : super(key: key);
  @override
  State<Tutorials> createState() => _TutorialsState();
}

class _TutorialsState extends State<Tutorials> {
  List<String> name = [
    "img/l1.png",
    "img/l2.png",
    "img/l3.png",
    "img/l4.png"
  ];
  List<String> name_text = [
    "Live",
    "School",
    "Business",
    "Stock"
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back,
            color: Colors.deepOrangeAccent,
          ),
        ),
        title: Padding(
          padding: EdgeInsets.all(7),
          child: Text("Tutorials!",style: TextStyle(color: Colors.grey),),
        ),
        centerTitle: false,
        elevation: 0.0,
        backgroundColor: Colors.grey.shade50,
        actions: [
          Stack(
            children: [
              Container(
                margin: EdgeInsets.all(17),
                // padding: EdgeInsets.fromLTRB(7,14,16,01),
                child: InkWell(
                  child: Icon(
                    Icons.notifications_active_sharp,
                    color: Colors.grey,
                  ),
                  onTap: (){
                    Navigator.pushNamed(context, '/entertainment');
                  },
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  margin: EdgeInsets.all(17),
                  padding: EdgeInsets.fromLTRB(7,14,16,01),
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.height / 11,
            color: Colors.deepOrangeAccent,
            // color: Color(0xff2874F0),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.white,
                ),
                child: TextField(
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          /* Clear the search field */
                        },
                      ),
                      hintText: 'Search Tutorial, Education etc',
                      border: InputBorder.none),
                ),
              ),
            ),
          ),
          SizedBox(height: 15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for(int i = 0 ; i < 4 ; i++)
                
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    height: 60,
                    width: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: InkWell(
                      onTap: (){},
                      child: Column(
                        children: [
                          Image(image: AssetImage(name[i]),),
                          SizedBox(height: 5,),
                          Text(
                            name_text[i],
                            style: TextStyle(
                                fontSize: 9,
                                color: Colors.black
                            ),
                          ),
                        ],
                      ),
                    )
                  ),
                )

            ],
          ),
          SizedBox(height: 15,),
          Container(
            margin: EdgeInsets.only(left: 15,right: 15),
            child: InkWell(
              onTap: (){
                Navigator.pushNamed(context, '/entertainment');
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Entertainment!",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                  Container(
                    alignment: Alignment.center,
                    width: 55,
                    height: 25,
                    decoration: BoxDecoration(
                        color: Colors.orange,
                        borderRadius: BorderRadius.circular(20)
                    ),
                    child: Text("View",style: TextStyle(fontSize:16,color: Colors.white,fontWeight: FontWeight.w600),),
                  )

                ],
              ),
            ),
          ),
          SizedBox(height: 3,),
          Container(
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  offset: Offset(0, 10),
                  blurRadius: 33,
                  color: Color(0xFFD3D3D3).withOpacity(.84),
                ),
              ],
            ),
            child: Secondlist(),
          ),
          SizedBox(height: 10,),
          Container(
            margin: EdgeInsets.only(left: 15,right: 15),
            child: InkWell(
              onTap: (){
                Navigator.pushNamed(context, '/educational');
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Educational!",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                  Container(
                    alignment: Alignment.center,
                    width: 55,
                    height: 25,
                    decoration: BoxDecoration(
                        color: Colors.deepOrangeAccent,
                        borderRadius: BorderRadius.circular(20)
                    ),
                    child: Text("View",style: TextStyle(fontSize:16,color: Colors.white,fontWeight: FontWeight.w600),),
                  )

                ],
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  offset: Offset(0, 10),
                  blurRadius: 33,
                  color: Color(0xFFD3D3D3).withOpacity(.84),
                ),
              ],
            ),
            child: Container(
              height: 210,
                padding: EdgeInsets.only(top: 10,bottom: 30),
                child: ThirdList()
            ),
          ),

          Container(
            margin: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  offset: Offset(0, 10),
                  blurRadius: 33,
                  color: Colors.deepOrangeAccent,
                ),
              ],
            ),
            child: Fourthlist(),
          ),
        ],
      ),
    );
  }
}


class Firstlist extends StatefulWidget {
  @override
  _FirstlistState createState() => _FirstlistState();
}

class _FirstlistState extends State<Firstlist> {
  List<String> name = [
    "img/l1.png",
    "img/l2.png",
    "img/l3.png",
    "img/l4.png",
    "img/l5.png"
  ];

  buildItem(BuildContext context, int index) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      child: Image.asset(
        name[index],
        height: 100,
        width: 100,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      child: ListView.builder(
        itemCount: 8,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          return buildItem(context, index);
        },
      ),
    );
  }
}
class Secondlist extends StatefulWidget {
  @override
  _SecondlistState createState() => _SecondlistState();
}

class _SecondlistState extends State<Secondlist> {
  buildItem(BuildContext context, int index) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut1.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut2.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut8.png"

                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut3.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut4.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut5.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut6.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
              color: Colors.white60,
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: AssetImage(
                    "img/tut7.png"
                ),
                fit: BoxFit.fill
              )
            ),

          ),

        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(3),
      child: Container(
        height: MediaQuery.of(context).size.height / 4,
        child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return buildItem(context, index);
          },
        ),
      ),
    );
  }
}


class ThirdList extends StatefulWidget {
  const ThirdList({Key? key}) : super(key: key);

  @override
  State<ThirdList> createState() => _ThirdListState();
}

class _ThirdListState extends State<ThirdList> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu1.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu2.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu3.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu4.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu5.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu6.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu7.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),
          Container(
            margin: EdgeInsets.only(left: 20,top: 10),
            height: 290,
            width: 270,
            decoration: BoxDecoration(
                color: Colors.white60,
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(
                        "img/edu8.png"
                    ),
                    fit: BoxFit.fill
                )
            ),

          ),

        ],
      ),
    );;
  }
}

class Fourthlist extends StatefulWidget {
  @override
  _FourthlistState createState() => _FourthlistState();
}

class _FourthlistState extends State<Fourthlist> {
  List<deals> deal = <deals>[];

  @override
  void initState() {
    super.initState();
    addDealItem();
  }

  addDealItem() {
    // deal = List<deals>();
    deal.add(deals(
        "img/top1.png",
        'Coding & Tops',
        'Views 2+m'));
    deal.add(deals(
        "img/top2.png",
        'Business & Commerce',
        'Views 10+m'));
    deal.add(deals(
        "img/top3.png",
        'Top Inventions',
        'Views 5+m'));
    deal.add(deals(
        "img/top4.png",
        'Casuals',
        'Views 12+m'));
  }

  buildItem(BuildContext context, int index) {
    return Container(
      height: MediaQuery.of(context).size.height / 2.5,
      child: Column(
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.height / 6.5,
            width: MediaQuery.of(context).size.width / 4,
            child: Image.asset(deal[index].imageUrl),
          ),
          Text(
            '${deal[index].name}',
            style: TextStyle(fontSize: 15),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              '${deal[index].discount}',
              style: TextStyle(color: Colors.green),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      height: size.height / 1.6,
      child: Stack(
        children: <Widget>[
          Container(
            height: size.height / 1.7,
            color: Colors.deepOrangeAccent,
          ),
          Container(
            height: size.height / 7,
            width: size.width,
            alignment: Alignment.topCenter,
            child: Text(
              "Top Playlist",
              style: TextStyle(
                color: Colors.white60,
                fontWeight: FontWeight.bold
              ),
            )
          ),
          Positioned(
            top: MediaQuery.of(context).size.height / 65,
            child: Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Playlists of the Day',
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          ),
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.person,
                                color: Colors.white,
                              ),
                              Text(
                                'Over millions views',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 12),
                              )
                            ],
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.white),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text('View All'),
                          ),
                        ),
                      )
                    ],
                  ),
                  width: size.width,
                ),
                Container(
                  height: size.height / 1.75,
                  padding: EdgeInsets.only(left: 8, right: 8),
                  width: size.width,
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    color: Colors.white,
                    child: GridView.builder(
                      padding: EdgeInsets.all(10),
                      itemCount: 4,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return buildItem(context, index);
                      },
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}


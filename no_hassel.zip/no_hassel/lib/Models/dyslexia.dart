class Dyslexia {
  static bool on = false;
}

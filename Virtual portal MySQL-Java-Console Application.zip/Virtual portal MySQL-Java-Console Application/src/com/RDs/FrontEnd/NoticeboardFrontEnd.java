package com.RDs.FrontEnd;

import com.RDs.Portal_logic.Noticeboard;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class NoticeboardFrontEnd extends JPanel {


    JLabel jLabelDescription;

    public NoticeboardFrontEnd() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(600, 200);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        jLabelDescription = new JLabel();
        jLabelDescription.setForeground(Color.WHITE);
        add(jLabelDescription);
        jLabelDescription.setAlignmentX(Component.LEFT_ALIGNMENT);

        Noticeboard noticeboard = null;
        try {
            noticeboard = new Noticeboard();
            String notice_description = noticeboard.getNoticeBoard();
            jLabelDescription.setText(notice_description);
        } catch (SQLException e) {
            e.printStackTrace();
        }






    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/noticeboard.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }
}


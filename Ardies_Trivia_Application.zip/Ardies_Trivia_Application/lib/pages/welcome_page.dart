import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/widgets/app_bold_text.dart';
import 'package:ardies_trivia_application/widgets/app_text.dart';
import 'package:ardies_trivia_application/categories/categoryBooks.dart';
import 'dart:async';
import 'dart:core';
class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key}) : super(key: key);
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}
class _WelcomePageState extends State<WelcomePage> {
  List images = [
    "img/books.jpg",
    "img/lessons.jpg",
    "img/tutorials.jpg",
    "img/quiz.jpg"

  ];
  List Categories = [
    ["BOOKS","EDUCATIONAL | ACADEMICS", "\nImproves your focus, memory, empathy, \nand communication skills"],
    ["LESSON","LEARN LESSON","\nLesson is defined as to teach, instruct \nor discipline"],
    ["WATCH TUTORIALS","LEARN WITH VISUALS","\nIf you are stuck in a class,\n you could use a tutorial"],
    ["QUIZ","SELF ANALYSIS","\nA quick and informal assessment of \nstudent knowledge"]

  ];
  // enum functions(books,quiz,lessons,tutorials);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: Icon(
            Icons.help_outline_sharp,
          size: 45,
        ),
        elevation: 0.5,
        onPressed: (){
          Navigator.pushNamed(context, '/settings');
        },
        foregroundColor: Colors.deepOrangeAccent,
        backgroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: AppText(text: "Ardies Trivia",size: 22),
        backgroundColor: Colors.white,
        elevation: 1,
        foregroundColor: Colors.black,
      ),
        drawer: Drawer(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                UserAccountsDrawerHeader(
                  accountName: Text(
                    "Ardies Trivia User",
                    style: TextStyle(
                        color: Colors.black
                    ),
                  ),
                  accountEmail: Text(
                    "Comsats@outlook.com",
                    style: TextStyle(
                        color: Colors.black
                    ),
                  ),
                  decoration: BoxDecoration(color: Colors.white),
                  currentAccountPicture: new CircleAvatar(
                    backgroundColor: Colors.orange,
                    backgroundImage: AssetImage('img/comsats.jpeg'),
                    radius: 50.0,
                  ),
                  
                ),
                ListTile(
                  onTap: (){
                    Navigator.pushNamed(context, '/educational');
                  },
                  title: Text("Favourites",style: TextStyle(fontWeight: FontWeight.w600),),
                  trailing: Icon(
                    Icons.favorite,
                    color: Colors.grey,
                  ),
                ),
                ListTile(
                  onTap: (){
                    Navigator.pushNamed(context, '/settings');
                  },
                  title: Text("Settings",style: TextStyle(fontWeight: FontWeight.w600),),
                  trailing: Icon(
                    Icons.settings,
                    color: Colors.grey,
                  ),
                ),
            ListTile(
              onTap: (){
                Navigator.pushNamed(context, '/progress');
              },
              title: Text("Progress",style: TextStyle(fontWeight: FontWeight.w600),),
              trailing: Icon(
                Icons.grade,
                color: Colors.grey,
              ),
            ),
                Spacer(),
                Container(
                  height: 2,
                  width: 280,
                  color: Colors.grey.shade300,
                ),
                ListTile(
                  onTap: (){
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                  title: Text("Log out",style: TextStyle(fontWeight: FontWeight.w600),),
                  trailing: Icon(
                    Icons.logout,
                    color: Colors.grey,
                  ),
                ),
              ],

            ),
          ),
        ),
      
      body: PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: images.length,
          itemBuilder:(_,index){
            return Container(
                width: double.maxFinite,
                height: double.maxFinite,
                decoration: BoxDecoration(
                  // color: Colors.blue,
                  image: DecorationImage(
                      image: AssetImage(
                          images[index]
                      ),
                      fit: BoxFit.cover
                  ),
                ),
                child: Container(
                  margin: const EdgeInsets.only(top:140,left:20,right:20),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AppBoldText(text: Categories[index][0], size: 25),
                          AppText(text: Categories[index][1], size: 18),
                          Container(
                            padding: EdgeInsets.only(right: 20),
                            child: AppText(text: Categories[index][2], size: 13),
                          ),
                          SizedBox(height: 20,),
                          MaterialButton(
                            onPressed: (){
                              print(index);
                              if(index==0)Navigator.pushNamed(context,'/books');
                              else if(index == 1)Navigator.pushNamed(context,'/lessons');
                              else if(index == 2) Navigator.pushNamed(context,'/tutorials');
                              else if(index == 3)Navigator.pushNamed(context,'/quiz');
                            },
                            height: 50,
                            color: Colors.deepOrangeAccent,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                for(double i = 10 ; i < 25 ; i = i+5) Icon(
                                  Icons.arrow_forward_ios,
                                  size: i,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      Column(
                        children: List.generate(4, (indexDots){
                          return Container(
                            margin: EdgeInsets.only(bottom: 2),
                            width: 8,
                            height: index==indexDots?25:8,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: index==indexDots?Colors.deepOrangeAccent:Colors.grey ,
                            ),
                          );
                        }),
                      )
                    ],
                  ),
                )
            );
          }
      ),
      );
  }
}

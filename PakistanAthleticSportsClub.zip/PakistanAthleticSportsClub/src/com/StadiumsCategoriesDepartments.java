package com;

public interface StadiumsCategoriesDepartments {
    String[] PAK_STADIUM = {"Karachi", "KPK", "Islamabad", "Baluchistan"};
    String[] STADIUM_CATEGORIES  = {"Cricket", "Football", "Tennis", "Volley Ball", "Table Tennis"};

}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:no_hassel/Views/MyNavBar.dart';

import 'Views/home.dart';

void main() {
  runApp(NoHassel());
}

class NoHassel extends StatefulWidget {
  const NoHassel({Key? key}) : super(key: key);

  @override
  State<NoHassel> createState() => _NoHasselState();
}

class _NoHasselState extends State<NoHassel> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'No Hassel',
      theme: ThemeData(
        primaryColor: Colors.blue,
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: Colors.red,
        ),

        // Define the default font family.
        // Other theme properties like textTheme, buttonTheme, etc. can be defined here as well.
        // Modify the colors, typography, and other properties based on your requirements.
      ),
      home: MyNavBar(),
    );
  }
}

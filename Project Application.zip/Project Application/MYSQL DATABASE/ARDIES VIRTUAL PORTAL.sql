
DROP SCHEMA 
IF EXISTS Virtual_Portal ;
CREATE SCHEMA Virtual_Portal ; 
USE Virtual_Portal;


CREATE TABLE Students(
	rollnumber VARCHAR(100) primary key,
    password_ varchar(100) NOT NULL,
    first_name varchar(100) NOT NULL,
    last_name varchar(100) NOT NULL,
    email_address VARCHAR(100) NOT NULL,
    departmentName VARCHAR(100),
    programName VARCHAR(100),
    semester int DEFAULT 1,
    isRegistered boolean DEFAULT FALSE
);

CREATE TABLE Departments(
	departmentName VARCHAR(100) PRIMARY KEY,
    depProgramID VARCHAR(100)
);

CREATE TABLE DepartmentConsists(
	depProgramID VARCHAR(100),
    programName VARCHAR(100),
    PRIMARY KEY (depProgramID, programName)
);

CREATE TABLE Programs(
    programName VARCHAR(100) Primary Key,
    semesterCourseID VARCHAR(100) UNIQUE NOT NULL
);




CREATE TABLE SemesterCourses (
    semesterCourseID VARCHAR(100) NOT NULL,
    semester int NOT NULL,
    courseID VARCHAR(100) NOT NULL,
    PRIMARY KEY (semesterCourseID, semester)
);


CREATE TABLE Courses(
	courseName VARCHAR(100),
    courseID VARCHAR(100),
    PRIMARY KEY (courseID,courseName)
);



CREATE TABLE Faculty(
	facultyID varchar(100) PRIMARY KEY,
    facultyName VARCHAR(100) NOT NULL,
    email_address VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    departmentName VARCHAR(100),
    validate boolean default false
);


CREATE TABLE Results (
	rollnumber VARCHAR(100) ,
	courseName VARCHAR(100),
    semesterID int,
	course_score int default 0,
    PRIMARY KEY (rollnumber, courseName)
    

);


CREATE TABLE FacultyCourses(
	facultyID varchar(100),
    courseName varchar(100),
    PRIMARY KEY (facultyID, courseName)
);



CREATE TABLE Admin (
	admin_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    admin_password VARCHAR(100)
);
CREATE TABLE Verified(
	admin_id VARCHAR(100),
    rollnumber VARCHAR(100) UNIQUE,
    PRIMARY KEY (admin_id, rollnumber)
);
CREATE TABLE Help_desk(
	tokenID int PRIMARY KEY AUTO_INCREMENT,
    rollnumber VARCHAR(100),
    student_query VARCHAR(100),
    respondedQuery VARCHAR(100) DEFAULT "NOT RESPONDED YET" ,
    facultyID VARCHAR(100) DEFAULT null-- Responder
);

CREATE TABLE NoticeBoard(
	noticeID INT AUTO_INCREMENT PRIMARY KEY,
    notice_message VARCHAR(10000),
    admin_id VARCHAR(100),
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id)
);









ALTER TABLE Departments
ADD FOREIGN KEY (depProgramID) REFERENCES DepartmentConsists(depProgramID);
ALTER TABLE DepartmentConsists
ADD FOREIGN KEY (programName) REFERENCES Programs(programName); -- 


ALTER TABLE DepartmentConsists
ADD INDEX depProgramID_idx (depProgramID);


ALTER TABLE Courses
ADD INDEX coursesName_idx (courseName);

ALTER TABLE Students
ADD FOREIGN KEY Students(departmentName) references Departments(departmentName);
-- ALTER  TABLE Departments
-- ADD FOREIGN KEY Departments(programName) references Programs(programName);
ALTER TABLE Programs
ADD FOREIGN KEY Programs(semesterCourseID) references SemesterCourses(semesterCourseID);
ALTER TABLE SemesterCourses
ADD FOREIGN KEY SemesterCourses(courseID) references Courses(courseID);
ALTER TABLE Results
ADD FOREIGN KEY (rollnumber) REFERENCES Students(rollnumber);
ALTER TABLE FacultyCourses
ADD foreign key FacultyCourses(facultyID) references Faculty(facultyID);
ALTER TABLE Verified
ADD FOREIGN KEY (rollnumber) references Students(rollnumber),
ADD FOREIGN KEY (admin_id) references Admin(admin_id);
ALTER TABLE Help_desk
ADD FOREIGN KEY (rollnumber) REFERENCES Students(rollnumber),
ADD FOREIGN KEY (facultyID) REFERENCES Faculty(facultyID);
ALTER TABLE Students
ADD FOREIGN KEY (programName) REFERENCES Programs(programName);
ALTER TABLE Results
ADD FOREIGN KEY Results(courseName) REFERENCES Courses(courseName);
ALTER TABLE FacultyCourses
ADD foreign Key FacultyCourses(courseName) references Courses(courseName);



CREATE TABLE StudentsCourseTeachers(
	rollnumber VARCHAR(100) NOT NULL,
    courseName VARCHAR(100) NOT NULL,
    primary key (rollnumber, courseName),
    facultyID varchar(100)
);
ALTER TABLE StudentsCourseTeachers
ADD FOREIGN KEY (facultyID) REFERENCES Faculty(facultyID),
ADD FOREIGN KEY (courseName) REFERENCES Courses(courseName),
ADD FOREIGN KEY (rollnumber) REFERENCES Students(rollnumber);




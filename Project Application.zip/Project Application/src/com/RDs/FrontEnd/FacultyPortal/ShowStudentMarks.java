package com.RDs.FrontEnd.FacultyPortal;

import com.RDs.FrontEnd.Faculty;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.facultyHomePage;

public class ShowStudentMarks extends JPanel {

    public JSpinner jSpinnerProgramP;
    JTextField jTextFieldRegistrationNumber;
    JTable jTableDetails;
    JButton jButtonBack, jButtonSearch;

    public ShowStudentMarks() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0, 100)));

        jSpinnerProgramP = new JSpinner();
        jSpinnerProgramP.setMaximumSize(new Dimension(440,45));
        add(jSpinnerProgramP);




        add(Box.createRigidArea(new Dimension(0,20)));

        JPanel jPanelR = new JPanel();
        jPanelR.setLayout(new BoxLayout(jPanelR,BoxLayout.X_AXIS));
        add(jPanelR);
        jPanelR.setOpaque(false);

        jTextFieldRegistrationNumber = new JTextField();
        jTextFieldRegistrationNumber.setMaximumSize(new Dimension(210,45));
        jTextFieldRegistrationNumber.setMinimumSize(new Dimension(210,45));
        jPanelR.add(jTextFieldRegistrationNumber);

        add(Box.createRigidArea(new Dimension(0,20)));

        JPanel jPanel = new JPanel();

        add(jPanel);

        jPanel.setLayout(new BoxLayout(jPanel,BoxLayout.X_AXIS));

        jButtonSearch = new JButton("SEARCH");
        jButtonSearch.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonSearch.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonSearch.setForeground(Color.GRAY);
        jButtonSearch.setMaximumSize(new Dimension(180, 45));
        jButtonSearch.setBorderPainted(false);
        jButtonSearch.setBackground(Color.WHITE);
        jButtonSearch.setFocusable(false);
        jPanel.add(jButtonSearch);



        jButtonBack = new JButton("BACK");
        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(180, 45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);

        jPanel.add(jButtonBack);

        add(Box.createRigidArea(new Dimension(0,20)));


        jTableDetails = new JTable();

        jTableDetails = new JTable();

        add(jTableDetails);

        jTableDetails.getTableHeader().setReorderingAllowed(false);

        //email_address, departmentName, semester, programName, semesterCourseID, courseID, courseName, facultyID, facultyName, password, validate, rollnumber, password_, first_name, last_name, isRegistered

        String[] detailColumn = new String[]{"Registration Number","Full Name", "Semester","Department", "Program Name", "Course Name", "GPA Score" };

        jTableDetails.setModel(new DefaultTableModel(new String[][]{}, detailColumn));

        JScrollPane scrollPaneNoticeboard = new JScrollPane(jTableDetails,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPaneNoticeboard.setMaximumSize(new Dimension(1000, 400));
        scrollPaneNoticeboard.setBackground(new Color(0, 0, 0, 65));

        add(scrollPaneNoticeboard);

        jButtonSearch.addActionListener( e-> {
            try {
                Faculty faculty = new Faculty();
                faculty.retrieveProgram();
                String[][] data;
                if (!jTextFieldRegistrationNumber.getText().equalsIgnoreCase("Search By Registration Number") ||
                !jTextFieldRegistrationNumber.getText().equalsIgnoreCase("Search By Registration Number")) {
                    data = faculty.showSpecificStudentMarks(jTextFieldRegistrationNumber.getText(),String.valueOf(jSpinnerProgramP.getValue()));
                }
                else {
                    data = faculty.showAddStudentMarks(String.valueOf(jSpinnerProgramP.getValue()));
                }

                jTableDetails.setModel(new DefaultTableModel(data,detailColumn));

            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        });

        jButtonBack.addActionListener(e-> {
            setVisible(false);
            facultyHomePage.setVisible(true);
        });

        jTextFieldRegistrationNumber.setText("Search By Registration Number");

        jTextFieldRegistrationNumber.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldRegistrationNumber.setText("");
                super.mouseClicked(e);
            }
        });



    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/FacultyPortal/facultyPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }

}

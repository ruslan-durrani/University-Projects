package com;

import java.io.*;

abstract class StadiumCategories implements StadiumsCategoriesDepartments {
	
	public StadiumCategories(){
		createStadiumDirectories();
	}
	public void createStadiumDirectories() {
		for(int i = 0; i < PAK_STADIUM.length ; i++) {
			File directories = new File(PAK_STADIUM[i]);
			if(!(directories.exists())) {
				directories.mkdir();
				createSportsCategories(directories);
			}
			
		}
		
	}
	public void createSportsCategories(File d) {
		for(int i = 0; i < STADIUM_CATEGORIES.length ; i++) {
			File directories = new File(d.getAbsolutePath() +"/"+ STADIUM_CATEGORIES[i]);
			if(!(directories.exists())) {
				directories.mkdir();
			}
		}
		
	}
	
}

public class StadiumRegistrationDataBase extends StadiumCategories{
	String stadium;
	String dep;
	String athleteName;
	String[] data;
	private File stadiumFile;
	
	public StadiumRegistrationDataBase(String stadium , String sportsDep, String athleteName, String[] data ) throws IOException {
		super();
		this.dep = sportsDep;
		this.stadium = stadium;
		this.athleteName = athleteName;
		this.data = data;
		registerAthletesInStadiumRecord();
    }
	public void registerAthletesInStadiumRecord() throws IOException{
		stadiumFile = new File(stadium);
		stadiumFile.mkdirs();
		stadiumFile = new File(stadiumFile.getAbsoluteFile()+"/"+dep);
		stadiumFile.mkdir();
		
		stadiumFile = new File(stadiumFile.getAbsoluteFile()+"/"+athleteName+".txt");
		if(!(stadiumFile.exists())) {
			stadiumFile.createNewFile();
		}
		stadiumAthleteData(stadiumFile);
		
	}
	private void stadiumAthleteData(File f) throws IOException {
		FileWriter wr = new FileWriter(f);
		for(int i = 0 ; i < data.length ; i++) {
			wr.write("\n"+data[i]);
		}
		wr.close();
	}

	
	
}

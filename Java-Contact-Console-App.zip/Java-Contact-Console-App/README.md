JAVA PROJECT ( FUNCTIONAL CONTACT & CELL MANAGEMENT).

File Handling - Multi-D Arrays - Control Structures - Sequences - Exception Handling.
----------------------------------------------------------------
A Java project that has a title Functional Contact and Cell Management. Primarily, 
the purpose of this project is to store actual contact data permanently to a file.
That can be used in any form any time and has features to add, delete, update, search etc.
Any user can make their own contact book profile but firstly he has to sign-up for an account. 
After sign-up, contact book profile is accessible to the registered users. 
This features are handled by File Handling techniques. This project also covers the gamification phase 
that has several technical games that literally covers the concepts of Selections and Control Structures, 
Multi-Dimensional Arrays more efficiently.Moreover, the flow is comfortable, the user can access any 
method/function any time by following the instructions on display.

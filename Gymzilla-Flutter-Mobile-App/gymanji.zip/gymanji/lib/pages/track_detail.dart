import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:gymzilla/business%20login/Gymnast.dart';

class TrackDetails extends StatefulWidget {
  var gymnastOptions;
  TrackDetails({required this.gymnastOptions});
  @override
  State<TrackDetails> createState() => _TrackDetailsState();
}

class _TrackDetailsState extends State<TrackDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Gymnast Detail Page"),
          leading: InkWell(
            onTap: () {
              Get.back();
            },
            child: Icon(Icons.arrow_back),
          )),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Name: ${widget.gymnastOptions.title}",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              Text(
                "Age: ${widget.gymnastOptions.age}",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              Text(
                "Date of Joining: ${widget.gymnastOptions.day}/${widget.gymnastOptions.month}/${widget.gymnastOptions.year}",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              Text(
                "Address: ${widget.gymnastOptions.address}",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              Text(
                "Contact Number: ${widget.gymnastOptions.contactNumber}",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              Text(
                "Payment Status: " +
                    (widget.gymnastOptions.isPending()
                        ? "NOT PAID "
                        : "Amount Paid " + widget.gymnastOptions.amountPaid),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

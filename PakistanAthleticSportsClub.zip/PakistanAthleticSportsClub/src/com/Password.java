package com;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Password {

    public Password() {
    }


    public boolean isValidPassword(String password) {

        String regex = "^(?=.*[0-9])" + "(?=.*[A-Z])(?=.*[a-z])" + "(?=\\S+$)" + ".{8,}$";

        Pattern p = Pattern.compile(regex);
        Matcher matcher = p.matcher(password);
        return matcher.matches();
    }
}

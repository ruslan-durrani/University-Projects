package GUI;

import javax.swing.*;
import java.awt.*;

import static GUI.Frame.*;

//import static GUI.AdminPageLogin.usernameField;

public class AdminLoginHomePage extends JPanel {

    JLabel welcome, adminName;
    JButton buttonAddTicketData, buttonShowTicketData, buttonUpdateTicketData, buttonDeleteTicketData, buttonLogout;



    public AdminLoginHomePage() {
        setBackground(new Color(0xFF6200));
//        setBackground(Color.white);
        setVisible(true);
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        setSize(500,500);

        welcome = new JLabel("Welcome");
        add(welcome);
        welcome.setForeground(Color.WHITE);
        welcome.setHorizontalTextPosition(SwingConstants.CENTER);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcome.setFont(new Font("Monotype Sort",Font.BOLD,32));
        welcome.setVisible(true);
        add(Box.createRigidArea(new Dimension(0,18)));

        adminName = new JLabel();
        adminName.setText("Admin");
        add(adminName);
        adminName.setForeground(Color.WHITE);
        adminName.setHorizontalTextPosition(SwingConstants.CENTER);
        adminName.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminName.setFont(new Font("Monotype Sort",Font.BOLD,18));
        adminName.setVisible(true);
        add(Box.createRigidArea(new Dimension(0,30)));


        buttonAddTicketData = new JButton("Add Ticket");
        add(buttonAddTicketData);
        buttonAddTicketData.setVisible(true);
        buttonAddTicketData.setMaximumSize(new Dimension(180,40));
        buttonAddTicketData.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonAddTicketData.setFont(new Font("Monotype Sort",Font.BOLD,12));
        buttonAddTicketData.setForeground(Color.white);
        buttonAddTicketData.setBackground(new Color(252, 69, 31));
        buttonAddTicketData.setBorderPainted(false);
        buttonAddTicketData.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0,18)));

        buttonShowTicketData = new JButton("Show Ticket");
        add(buttonShowTicketData);
        buttonShowTicketData.setVisible(true);
        buttonShowTicketData.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonShowTicketData.setMaximumSize(new Dimension(180,40));
        buttonShowTicketData.setFont(new Font("Monotype Sort",Font.BOLD,12));
        buttonShowTicketData.setForeground(Color.white);
        buttonShowTicketData.setBackground(new Color(252, 69, 31));
        buttonShowTicketData.setBorderPainted(false);
        buttonShowTicketData.setFocusable(false);
        add(Box.createRigidArea(new Dimension(0,18)));


        buttonUpdateTicketData = new JButton("Update Ticket");
        add(buttonUpdateTicketData);
        buttonUpdateTicketData.setVisible(true);
        buttonUpdateTicketData.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonUpdateTicketData.setFont(new Font("Monotype Sort",Font.BOLD,12));
        buttonUpdateTicketData.setForeground(Color.white);
        buttonUpdateTicketData.setBackground(new Color(252, 69, 31));
        buttonUpdateTicketData.setBorderPainted(false);
        buttonUpdateTicketData.setFocusable(false);
        buttonUpdateTicketData.setMaximumSize(new Dimension(180,40));
        add(Box.createRigidArea(new Dimension(0,18)));


        buttonDeleteTicketData = new JButton("Delete Ticket");
        add(buttonDeleteTicketData);
        buttonDeleteTicketData.setVisible(true);
        buttonDeleteTicketData.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonDeleteTicketData.setFont(new Font("Monotype Sort",Font.BOLD,12));
        buttonDeleteTicketData.setForeground(Color.white);
        buttonDeleteTicketData.setBackground(new Color(252, 69, 31));
        buttonDeleteTicketData.setBorderPainted(false);
        buttonDeleteTicketData.setFocusable(false);
        buttonDeleteTicketData.setMaximumSize(new Dimension(180,40));
        add(Box.createRigidArea(new Dimension(0,18)));

        buttonLogout = new JButton("Log Out");
        add(buttonLogout);
        buttonLogout.setVisible(true);
        buttonLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonLogout.setFont(new Font("Monotype Sort",Font.BOLD,12));
        buttonLogout.setForeground(Color.white);
        buttonLogout.setBackground(new Color(252, 69, 31));
        buttonLogout.setBorderPainted(false);
        buttonLogout.setFocusable(false);
        buttonLogout.setMaximumSize(new Dimension(180,40));
        add(Box.createRigidArea(new Dimension(0,18)));


        buttonShowTicketData.addActionListener(e -> {
            setVisible(false);
            showTicket.setVisible(true);
        });

        buttonAddTicketData.addActionListener(e-> {
            setVisible(false);
            addTicket.setVisible(true);
        });

        buttonDeleteTicketData.addActionListener(e-> {
            setVisible(false);
            deleteTicket.setVisible(true);
        });


        buttonLogout.addActionListener(e-> {
            setVisible(false);
            mainPagePanel.setVisible(true);
        });

        buttonUpdateTicketData.addActionListener(e-> {
            setVisible(false);
            updateTicket.setVisible(true);
        });

    }
}

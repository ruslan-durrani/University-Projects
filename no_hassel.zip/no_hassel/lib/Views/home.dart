import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:no_hassel/Models/dyslexia.dart';
import 'package:intl/intl.dart';
import 'package:no_hassel/Views/SightSaver.dart';

import 'Mesages.dart';

class Home extends StatefulWidget {
  Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var mainButtons = [
    ["📸", "Sight Saver"],
    ["🔈", "Read Aloud"],
    ["💬", "Chat"],
  ];
  @override
  Widget build(BuildContext context) {
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('MMM d, yyyy, HH:mm:ss');
    final String formattedDateTime = formatter.format(now);
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(20),
        child: ListView(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text(
                  "Dyslexia Friendly",
                  style: TextStyle(
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                      fontSize: 16,
                      color: Colors.black),
                ),
                Switch(
                    value: Dyslexia.on,
                    onChanged: (e) {
                      setState(() {
                        Dyslexia.on = e;
                      });
                    })
              ],
            ),
            SizedBox(
              height: 20,
              child: Divider(
                height: 5,
                color: Colors.grey,
              ),
            ),
            Row(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage(
                      '/Users/russi7kd/StudioProjects/no_hassel/assets/img/Dr_Madni.jpg'), // Replace with your image path
                ),
                SizedBox(
                  width: 7,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Hi Dr Madni",
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight:
                              Dyslexia.on ? FontWeight.bold : FontWeight.w600),
                    ),
                    Text(
                      "Date: " + formattedDateTime,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: Dyslexia.on
                              ? FontWeight.bold
                              : FontWeight.normal),
                    )
                  ],
                )
              ],
            ),
            Container(
              padding: EdgeInsets.all(10),
              child: Text(
                "Assistant Professor at CS Dept. COMSATS University Islamabad with 10+ years of expertise. His research has focused upon the area of human computer interaction, and multimodal interfaces.",
                style: TextStyle(
                  fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal,
                  fontSize: 14,
                ),
              ),
            ),
            SizedBox(
              height: 20,
              child: Divider(
                height: 5,
                color: Colors.grey,
              ),
            ),
            ...List.generate(3, (index) {
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        if (index == 0)
                          return SightSaver();
                        else if (index == 1)
                          return Messages();
                        else
                          return Messages();
                      },
                    ),
                  );
                },
                child: Card(
                  child: Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(color: Colors.deepOrange),
                    child: Row(
                      children: [
                        Text(
                          mainButtons[index][0],
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w500),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          mainButtons[index][1],
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: Dyslexia.on
                                  ? FontWeight.w500
                                  : FontWeight.normal),
                        ),
                        Spacer(),
                        Icon(
                          Icons.navigate_next_sharp,
                          color: Colors.white,
                          weight: 10,
                        )
                      ],
                    ),
                  ),
                ),
              );
            })
          ],
        ),
      ),
      floatingActionButton: SpeedDial(
        backgroundColor: Colors.purpleAccent,
        foregroundColor: Colors.white,
        animatedIcon: AnimatedIcons.menu_close,
        children: [
          SpeedDialChild(
            child: Icon(Icons.view_list_outlined),
            label: 'Screen Reader',
            onTap: () {
              // Handle Email icon press
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.chat),
            label: 'Chat',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Messages(),
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.share_arrival_time_outlined),
            label: 'Read Aloud',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.insights),
            label: 'Sight Saver',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

package com.RDs.FrontEnd.Admin;

import com.RDs.Portal_logic.Noticeboard;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.Faculty.facultyID;
import static com.RDs.FrontEnd.SplashScreen.adminHomePage;

public class ManageNoticeboard extends JPanel {

    JButton jButtonAdd, jButtonDelete, jButtonUpdate, jButtonBack;
    JTextField jTextFieldId, jTextFieldDescription;
    public  static JTable jTableNoticeboardDetail;
    JScrollPane jScrollPaneDetail;


    Noticeboard noticeboard;

    {
        try {
            noticeboard = new Noticeboard();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public ManageNoticeboard() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0, 100)));

        jTextFieldId = new JTextField("Enter ID");
        add(jTextFieldId);
        jTextFieldId.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldId.setFont(new Font("Monotype Sort", Font.BOLD, 13));
        jTextFieldId.setMaximumSize(new Dimension(300, 45));

        add(Box.createRigidArea(new Dimension(0, 20)));

        jTextFieldDescription = new JTextField("Enter Description");
        jTextFieldDescription.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldDescription.setFont(new Font("Monotype Sort", Font.BOLD, 13));
        jTextFieldDescription.setMaximumSize(new Dimension(500, 45));

        add(jTextFieldDescription);


        add(Box.createRigidArea(new Dimension(0, 20)));


        JPanel jPanelButton = new JPanel();
        add(jPanelButton);
        jPanelButton.setLayout(new BoxLayout(jPanelButton, BoxLayout.X_AXIS));
        jPanelButton.setBackground(new Color(0xFF6200));

        jButtonAdd = new JButton("ADD");

        jButtonAdd.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonAdd.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonAdd.setForeground(Color.GRAY);
        jButtonAdd.setMaximumSize(new Dimension(180, 45));
        jButtonAdd.setBorderPainted(false);
        jButtonAdd.setBackground(Color.WHITE);
        jButtonAdd.setFocusable(false);

        jPanelButton.add(jButtonAdd);

        jButtonDelete = new JButton("DELETE");

        jButtonDelete.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonDelete.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonDelete.setForeground(Color.GRAY);
        jButtonDelete.setMaximumSize(new Dimension(180, 45));
        jButtonDelete.setBorderPainted(false);
        jButtonDelete.setBackground(Color.WHITE);
        jButtonDelete.setFocusable(false);

        jPanelButton.add(jButtonDelete);


        jButtonUpdate = new JButton("UPDATE");

        jButtonUpdate.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonUpdate.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonUpdate.setForeground(Color.GRAY);
        jButtonUpdate.setMaximumSize(new Dimension(180, 45));
        jButtonUpdate.setBorderPainted(false);
        jButtonUpdate.setBackground(Color.WHITE);
        jButtonUpdate.setFocusable(false);

        jPanelButton.add(jButtonUpdate);

        jButtonBack = new JButton("BACK");

        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(180, 45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);

        jPanelButton.add(jButtonBack);

        add(Box.createRigidArea(new Dimension(0, 30)));

        jTableNoticeboardDetail = new JTable();
        jScrollPaneDetail = new JScrollPane();

        jTableNoticeboardDetail.getTableHeader().setReorderingAllowed(false);

        String[] detailColumn = new String[]{"ID", "Description", "Posted By"};
        String[][] noticeboardDetails = noticeboard.fillTableNoticeboard();
        jTableNoticeboardDetail.setModel(new DefaultTableModel(noticeboardDetails,
                detailColumn));

        jScrollPaneDetail.setViewportView(jTableNoticeboardDetail);
        add(jScrollPaneDetail);


        jButtonBack.addActionListener(e -> {
            setVisible(false);
            adminHomePage.setVisible(true);
            jTextFieldDescription.setText("Enter Description");
            jTextFieldId.setText("Enter ID");
        });

        jButtonAdd.addActionListener(e -> {
            String noticeboardDetail = jTextFieldDescription.getText();
            int noticeID = Integer.parseInt(jTextFieldId.getText());
            System.out.println("add" + facultyID);

            if (!noticeboardDetail.isEmpty() && noticeboard.postNoticeboard(noticeID, noticeboardDetail)) {
                JOptionPane.showMessageDialog(this,"Noticeboard Added Successfully");

                jTableNoticeboardDetail.setModel(new DefaultTableModel(noticeboard.fillTableNoticeboard(),detailColumn));
                jTextFieldId.setText("Enter ID");
                jTextFieldDescription.setText("Enter Description");
            }
            else {
                JOptionPane.showMessageDialog(this,"Error Occurred");
            }
        });


        jTextFieldDescription.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jTextFieldDescription.setText("");
            }
        });

        jTextFieldId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldId.setText("");
                super.mouseClicked(e);
            }
        });

        jButtonUpdate.addActionListener(e-> {
            String desc = jTextFieldDescription.getText();
            int id = Integer.parseInt(jTextFieldId.getText());

            if (!desc.isEmpty() && !desc.equals("Enter Description") && !jTextFieldId.getText().isEmpty() && !jTextFieldId.getText().equals("Enter ID") &&
               noticeboard.updatePost(id,desc)) {
                JOptionPane.showMessageDialog(this,"Noticeboard Updated Successfully");
                jTextFieldId.setText("Enter ID");
                jTextFieldDescription.setText("Enter Description");
                jTableNoticeboardDetail.setModel(new DefaultTableModel(noticeboard.fillTableNoticeboard(),detailColumn));
            }
            else JOptionPane.showMessageDialog(this,"Not Updated ERROR!");
        });

        jButtonDelete.addActionListener(e-> {

            if (!jTextFieldId.getText().isEmpty() && !jTextFieldId.getText().equals("Enter ID") && noticeboard.deleteNoticeboard(Integer.parseInt(jTextFieldId.getText()))){
                JOptionPane.showMessageDialog(this,"Deleted Successful");
                jTextFieldId.setText("Enter ID");
                jTextFieldDescription.setText("Enter Description");
                jTableNoticeboardDetail.setModel(new DefaultTableModel(noticeboard.fillTableNoticeboard(),detailColumn));
            }
            else JOptionPane.showMessageDialog(this,"NOT DELETED ERROR!");
        });


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Admin/manageNoticeboard.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }
}

import 'package:flutter/material.dart';
import 'package:no_hassel/Models/dyslexia.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange,
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage(
                  '/Users/russi7kd/StudioProjects/no_hassel/assets/img/r.jpg'),
            ),
            SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Quaid E Azam',
                  style: TextStyle(
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.normal),
                ),
                Text(
                  'Online',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                      fontWeight:
                          Dyslexia.on ? FontWeight.bold : FontWeight.normal),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.phone),
            onPressed: () {
              // Perform phone call action
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 16),
              children: const [
                MessageBubble(
                  text: 'Salam Doctor Saab!',
                  isMe: false,
                ),
                SizedBox(
                  height: 10,
                ),
                MessageBubble(
                  text: 'W salam Quaid E Azam, how are you!',
                  isMe: true,
                ),
                SizedBox(
                  height: 10,
                ),
                MessageBubble(
                  text:
                      'I am looking into AI these days, can you schedule a meeting tonight or someday feasible for you?',
                  isMe: false,
                ),
                SizedBox(
                  height: 10,
                ),
                MessageBubble(
                  text:
                      'Sure Sir, i am available, i will send you zoom meeting link later tonight',
                  isMe: true,
                ),
                SizedBox(
                  height: 10,
                ),
                // Add more message bubbles here
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.record_voice_over),
                  onPressed: () {
                    // Perform text-to-speech action
                  },
                ),
                const Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    // Send message action
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MessageBubble extends StatelessWidget {
  final String text;
  final bool isMe;

  const MessageBubble({
    required this.text,
    required this.isMe,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
          isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Container(
            margin: EdgeInsets.symmetric(vertical: 4),
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isMe ? Colors.green : Colors.grey.shade300,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              text,
              style: TextStyle(
                  color: isMe ? Colors.white : Colors.black,
                  fontWeight:
                      Dyslexia.on ? FontWeight.bold : FontWeight.normal),
            )),
        Row(
          mainAxisAlignment:
              isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(left: 5, right: 5),
              decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(.3),
                  borderRadius: BorderRadius.circular(10)),
              child: Text(
                "🔊Text-Speech",
                style: TextStyle(
                    fontSize: 12,
                    fontWeight:
                        Dyslexia.on ? FontWeight.bold : FontWeight.normal),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 5, right: 5),
              decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(.3),
                  borderRadius: BorderRadius.circular(10)),
              child: Text(
                "💬 Speech-Text",
                style: TextStyle(
                    fontSize: 12,
                    fontWeight:
                        Dyslexia.on ? FontWeight.bold : FontWeight.normal),
              ),
            ),
          ],
        )
      ],
    );
  }
}

package GUI;

import com.Spectator;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;

import static GUI.Frame.deleteTicket;
import static GUI.Frame.spectatorPanel;

public class RefundTicket extends JPanel {

    JLabel ticketName;
    JTextField jTextFieldUsername;
    JSpinner jSpinnerDepartment, jSpinnerStadium;
    JButton buttonSubmit, buttonBack;
    public RefundTicket() {
        setVisible(true);
        setBackground(new Color(0xFF86200));
        setSize(500,500);
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

        ticketName = new JLabel("Refund Ticket");
        ticketName.setVisible(true);
        add(ticketName);
        ticketName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        ticketName.setForeground(Color.WHITE);
        ticketName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));

        String[] stadiumArray = {"Select Stadium", "Islamabad", "KPK", "Karachi", "Baluchistan"};
        String[] departmentArray = {"Select Department", "Cricket", "Football", "Tennis", "Volley Ball", "Table Tennis"};
        JPanel panel1 = new JPanel();

        jSpinnerDepartment = new JSpinner(new SpinnerListModel(departmentArray));
        jSpinnerDepartment.setVisible(true);
        jSpinnerDepartment.setMinimumSize(new Dimension(180, 40));
        jSpinnerDepartment.setMaximumSize(new Dimension(180, 40));

        jSpinnerStadium = new JSpinner(new SpinnerListModel(stadiumArray));
        jSpinnerStadium.setVisible(true);
        jSpinnerStadium.setMinimumSize(new Dimension(180, 40));
        jSpinnerStadium.setMaximumSize(new Dimension(180, 40));

        panel1.add(jSpinnerDepartment);
        panel1.add(Box.createRigidArea(new Dimension(10, 0)));
        panel1.add(jSpinnerStadium);
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
        panel1.setBackground(new Color(0xFF6200));
        add(panel1);
        panel1.setVisible(true);
        add(Box.createRigidArea(new Dimension(0, 10)));

        jTextFieldUsername = new JTextField("Enter Username");
        jTextFieldUsername.setVisible(true);
        add(jTextFieldUsername);
        jTextFieldUsername.setMinimumSize(new Dimension(180, 40));
        jTextFieldUsername.setMaximumSize(new Dimension(180, 40));
        add(Box.createRigidArea(new Dimension(0,10)));

        JPanel buttonPanel = new JPanel();
        add(buttonPanel);
        buttonPanel.setVisible(true);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(0xFF6200));

        buttonBack = new JButton("Back");
        buttonPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(90, 40));
        buttonBack.setMinimumSize(new Dimension(90, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
        buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));

        buttonSubmit = new JButton("Submit");
        buttonPanel.add(buttonSubmit);
        buttonSubmit.setVisible(true);
        buttonSubmit.setFont(new Font("Monotype Sott", Font.BOLD, 12));
        buttonSubmit.setMaximumSize(new Dimension(90, 40));
        buttonSubmit.setMinimumSize(new Dimension(90, 40));
        buttonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSubmit.setForeground(Color.white);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setBorderPainted(false);
        buttonSubmit.setFocusable(false);


        buttonBack.addActionListener(e-> {
            setVisible(false);
            spectatorPanel.setVisible(true);
        });


        buttonSubmit.addActionListener(e->{
            String username = jTextFieldUsername.getText();
            String department = String.valueOf(jSpinnerDepartment.getValue());
            String stadium = String.valueOf(jSpinnerStadium.getValue());
            int result = JOptionPane.showConfirmDialog(this,"Are you sure? you want to refund ticket?","Refund Ticket",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);

            if (result == JOptionPane.YES_OPTION) {
                   if (username.isEmpty() || username.equalsIgnoreCase("Enter username")){
                       JOptionPane.showMessageDialog(this,"Please fill all the fields");
                   }
                   else {
                       Spectator spectator = new Spectator();
                       try {
                           if (spectator.deleteSpectatorTicket(stadium,department,username)){
                               JOptionPane.showMessageDialog(this,"Ticket deleted successfully");
                           }
                           else {
                               JOptionPane.showMessageDialog(this,"Ticket does not exist");
                           }
                       } catch (FileNotFoundException ex) {
                           ex.printStackTrace();
                       }


                   }
            }
        });





    }


}

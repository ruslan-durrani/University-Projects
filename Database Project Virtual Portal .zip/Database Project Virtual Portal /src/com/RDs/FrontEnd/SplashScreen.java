package com.RDs.FrontEnd;

import com.RDs.FrontEnd.Admin.*;
import com.RDs.FrontEnd.FacultyPortal.*;
import com.RDs.FrontEnd.HelpDesk.FacultyHelpDesk;
import com.RDs.FrontEnd.Student.*;

import javax.swing.*;

public class SplashScreen extends JFrame {

    public static JPanel mainPagePanel = new MainPagePanel();
    public static AdministrationLogin administrationLogin = new AdministrationLogin();
    public static StudentLogin studentLogin = new StudentLogin();
    public static StudentRegistration studentRegistration = new StudentRegistration();
    public static AdminHomePage adminHomePage = new AdminHomePage();
    public static ManageNoticeboard manageNoticeboard = new ManageNoticeboard();

    public static ValidateStudent validateStudent = new ValidateStudent();
    public static FacultyLogin facultyLogin = new FacultyLogin();

    public static FacultyHomePage facultyHomePage = new FacultyHomePage();
    public static StudentInfo studentInfo = new StudentInfo();
    public static AddStudentMarks addStudentMarks = new AddStudentMarks();
    public static ShowStudentMarks showStudentMarks = new ShowStudentMarks();
    public static StudentHomePage studentHomePage = new StudentHomePage();
    public static StudentProfileInfo studentProfileInfo = new StudentProfileInfo();
    public static RegisteredCourses registeredCourses = new RegisteredCourses();
    public static StudentHelpDesk studentHelpDesk= new StudentHelpDesk();
    public static FacultyHelpDesk facultyHelpDesk = new FacultyHelpDesk();
    public static FacultyProfileInfo facultyProfileInfo = new FacultyProfileInfo();

    public SplashScreen(){
        setVisible(true);
        setTitle("Ardies Virtual Portal");
        setSize(1000,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        add(mainPagePanel);


        add(administrationLogin);
        administrationLogin.setVisible(false);

        add(studentLogin);
        studentLogin.setVisible(false);

        add(studentRegistration);
        studentRegistration.setVisible(false);

        add(adminHomePage);
        adminHomePage.setVisible(false);

        add(manageNoticeboard);
        manageNoticeboard.setVisible(false);




        add(validateStudent);
        validateStudent.setVisible(false);

        add(facultyLogin);
        facultyLogin.setVisible(false);


        add(facultyHomePage);
        facultyHomePage.setVisible(false);

        add(studentInfo);
        studentInfo.setVisible(false);

        add(addStudentMarks);
        addStudentMarks.setVisible(false);

        add(showStudentMarks);
        showStudentMarks.setVisible(false);

        add(studentHomePage);
        studentHomePage.setVisible(false);

        add(studentProfileInfo);
        studentProfileInfo.setVisible(false);

        add(registeredCourses);
        registeredCourses.setVisible(false);

        add(studentHelpDesk);
        studentHelpDesk.setVisible(false);

        add(facultyHelpDesk);
        facultyHelpDesk.setVisible(false);

        add(facultyProfileInfo);
        facultyProfileInfo.setVisible(false);
    }
}



class Main {

    public static void main(String[] args) {
        new SplashScreen();





    }
}

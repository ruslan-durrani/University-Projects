import 'package:flutter/material.dart';

const kBlackColor = Colors.black;
// const kPrimaryLight = Color(0xFFEDF6F3);
// const kPrimary = Color(0xFFDAEFE8);
// const kPrimaryDark = Color(0xFF88A1AE);
// const kAccent = Color(0xFFFDCA73);
const kLightBlackColor = Color(0xFF8F8F8F);
const kIconColor = Color(0xFFF48A37);
const kProgressIndicator = Color(0xFFBE7066);
final kShadowColor = Color(0xFFD3D3D3).withOpacity(.84);
const kSecondaryColor = Color(0xFF8B94BC);
const kGreenColor = Color(0xFF6AC259);
const kRedColor = Color(0xFFE92E30);
const kGrayColor = Color(0xFFC1C1C1);
// const kBlackColor = Color(0xFF101010);
const kPrimaryGradient = LinearGradient(
  colors: [Color(0xFF46A0AE), Color(0xFF00FFCB)],
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
);

const double kDefaultPadding = 20.0;

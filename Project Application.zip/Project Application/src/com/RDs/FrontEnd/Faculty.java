package com.RDs.FrontEnd;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import com.RDs.Database.Database;

import javax.swing.*;
import javax.xml.crypto.Data;

public class Faculty extends Database {

    public ArrayList<ArrayList<String>> facultyDynamic = new ArrayList<>();
    public String[][] facultyDetail;
    public static String[] tokenId;
    public static String facultyID;
    public ArrayList<ArrayList<String>> studentDetails = new ArrayList<>();
    public ArrayList<ArrayList<String>> addMarksToStudent = new ArrayList<>();


    public Faculty() throws SQLException {
        super();

    }

    public String[][] fillFacultyTable() {

        String validationQuery = "SELECT * FROM faculty";
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            int i = 0;
            while (rs.next()) {
//                facultyID, facultyName, password, departmentName

                String faculty_id = rs.getString("facultyID");
                String facultyName = rs.getString("facultyName");
                String departmentName = rs.getString("departmentName");
                boolean validate = rs.getBoolean("validate");
                if (!validate) {
                    facultyDynamic.add(new ArrayList<>());
                    facultyDynamic.get(i).add(faculty_id);
                    facultyDynamic.get(i).add(facultyName);
                    facultyDynamic.get(i).add(departmentName);
                    i++;
                }

            }

            if (facultyDynamic.isEmpty()) return new String[][]{};

            facultyDetail = new String[facultyDynamic.size()][facultyDynamic.get(0).size()];

            for (int j = 0; j < facultyDynamic.size(); j++) {

                for (int k = 0; k < facultyDynamic.get(j).size(); k++) {
                    facultyDetail[j][k] = facultyDynamic.get(j).get(k);
                }
            }

            return facultyDetail;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new String[][]{};
    }

    public boolean validate(String facultyId, String password) {
        String validationQuery = "SELECT * FROM faculty";
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            while (rs.next()) {
                String facultyID_ = rs.getString("facultyID");
                String facultyPassword = rs.getString("password");
                boolean validate = rs.getBoolean("validate");

                if (validate && facultyId.equalsIgnoreCase(facultyID_) && password.equals(facultyPassword)) {
                    facultyID = facultyID_;
                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }


    public String fillChat() {
        String validationQuery = "SELECT * FROM help_desk";
        ResultSet rs = null;
        StringBuilder chatDesc = new StringBuilder();
        chatDesc.append("<html><br><br>");
        try {
            rs = stmt.executeQuery(validationQuery);

            //tokenID, rollnumber, student_query, respondedQuery, facultyID
            ArrayList<String> arr = new ArrayList<>();

            arr.add("Token ID");
            while (rs.next()) {
                String tokenID = rs.getString("tokenID");
                String rollNumber = rs.getString("rollnumber");
                String studentQuery = rs.getString("student_query");
                String respondedQuery = rs.getString("respondedQuery");
                String facultyID = rs.getString("facultyID");

                chatDesc.append("Token ID: ").append(tokenID).append("<br>");
                chatDesc.append("Registration Number: ").append(rollNumber).append("<br>");
                chatDesc.append("Message: ").append(studentQuery).append("<br>");
                chatDesc.append("Response: ").append(respondedQuery);

                if (respondedQuery.equalsIgnoreCase("NOT RESPONDED YET")) {
                    chatDesc.append("<br><br>");
                } else {
                    chatDesc.append("<br>Replied By: ").append(facultyID).append("<br><br>");
                }

                arr.add(tokenID);
            }

            tokenId = new String[arr.size()];
            for (int i = 0; i < arr.size(); i++) {
                tokenId[i] = arr.get(i);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return chatDesc.toString();
    }

    public boolean postReply(String reply, String tokenID) throws SQLException {

        String validationQuery = "SELECT * FROM help_desk";
        ResultSet rs = null;

        String q1 = "UPDATE help_desk set respondedQuery='" + reply + "' WHERE tokenID='" + tokenID + "'";
        String q2 = "UPDATE help_desk set facultyID='" + Faculty.facultyID + "' WHERE tokenID='" + tokenID + "'";

        rs = stmt.executeQuery(validationQuery);

        while (rs.next()) {
            String tokenID_ = rs.getString("tokenID");
            String facultyID_ = rs.getString("facultyID");
            if (tokenID_.equalsIgnoreCase(tokenID)) {
                if (facultyID_ == null || facultyID_.isEmpty() || facultyID_.equalsIgnoreCase(facultyID)) {
                    System.out.println(facultyID_);
                    stmt.executeUpdate(q1);
                    stmt.executeUpdate(q2);
                    return true;
                }
            }
        }
        return false;

    }

    public String[] retrieveProgram() {
//        String validation = "SELECT * FROM Faculty AS f NATURAL JOIN FacultyCourses NATURAL JOIN Courses NATURAL JOIN SemesterCourses NATURAL JOIN Programs NATURAL JOIN Students WHERE f.FacultyID = '" + facultyID + "'";
//         String validation = "SELECT DISTINCT facultyID, semester,departmentName,programName,facultyName AS Teacher,courseName,concat(first_name,' ', last_name) AS \"Full Name\" ,rollnumber AS Student FROM Faculty NATURAL JOIN FacultyCourses Natural JOIN Courses NATURAL JOIN SemesterCourses NATURAL JOIN Students WHERE facultyID = '" + facultyID  + "' and validate = 1";

        String validation = "SELECT DISTINCT facultyID, courseName, rollnumber, concat(first_name, \" \", last_name) AS \"Full Name\", s.departmentName, s.programName, s.semester FROM faculty NATURAL JOIN FacultyCourses NATURAL JOIN Courses NATURAL JOIN Departments Natural JOIN Programs JOIN students as s ON (semester) NATURAL JOIN semestercourses WHERE facultyID = '" + facultyID + "' AND validate = 1";
        String[] programs = null;
        ArrayList<String> arr = new ArrayList<>();
        try {
            ResultSet rs = stmt.executeQuery(validation);
            int k = 0;
            while (rs.next()) {
                //Registration Number","Full Name", "Semester","Department", "Program Name"
                String registrationNumber = rs.getString("rollnumber");
                String program = rs.getString("programName");
                String courseName = rs.getString("courseName");
                String fullName = rs.getString("Full Name");
                String semester = rs.getString("semester");
                String department = rs.getString("departmentName");
//                System.out.println(program);

                studentDetails.add(new ArrayList<>());
                studentDetails.get(k).add(registrationNumber);
                studentDetails.get(k).add(fullName);
                studentDetails.get(k).add(semester);
                studentDetails.get(k).add(department);
                studentDetails.get(k).add(program);
                studentDetails.get(k).add(courseName);
                k++;
                arr.add(courseName);
            }

//            System.out.println(studentDetails.get(0).size());
            programs = new String[arr.size()];

            for (int i = 0; i < arr.size(); i++) {
                programs[i] = arr.get(i);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return programs;
    }

    public String[][] fillStudentTable(String courseName) {
        ArrayList<ArrayList<String>> arr = new ArrayList<>();

        for (int i = 0; i < studentDetails.size(); i++) {
            if (studentDetails.get(i).contains(courseName)) arr.add(new ArrayList<>());

            for (int j = 0; j < studentDetails.get(i).size(); j++) {
                if (studentDetails.get(i).get(5).equals(courseName)) {
                    arr.get(arr.size() - 1).add(studentDetails.get(i).get(j));
                }
            }

        }

        String[][] studentArr = new String[arr.size()][arr.get(0).size()];
        for (int i = 0; i < arr.size(); i++) {
            for (int j = 0; j < arr.get(i).size(); j++) {
                studentArr[i][j] = arr.get(i).get(j);
            }
        }

        return studentArr;
    }

    public String[][] showAddStudentMarks(String courseName) {
        String validation = "SELECT DISTINCT facultyID, courseName, rollnumber, concat(first_name, \" \", last_name) AS \"Full Name\", s.departmentName, s.programName, s.semester, course_score FROM faculty NATURAL JOIN FacultyCourses NATURAL JOIN Courses NATURAL JOIN Departments Natural JOIN Programs JOIN students as s ON (semester) NATURAL JOIN semestercourses NATURAL JOIN Results WHERE facultyID = '" + facultyID + "' AND validate = 1";

        try {
            ResultSet rs = stmt.executeQuery(validation);
            int i = 0;
            while (rs.next()) {
                String regNumber = rs.getString("rollnumber");
                System.out.println(regNumber);
                String fullName = rs.getString("Full Name");
                String semester = rs.getString("semester");
                String department = rs.getString("departmentName");
                String program = rs.getString("programName");
                String course = rs.getString("courseName");
                String score = rs.getString("course_score");

                addMarksToStudent.add(new ArrayList<>());
                addMarksToStudent.get(i).add(regNumber);
                addMarksToStudent.get(i).add(fullName);
                addMarksToStudent.get(i).add(semester);
                addMarksToStudent.get(i).add(department);
                addMarksToStudent.get(i).add(program);
                addMarksToStudent.get(i).add(course);
                addMarksToStudent.get(i).add(score);
                i++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ArrayList<ArrayList<String>> arr = new ArrayList<>();

        for (int i = 0; i < addMarksToStudent.size(); i++) {
            if (addMarksToStudent.get(i).contains(courseName)) arr.add(new ArrayList<>());
            for (int j = 0; j < addMarksToStudent.get(i).size(); j++) {
                if (addMarksToStudent.get(i).get(5).equals(courseName)) {
                    arr.get(arr.size() - 1).add(addMarksToStudent.get(i).get(j));
                }
            }
        }

        String[][] addMarks = new String[arr.size()][arr.get(0).size()];

        for (int i = 0; i < addMarks.length; i++) {
            for (int j = 0; j < addMarks[i].length; j++) {
                addMarks[i][j] = arr.get(i).get(j);
            }
        }
        return addMarks;
    }

    public boolean addMarks(String registrationNumber, String courseName, int score) {

        String validate = "UPDATE Results SET course_score = " + score + " WHERE rollnumber ='" + registrationNumber + "' AND courseName = '" + courseName + "'";

        try {
            System.out.println(validate);
            int rs = stmt.executeUpdate(validate);
            System.out.println(rs);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String[][] showSpecificStudentMarks(String registrationNumber, String courseName) {
//        addMarksToStudent
        String[][] arr;
        ArrayList<ArrayList<String>> arrayList = new ArrayList<>();
        showAddStudentMarks(courseName);
        for (int i=0; i<addMarksToStudent.size(); i++) {
            if (addMarksToStudent.get(i).contains(registrationNumber) && addMarksToStudent.get(i).contains(courseName)) arrayList.add(new ArrayList<>());
            for (int j=0; j<addMarksToStudent.get(i).size(); j++) {
                if (addMarksToStudent.get(i).get(0).equalsIgnoreCase(registrationNumber) && addMarksToStudent.get(i).get(5).equalsIgnoreCase(courseName)) {
                    arrayList.get(arrayList.size()-1).add(addMarksToStudent.get(i).get(j));
                }
            }
        }
        arr = new String[arrayList.size()][arrayList.get(0).size()];

        for (int i=0; i<arr.length; i++) {
            for (int j=0; j<arr[i].length; j++) {

                arr[i][j] = arrayList.get(i).get(j);
            }
        }

        return arr;

    }


    public String getProfileInfo() {
        //rollnumber, password_, first_name, last_name, email_address, departmentName, programName, semester, isRegistered
        //facultyID, facultyName, email_address, password, departmentName, validate
        StringBuilder desc = new StringBuilder();
//        String[] temp = new String[8];


        String validationQuery = "SELECT * FROM Faculty";
        try {
            ResultSet rs = stmt.executeQuery(validationQuery);
            while (rs.next()) {
                String registrationNumber = rs.getString("facultyID");
                String firstName = "Full Name: " + rs.getString("facultyName");
                String emailAddress = "Email Address: " + rs.getString("email_address");
                String departmentName = "Department Name: " + rs.getString("departmentName");

                if (Faculty.facultyID.equals(registrationNumber)) {

                    desc.append("<html><br>");
                    desc.append("Faculty ID: ").append(registrationNumber).append("<br>").append(firstName).append("<br>").append(emailAddress).append("<br>").append(departmentName).append("<br>");
                    desc.append("</html>");
                    return desc.toString();
                }


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return desc.toString();


    }


    public boolean updateEmailAddress(String emailAddress) {
        String validation = "UPDATE Faculty SET email_address = '" + emailAddress + "' WHERE facultyID = '" + Faculty.facultyID + "'";

        try {
            stmt.executeUpdate(validation);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFullName(String fullName) {
        String validation = "UPDATE Faculty SET facultyName = '" + fullName + "' WHERE facultyID = '" + Faculty.facultyID + "'";

        try {
            stmt.executeUpdate(validation);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}

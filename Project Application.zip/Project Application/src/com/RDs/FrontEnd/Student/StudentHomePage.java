package com.RDs.FrontEnd.Student;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import static com.RDs.FrontEnd.SplashScreen.*;
import static com.RDs.FrontEnd.Student.StudentLogin.studentBackend;

public class StudentHomePage extends JPanel {

    JButton jButtonProfileInfo, jButtonRegisteredCourses, jButtonStdResults, jButtonHelpDesk, jButtonLogout, jButtonMarks;
    String[] retrieveProgram;


    public StudentHomePage() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);

        add(Box.createRigidArea(new Dimension(0, 100)));

        jButtonProfileInfo = new JButton("PROFILE INFO");
        add(jButtonProfileInfo);
        jButtonProfileInfo.setBackground(Color.WHITE);
        jButtonProfileInfo.setBorderPainted(false);
        jButtonProfileInfo.setFocusable(false);
        jButtonProfileInfo.setForeground(Color.GRAY);
        jButtonProfileInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonProfileInfo.setMaximumSize(new Dimension(200, 45));
        jButtonProfileInfo.setFont(new Font("Monotype Sort", Font.BOLD, 14));

        add(Box.createRigidArea(new Dimension(0, 20)));

        jButtonRegisteredCourses = new JButton("REGISTERED COURSE");
        add(jButtonRegisteredCourses);
        jButtonRegisteredCourses.setBackground(Color.WHITE);
        jButtonRegisteredCourses.setBorderPainted(false);
        jButtonRegisteredCourses.setFocusable(false);
        jButtonRegisteredCourses.setForeground(Color.GRAY);
        jButtonRegisteredCourses.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonRegisteredCourses.setMaximumSize(new Dimension(200,45));
        jButtonRegisteredCourses.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonMarks = new JButton("MARKS SUMMARY");
        add(jButtonMarks);
        jButtonMarks.setBackground(Color.WHITE);
        jButtonMarks.setBorderPainted(false);
        jButtonMarks.setFocusable(false);
        jButtonMarks.setForeground(Color.GRAY);
        jButtonMarks.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonMarks.setMaximumSize(new Dimension(200,45));
        jButtonMarks.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

//        jButtonStdResults = new JButton("STUDENT RESULT");
//        add(jButtonStdResults);
//        jButtonStdResults.setBackground(Color.WHITE);
//        jButtonStdResults.setBorderPainted(false);
//        jButtonStdResults.setFocusable(false);
//        jButtonStdResults.setForeground(Color.GRAY);
//        jButtonStdResults.setAlignmentX(Component.CENTER_ALIGNMENT);
//        jButtonStdResults.setMaximumSize(new Dimension(200,45));
//        jButtonStdResults.setFont(new Font("Monotype Sort",Font.BOLD,14));
//
//        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonHelpDesk = new JButton("HELP DESK");
        add(jButtonHelpDesk);
        jButtonHelpDesk.setBackground(Color.WHITE);
        jButtonHelpDesk.setBorderPainted(false);
        jButtonHelpDesk.setFocusable(false);
        jButtonHelpDesk.setForeground(Color.GRAY);
        jButtonHelpDesk.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonHelpDesk.setMaximumSize(new Dimension(200,45));
        jButtonHelpDesk.setFont(new Font("Monotype Sort",Font.BOLD,14));

        add(Box.createRigidArea(new Dimension(0,20)));

        jButtonLogout = new JButton("LOG OUT");
        add(jButtonLogout);
        jButtonLogout.setBackground(Color.WHITE);
        jButtonLogout.setBorderPainted(false);
        jButtonLogout.setFocusable(false);
        jButtonLogout.setForeground(Color.GRAY);
        jButtonLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonLogout.setMaximumSize(new Dimension(200, 45));
        jButtonLogout.setFont(new Font("Monotype Sort", Font.BOLD, 14));

        jButtonLogout.addActionListener(e -> {

            int receive = JOptionPane.showConfirmDialog(this, "Would you like to log out?", "LOG OUT", JOptionPane.YES_NO_OPTION);
            if (receive == 0) {
                setVisible(false);
                facultyLogin.setVisible(true);
            }
        });

        jButtonHelpDesk.addActionListener(e-> {
            setVisible(false);
            studentHelpDesk.setVisible(true);
        });

//        jButtonHelpDesk.addActionListener(e-> {
//            setVisible(false);
//            helpDeskActivity.setVisible(true);
//        });

        jButtonProfileInfo.addActionListener(e -> {
            setVisible(false);
            studentProfileInfo.jLabel.setText(studentBackend.getProfileInfo());
            studentProfileInfo.setVisible(true);

        });

        jButtonRegisteredCourses.addActionListener(e-> {
            String[] detailColumn = new String[]{"Program Name","Course Name", "Semester","Faculty Name", "Faculty ID"};

            setVisible(false);
            registeredCourses.setVisible(true);
            String[][] reg = studentBackend.registeredCourses();
            RegisteredCourses.jTableDetails.setModel(new DefaultTableModel(reg,detailColumn));
//            System.out.println(reg);
        });


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Student/studentPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }
}

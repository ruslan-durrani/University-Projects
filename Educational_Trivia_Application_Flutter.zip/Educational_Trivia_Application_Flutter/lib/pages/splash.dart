import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/pages/welcome_page.dart';
import 'dart:async';
import 'dart:core';
class SplashScreen extends StatefulWidget {
  static String splash = "/splash";
  const SplashScreen({Key? key}) : super(key: key);
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: const BoxDecoration(color: Colors.deepOrangeAccent),
            // decoration: const BoxDecoration(color: Colors.deepOrangeAccent),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                flex: 2,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:  [
                    new GestureDetector(
                      onTap: (){
                        Navigator.pushNamed(context, '/login');
                      },
                      child: CircleAvatar (
                        backgroundColor: Colors.transparent,
                        radius: 60.0,
                        // child: Icon(
                        //   Icons.highlight_sharp,
                        //   color: Colors.deepOrangeAccent,
                        //   size: 55.0,
                        // ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: Image(
                            image: AssetImage('img/LOGO.jpg'),
                            fit: BoxFit.cover,
                          ),
                        )
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(top: 10.0)),
                    Text(
                      "Ardies Trivia",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 24.0,
                          color: Colors.white),
                    )
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

package com;

import java.io.*;
import java.util.ArrayList;


abstract class AdminDirectories implements StadiumsCategoriesDepartments {
    File file;
    String[] ticketData = new String[]{"", "", "", "", ""}; //"Department: ", "Title: ", "Stadium: ", "Day: ", "Time: "

    AdminDirectories(){
        file = new File("Admin");
        file.mkdir();
        createStadiumDirectories(file);

    }

    protected void createStadiumDirectories(File file) {
        for (int i = 0; i < PAK_STADIUM.length; i++) {
            File f = new File(file.getAbsolutePath() + "/" + PAK_STADIUM[i]);
            f.mkdir();
        }
    }
}

public class Admin extends AdminDirectories {
    private static File file;
    public static ArrayList<String> ticketDataArray = new ArrayList<>();
    public ArrayList<ArrayList<String>> ticketData2D = new ArrayList<>();
    public String[][] ticket2DArray;


    public Admin() throws IOException {
        super();
    }

    public void addTicketData(String department, String title, String stadium, String day, String time) throws Exception {
        getTicketInput(department, title, stadium, day, time);
        file = new File(super.file.getAbsolutePath() + "/" + stadium + "/" + department + ".txt");
        if (!file.exists()) {
            file.createNewFile();
        }
        FileOutputStream fos = new FileOutputStream(file, true);
        for (int i = 0; i < ticketData.length; i++) {
            byte[] write;
            if (i == ticketData.length - 1) {
                write = (ticketData[i] + "\n").getBytes();
            } else if (i == 0) {
                write = (ticketData[i] + ",").getBytes();
            } else {
                write = (ticketData[i] + ",").getBytes();
            }
            fos.write(write);
        }
        fos.close();
    }


    private void getTicketInput(String department, String title, String stadium, String day, String time) {

        //"Department: ", "Title: ", "Stadium: ", "Day: ", "Time: "

        ticketData[0] = department;
        ticketData[1] = title;
        ticketData[2] = stadium;
        ticketData[3] = day;
        ticketData[4] = time;

    }

    public boolean showTicketData(String stadium, String department) throws Exception {

        ticketDataArray = new ArrayList<>();
        file = new File("Admin" + "/" + stadium + "/" + department + ".txt");
        if (!file.exists()) {
            return false;
        }
        else {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);

            String line;
            int id = 0;
            String[] s;
            while ((line = br.readLine()) != null) {
                s = line.split(",");

                ticketDataArray.add(line + "\n");

                ticketData2D.add(new ArrayList<>());

                ticketData2D.get(id).add(String.valueOf(id + 1));

                for (int i = 0; i < s.length; i++) {
                    ticketData2D.get(id).add(s[i]);
                }
                id++;
            }

            if (ticketData2D.isEmpty()) {
                return false;
            }

            ticket2DArray = new String[ticketData2D.size()][ticketData2D.get(0).size()];

            for (int i = 0; i < ticketData2D.size(); i++) {
                for (int j = 0; j < ticketData2D.get(i).size(); j++) {
                    ticket2DArray[i][j] = ticketData2D.get(i).get(j);
                }
            }
        }
        return true;
    }



    public ArrayList<String> getTicketData1d() {
        return ticketDataArray;
    }

    public void deleteTicketData(String id, String stadium, String department) throws Exception {


        showTicketData(stadium, department);

        FileOutputStream fos = new FileOutputStream(file);
        for (int i = 0; i < ticketDataArray.size(); i++) {
            if ((i + 1) == Integer.parseInt(id)) {
                continue;
            }
            byte[] write = (ticketDataArray.get(i)).getBytes();
            fos.write(write);
        }
        fos.flush();
        fos.close();
    }


    public void updateTicketData(String id, String department, String stadium, String title, String day, String time) throws Exception {

        FileOutputStream fos = new FileOutputStream(file);
        if (ticketDataArray.isEmpty())
            System.out.println("Empty");
        else {
            for (int i = 0; i < ticketDataArray.size(); i++) {
                System.out.println(ticketDataArray.get(i));
            }
            String line = "";

            for (int i = 0; i < ticketDataArray.size(); i++) {
                if ((i + 1) == Integer.parseInt(id)) {
                    line += department + "," + title + "," + stadium + "," + day + "," + time + "\n";
                    ticketDataArray.set(i, line);
                    break;
                }
            }

            for (int i = 0; i < ticketDataArray.size(); i++) {
                fos.write((ticketDataArray.get(i)).getBytes());
            }


        }

    }

}
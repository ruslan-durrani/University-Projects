package com.example.gymanji

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

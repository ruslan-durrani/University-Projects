
from scheduler import Scheduler


class SPN(Scheduler):
    def run(self):
        cur_time = 0
        finish_processes_count = 0
        at_idx = 0
        sorted_processes = sorted(self.processes, key=lambda x: x.at)
        # It runs until the number of finished processes equals the total number of processes.
        while finish_processes_count < self.process_count:
            # Queue the process to arrive at the current time
            for process_idx in range(at_idx, self.process_count):
                process = sorted_processes[process_idx]
                if process.at == cur_time:
                    print("processe arrived - cur_time:", cur_time, " p_id :", process.id)
                    self.ready_queue.append(process)
                elif process.at > cur_time:
                    at_idx = process_idx
                    break

            # history record
            self.record_history(self.ready_queue[:], self.cpus, self.processes)

            # cpu listening to
            for cpu in self.cpus:
                # cpu When the work of
                if cpu.is_finished():
                    print("processe finished - cur_time:", cur_time, " p_id :", cpu.process.id)
                    cpu.process.calculate_finished_process(cur_time)
                    finish_processes_count += 1
                    # Let the CPU rest after work.
                    cpu.set_idle()
                # cpu is resting
                if cpu.is_idle():
                    # If there is more than one process in the queue
                    if self.ready_queue:
                        # Among the processes in the queue, the process with the smallest 
			# BT is selected and set to the cpu.
                        process_num = 0
                        for i in range(1, len(self.ready_queue)):
                            if self.ready_queue[i].bt < self.ready_queue[process_num].bt:
                                process_num = i
                        cpu.set_process(self.ready_queue.pop(process_num))

            # increase current time
            cur_time += 1
            super().work()

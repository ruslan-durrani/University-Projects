package GUI;

import com.Login;

import javax.swing.*;
import java.awt.*;

import static GUI.Frame.adminLoginHomePage;
import static GUI.Frame.mainPagePanel;

public class AdminPageLogin extends JPanel {

    JButton buttonLogin, buttonBack;
    JLabel usernameLabel, passwordLabel;
    JPasswordField passwordField;
    JTextField usernameField;

    public AdminPageLogin() {


        setLayout(null);
        setSize(500,500);
        setBackground(new Color(0xFF6200));
        setVisible(true);

        // Admin Label
        JLabel adminTitle = new JLabel("ADMIN LOGIN");
        adminTitle.setVisible(true);
        adminTitle.setFont(new Font("Monotype Sort",Font.BOLD,16));
        adminTitle.setBounds(190,80,120,30); // 170,150,160,30
        adminTitle.setForeground(Color.WHITE);
        add(adminTitle);

        usernameLabel = new JLabel("USERNAME ");
        add(usernameLabel);
        usernameLabel.setFont(new Font("Monotype Sort",Font.BOLD,12));
        usernameLabel.setForeground(Color.white);
        usernameLabel.setVisible(true);
        usernameField = new JTextField();
        usernameField.setVisible(true);
        add(usernameField);
        usernameLabel.setBounds(90,150,75,30);
        usernameField.setBounds(170,150,160,30);

        // Password Field & Label

        passwordLabel = new JLabel("PASSWORD ");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setVisible(true);
        passwordLabel.setFont(new Font("Monotype Sort",Font.BOLD,12));
        passwordLabel.setBounds(90,190,75,30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setVisible(true);
        add(passwordField);
        passwordField.setBounds(170,190,160,30);



        // Login Button
        buttonLogin = new JButton("Login");
        add(buttonLogin);
        buttonLogin.setVisible(true);
        buttonLogin.setBounds(255,240,75,30);
        buttonLogin.setFocusable(false);
        buttonLogin.setBackground(new Color(252, 69, 31));
        buttonLogin.setForeground(Color.WHITE);
        buttonLogin.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonLogin.setBorderPainted(false);
        // BACK Button

        buttonBack = new JButton("Back");
        add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setBounds(170,240,75,30);
        buttonBack.setFocusable(false);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setBorderPainted(false);



        buttonLogin.addActionListener(e -> {

            Login login = new Login();

            try {

                String username = usernameField.getText();
                String password = String.valueOf(passwordField.getPassword());

                if (password.isEmpty() && username.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Password and Username field is empty!");

                }
                else if (username.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Username field is empty!");
                }

                else if (password.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Password field is empty!");
                }


                else if (login.isAdminUser(username,password)) {

                    JOptionPane.showMessageDialog(this,"Logged In Successfully");

                    setVisible(false);
                    adminLoginHomePage.setVisible(true);

                }
                else {
                    JOptionPane.showMessageDialog(this,"Username Or Password is Incorrect");
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        });


        buttonBack.addActionListener(e-> {
            int exitDialog = JOptionPane.showConfirmDialog(this,"Sure? You want to go back?","Back to Main Menu",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (exitDialog == JOptionPane.YES_OPTION) {
                setVisible(false);
                mainPagePanel.setVisible(true);
            }
        });

    }



}

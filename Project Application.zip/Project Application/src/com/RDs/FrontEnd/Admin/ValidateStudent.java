package com.RDs.FrontEnd.Admin;


import com.RDs.Portal_logic.Student;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.adminHomePage;

public class ValidateStudent extends JPanel {


    JTextField jTextFieldId;
    JButton jButtonBack, jButtonApprove, jButtonDisapprove;
    public static JTable jTableValidateStdDetail;
    JScrollPane jScrollPaneDetail;


    public ValidateStudent() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0,100)));

        jTextFieldId = new JTextField("Enter Registration Number");
        add(jTextFieldId);
        jTextFieldId.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldId.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldId.setMaximumSize(new Dimension(300,45));

        add(Box.createRigidArea(new Dimension(0,20)));

        JPanel jPanelButton = new JPanel();
        add(jPanelButton);
        jPanelButton.setLayout(new BoxLayout(jPanelButton,BoxLayout.X_AXIS));
        jPanelButton.setBackground(new Color(0xFF6200));



        jButtonApprove = new JButton("APPROVE");

        jButtonApprove.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonApprove.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonApprove.setForeground(Color.GRAY);
        jButtonApprove.setMaximumSize(new Dimension(180,45));
        jButtonApprove.setBorderPainted(false);
        jButtonApprove.setBackground(Color.WHITE);
        jButtonApprove.setFocusable(false);

        jPanelButton.add(jButtonApprove);

        jButtonDisapprove = new JButton("DIS-APPROVE");

        jButtonDisapprove.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonDisapprove.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonDisapprove.setForeground(Color.GRAY);
        jButtonDisapprove.setMaximumSize(new Dimension(180,45));
        jButtonDisapprove.setBorderPainted(false);
        jButtonDisapprove.setBackground(Color.WHITE);
        jButtonDisapprove.setFocusable(false);

        jPanelButton.add(jButtonDisapprove);

        jButtonBack = new JButton("BACK");

        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD,14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(180,45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);

        jPanelButton.add(jButtonBack);

        add(Box.createRigidArea(new Dimension(0,20)));

        jTableValidateStdDetail = new JTable();
        jScrollPaneDetail = new JScrollPane();

        jTableValidateStdDetail.getTableHeader().setReorderingAllowed(false);
        // rollnumber, password_, first_name, last_name, departmentName, programName, semester, isRegistered


        jScrollPaneDetail.setViewportView(jTableValidateStdDetail);
        add(jScrollPaneDetail);

        jButtonBack.addActionListener(e -> {
            setVisible(false);
            adminHomePage.setVisible(true);



        });

        jButtonApprove.addActionListener( e-> {
            try {
                Student student = new Student();

                if (!jTextFieldId.getText().isEmpty()) {
                    if(student.verifyStudent(jTextFieldId.getText())) {
                        JOptionPane.showMessageDialog(this,"Student Approved Successfully");
                        jTextFieldId.setText("Enter Registration Number");
                        String[] detailColumn = new String[]{"Roll Number","First Name", "Last Name", "Department", "Program", "Semester"};
                        jTableValidateStdDetail.setModel(new DefaultTableModel(new Student().fillStudentTable(),detailColumn));
                    }
                }
                else {
                    JOptionPane.showMessageDialog(this,"Student Not Approved");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        jButtonDisapprove.addActionListener(e-> {
            String rollNumber = jTextFieldId.getText();
            try {
                Student student = new Student();
                if (!rollNumber.isEmpty() && student.disapproveStd(rollNumber) &&!rollNumber.equals("Enter Registration Number")) {
                    JOptionPane.showMessageDialog(this, "Student Disapproved Successful");
                    jTextFieldId.setText("Enter Registration Number");
                    String[] detailColumn = new String[]{"Roll Number","First Name", "Last Name", "Department", "Program", "Semester"};
                    jTableValidateStdDetail.setModel(new DefaultTableModel(student.fillStudentTable(),detailColumn));
                }
                else JOptionPane.showMessageDialog(this,"Student Not Disapproved");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        jTextFieldId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldId.setText("");
                super.mouseClicked(e);
            }
        });


    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/Admin/validateStudent.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }
}

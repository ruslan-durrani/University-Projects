import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:gymzilla/pages/track.dart';
import 'package:gymzilla/pages/update.dart';
import '../business login/OptionCard.dart';
import 'add.dart';
import 'delete.dart';

class Home extends StatelessWidget {
  Home({Key? key}) : super(key: key);
  var card_options = [
    OptionCard(
      icon: Icons.add,
      title: "Add Gymnast",
      color: Colors.green,
      action: Add(),
    ),
    OptionCard(
      icon: Icons.track_changes_sharp,
      title: "Track & View Gymnast",
      color: Colors.blue,
      action: Track(),
    ),
    OptionCard(
      icon: Icons.update,
      title: "Update Gymnast",
      color: Colors.orange,
      action: Update(),
    ),
    OptionCard(
      icon: Icons.delete,
      title: "Delete Gymnast",
      color: Colors.red,
      action: Delete(),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          color: Colors.black,
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  color: Colors.orange,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.red,
                        foregroundImage: AssetImage(
                          "./assets/images/coach.png",
                        ),
                      ),
                      Spacer(),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 1.5,
                            child: Text(
                              "Welcome Coach 👋🏻😊",
                              style: TextStyle(
                                  fontSize: 20.sp, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(
                            height: 20.h,
                            child: Text(
                              new DateTime.now().day.toString() +
                                  " / " +
                                  new DateTime.now().month.toString() +
                                  " / " +
                                  new DateTime.now().year.toString(),
                              style: TextStyle(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.normal),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      Container(
                        alignment: Alignment.centerLeft,
                        padding: EdgeInsets.all(20.w),
                        child: Text(
                          "Gymnasts Options",
                          style: TextStyle(
                              fontSize: 25.sp, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerLeft,
                        padding: EdgeInsets.only(left: 20.w, right: 20.w),
                        child: Text(
                          "You can view, add, delete and update records of your boys gymnasts",
                          style: TextStyle(
                              fontSize: 12.sp, fontWeight: FontWeight.normal),
                        ),
                      ),
                    ],
                  )),
              Expanded(
                  flex: 7,
                  child: Container(
                    child: CustomScrollView(
                      primary: false,
                      slivers: <Widget>[
                        SliverPadding(
                          padding: EdgeInsets.all(20.w),
                          sliver: SliverGrid.count(
                            crossAxisSpacing: 15,
                            mainAxisSpacing: 15,
                            crossAxisCount: 2,
                            children: <Widget>[
                              ...card_options.map((e) {
                                return InkWell(
                                  onTap: () {
                                    Get.to(e.action);
                                  },
                                  child: Container(
                                    padding: EdgeInsets.all(8.w),
                                    color: e.color,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        CircleAvatar(
                                          radius: 15,
                                          backgroundColor: e.color,
                                          child: Icon(
                                            e.icon,
                                            color: Colors.white,
                                            size: 35,
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(top: 25.h),
                                          child: Text(
                                            e.title,
                                            textAlign: TextAlign.center,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              }),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

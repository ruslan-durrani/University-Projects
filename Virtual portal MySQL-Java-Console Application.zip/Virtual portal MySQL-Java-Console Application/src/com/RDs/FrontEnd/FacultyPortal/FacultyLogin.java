package com.RDs.FrontEnd.FacultyPortal;

import com.RDs.FrontEnd.Faculty;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.*;

public class FacultyLogin extends JPanel {


    JPanel jPanelUsername, jPanelPassword, jPanelButton;
    JLabel jLabelUsername, jLabelPassword;
    JTextField jTextFieldUsername;
    JPasswordField jPasswordFieldPassword;
    JButton jButtonLogin, jButtonBack, jButtonRegistration;

    public FacultyLogin() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000,800);

        add(Box.createRigidArea(new Dimension(0,100)));
//        add(Box.createRigidArea(new Dimension(0,20)));
        jPanelUsername = new JPanel();
        add(jPanelUsername);
        jPanelUsername.setVisible(true);
        jPanelUsername.setLayout(new BoxLayout(jPanelUsername,BoxLayout.X_AXIS));
        jPanelUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPanelUsername.setBackground(new Color(0xFF6200));


        jLabelUsername = new JLabel("ENROLLMENT ID: ");

        jPanelUsername.add(jLabelUsername);
        jLabelUsername.setForeground(Color.WHITE);
        jLabelUsername.setFont(new Font("Monotype Sort",Font.BOLD,14));


        jPanelUsername.add(Box.createRigidArea(new Dimension(5,0)));

        jTextFieldUsername = new JTextField();
        jPanelUsername.add(jTextFieldUsername);
        jTextFieldUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTextFieldUsername.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jTextFieldUsername.setMaximumSize(new Dimension(180,45));

        // PASSWORD PLACE

        add(Box.createRigidArea(new Dimension(0,6)));

        jPanelPassword = new JPanel();
        add(jPanelPassword);
        jPanelPassword.setVisible(true);
        jPanelPassword.setLayout(new BoxLayout(jPanelPassword,BoxLayout.X_AXIS));
        jPanelPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPanelPassword.setBackground(new Color(0xFF6200));

        jPanelPassword.add(Box.createRigidArea(new Dimension(37,0)));
        jLabelPassword = new JLabel("PASSWORD:");

        jPanelPassword.add(jLabelPassword);
        jLabelPassword.setForeground(Color.WHITE);
        jLabelPassword.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jPanelPassword.add(Box.createRigidArea(new Dimension(5,0)));

        jPasswordFieldPassword = new JPasswordField();
        jPanelPassword.add(jPasswordFieldPassword);
        jPasswordFieldPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        jPasswordFieldPassword.setFont(new Font("Monotype Sort", Font.BOLD,13));
        jPasswordFieldPassword.setMaximumSize(new Dimension(180,45));

        add(Box.createRigidArea(new Dimension(0,6)));


        jPanelButton = new JPanel();
        add(jPanelButton);
        jPanelButton.setLayout(new BoxLayout(jPanelButton,BoxLayout.X_AXIS));
        jPanelButton.setBackground(new Color(0xFF6200));

        jButtonLogin = new JButton("LOGIN");
        jPanelButton.add(jButtonLogin);
        jButtonLogin.setBackground(Color.WHITE);
        jButtonLogin.setBorderPainted(false);
        jButtonLogin.setFocusable(false);
        jButtonLogin.setForeground(Color.GRAY);
        jButtonLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonLogin.setMaximumSize(new Dimension(149,45));
        jButtonLogin.setFont(new Font("Monotype Sort",Font.BOLD,14));

        jPanelButton.add(Box.createRigidArea(new Dimension(6,0)));

        add(Box.createRigidArea(new Dimension(0,6)));

        jButtonBack = new JButton("BACK");
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setBorderPainted(false);
        jButtonBack.setFocusable(false);
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setMaximumSize(new Dimension(304,45));
        jButtonBack.setFont(new Font("Monotype Sort",Font.BOLD,14));
        add(jButtonBack);


        jButtonBack.addActionListener(e-> {
            setVisible(false);
            mainPagePanel.setVisible(true);
        });


        jButtonLogin.addActionListener(e-> {
            String facultyId = jTextFieldUsername.getText();
            String password = String.valueOf(jPasswordFieldPassword.getPassword());

            Faculty faculty = null;
            try {
                faculty = new Faculty();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            if (facultyId.isEmpty() || password.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please Fill up all the fields");
            }

            else if (faculty.validate(facultyId,password)) {
                JOptionPane.showMessageDialog(this,"Logged In Successfully");
                facultyHomePage.setVisible(true);
                setVisible(false);

            }
            else {
                JOptionPane.showMessageDialog(this,"Faculty ID or Password is incorrect");
            }
        });

        jPanelUsername.setOpaque(false);
        jPanelPassword.setOpaque(false);
        jPanelButton.setOpaque(false);

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/FacultyPortal/facultyPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image,0,0,null);
    }
}

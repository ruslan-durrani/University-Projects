import 'package:flutter/material.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        iconTheme: IconThemeData(
            color:Colors.white,
        ),
        elevation: 0,
      ),
      body: Form(
        child: ListView(
          children: [
             Align(
               alignment: Alignment.topLeft,
               child: Padding(
                   padding: EdgeInsets.only(
                       top: 32.0, right: 16.0, left: 16.0),
                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       Text(
                         'Ardies Trivia',
                         style: TextStyle(
                             color: Colors.deepOrangeAccent,
                             fontSize: 30.0,
                             fontWeight: FontWeight.bold),
                       ),
                       SizedBox(height: 3,),
                       Text(
                         'Sign In',
                         style: TextStyle(
                             color: Colors.grey,
                             fontSize: 25.0,
                             fontWeight: FontWeight.w300),
                       ),
                     ],
                   )
               ),
             ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 32.0, right: 24.0, left: 24.0),
              child: TextFormField(
                  textAlignVertical: TextAlignVertical.center,
                  textInputAction: TextInputAction.next,
                  style: const TextStyle(fontSize: 18.0),
                  keyboardType: TextInputType.emailAddress,
                  cursorColor: Colors.deepOrangeAccent,
                  decoration: InputDecoration(
                      hintText: "Email Address",
                  ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 32.0, right: 24.0, left: 24.0),
              child: TextFormField(
                  textAlignVertical: TextAlignVertical.center,
                  obscureText: true,
                  style: const TextStyle(fontSize: 18.0),
                  cursorColor: Colors.deepOrangeAccent,
                decoration: InputDecoration(
                  hintText: "Password",
                )
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16, right: 24),
              child: Align(
                alignment: Alignment.centerRight,
                child: GestureDetector(
                  child:  Text(
                    'Forgot password?',
                    style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                        letterSpacing: .8),
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(
                  right: 40.0, left: 40.0, top: 40),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.pushReplacementNamed(context, '/welcome');
                },
                style: ElevatedButton.styleFrom(

                  padding: const EdgeInsets.only(top: 12, bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    side: const BorderSide(
                      color: Colors.deepOrangeAccent,
                    ),
                  ),
                  primary: Colors.deepOrangeAccent,
                ),
                child: const Text(
                  'Log In',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.normal,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(32.0),
              child: Center(
                child: Text(
                  'OR',
                  style: TextStyle(
                      color: Colors.black
                ),
              ),
            ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  right: 40.0, left: 40.0, bottom: 20),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.pushReplacementNamed(context, '/signup');
                },
                child:  Text(
                  'Sign up',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.normal,
                      color: Colors.white),
                ),
                // icon: Image.asset(
                //   'img/facebook_logo.png',
                //   color: Colors.white,
                //   height: 24,
                //   width: 24,
                // ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  primary: Colors.blueAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    side: const BorderSide(
                      color: Colors.blueAccent,
                    ),
                  ),
                ),
              ),
            ),
      ]
    ),
      )
    );
  }
}

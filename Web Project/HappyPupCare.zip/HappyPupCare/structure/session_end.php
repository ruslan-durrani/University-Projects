<?php
// Clear session variables
session_unset();

// Close the session
session_destroy();
?>

package com;

import java.io.FileNotFoundException;

public class Login {
    private String username;
    private String password;

    public Login() {

    }

    public Login(String username, String password){

        this.username = username;
        this.password = password;

    }

    private boolean isValidUser() throws FileNotFoundException {
        return Registration.isRegisteredUser(username, password);
    }

    public boolean isAdminUser(String username, String password) throws Exception {
        return Registration.isAdminRegistered(username, password);
    }

    public boolean loginAthlete(String username, String password) throws FileNotFoundException {
        this.username = username;
        this.password= password;

        return isValidUser();
    }



}
package GUI;

import com.Password;
import com.Registration;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import static GUI.Frame.athleticPageLogin;
import static GUI.Frame.mainPagePanel;

public class AthleteRegistration extends JPanel {

    JLabel buttonSignUp;
    JTextField textFieldUsername, textFieldFirstName, textFieldLastName;
    JPasswordField passwordField;
    JButton buttonBack, buttonSubmit, buttonClear;
    JSpinner departmentCity, stadiumName;
    Label passwordContain, passwordLowercase, passwordCapital, passwordNumber, password8Char, passwordNoSpaces;

    public AthleteRegistration() {
        setVisible(true);
        setBackground(new Color(0xFF6200));
        setSize(500,500);
        setLayout(null);

        buttonSignUp = new JLabel("Sign Up");
        buttonSignUp.setVisible(true);
        buttonSignUp.setForeground(Color.WHITE);
        buttonSignUp.setFont(new Font("Microsoft YaHei UI",Font.BOLD,30));
        buttonSignUp.setBounds(12,13,118,39);
        add(buttonSignUp);

        textFieldFirstName = new JTextField("First Name");
        add(textFieldFirstName);
        textFieldFirstName.setVisible(true);
        textFieldFirstName.setBounds(12,70,229,40);
        textFieldFirstName.setFont(new Font("Monotype Sort",Font.PLAIN,12));

        textFieldFirstName.setBorder(BorderFactory. createLineBorder (new Color (220,220,220), 2));

        textFieldLastName = new JTextField("Last Name");
        add(textFieldLastName);
        textFieldLastName.setVisible(true);
        textFieldLastName.setBounds(245,70,229,40);
        textFieldLastName.setFont(new Font("Monotype Sort",Font.PLAIN,12));
        textFieldLastName.setBorder(BorderFactory. createLineBorder (new Color (220,220,220), 2));

        textFieldUsername = new JTextField("Username or email address");
        textFieldUsername.setVisible(true);
        textFieldUsername.setFont(new Font("Monotype Sort",Font.PLAIN,12));
        textFieldUsername.setBorder(BorderFactory.createLineBorder(new Color(220,220,220),2));
        textFieldUsername.setBounds(12,123,462,40);
        add(textFieldUsername);


        passwordField = new JPasswordField("Password");
        add(passwordField);
        passwordField.setVisible(true);
        passwordField.setBounds(12,173,462,40);
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(220,220,220),2));


        String[] stadiumArray = {"Select Stadium","Islamabad", "KPK", "Karachi", "Baluchistan"};
        String[] departmentArray = {"Select Department","Cricket", "Football","Tennis","Volley Ball","Table Tennis"};
        departmentCity = new JSpinner(new SpinnerListModel(departmentArray));
        departmentCity.setVisible(true);
        departmentCity.setBounds(12,226,229,40);
        add(departmentCity);

        stadiumName = new JSpinner(new SpinnerListModel(stadiumArray));
        add(stadiumName);
        stadiumName.setVisible(true);
        stadiumName.setBounds(245,226,229,40);

        buttonBack = new JButton("Back");
        add(buttonBack);
        buttonBack.setBounds(12,279,229,40);
        buttonBack.setVisible(true);
        buttonBack.setFocusable(false);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setBorderPainted(false);

        buttonSubmit = new JButton("Submit");
        buttonSubmit.setBounds(245,279,229,40);
        buttonSubmit.setVisible(true);
        buttonSubmit.setFocusable(false);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setForeground(Color.WHITE);
        buttonSubmit.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonSubmit.setBorderPainted(false);
        add(buttonSubmit);


        textFieldFirstName.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                textFieldFirstName.setText("");
            }
        }
        );

        textFieldLastName.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                textFieldLastName.setText("");
            }
        });

        textFieldUsername.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                textFieldUsername.setText("");
            }
        });

        passwordField.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                passwordField.setText("");
            }
        });

        buttonClear = new JButton("Clear");
        buttonClear.setBounds(120,332,229,40);
        buttonClear.setVisible(true);
        buttonClear.setFocusable(false);
        buttonClear.setBackground(new Color(252, 69, 31));
        buttonClear.setForeground(Color.WHITE);
        buttonClear.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonClear.setBorderPainted(false);
        add(buttonClear);

        buttonBack.addActionListener(e-> {
            setVisible(false);
            athleticPageLogin.setVisible(true);


        });

        buttonSubmit.addActionListener(e-> {
            String firstName = textFieldFirstName.getText();
            String lastName = textFieldLastName.getText();
            String fullName = firstName + " " + lastName;

            String username = textFieldUsername.getText();
            String password = String.valueOf(passwordField.getPassword());
            String department = (String) departmentCity.getValue();
            String stadium = (String) stadiumName.getValue();

            if ((firstName.isEmpty() || firstName.equalsIgnoreCase("first name")) || (lastName.isEmpty() || lastName.equalsIgnoreCase("last name") ||
                    (username.isEmpty() || username.equalsIgnoreCase("Username or email address")) || (password.isEmpty() || password.equalsIgnoreCase("password")))){
                JOptionPane.showMessageDialog(this,"Please fill up all the fields");
            }

            else if (department.equalsIgnoreCase("Select Department") && (stadium.equalsIgnoreCase("Select stadium"))){
                JOptionPane.showMessageDialog(this,"Please select department and stadium");
            }
            else if (department.equalsIgnoreCase("Select Department")){
                JOptionPane.showMessageDialog(this,"Please select department");
            }
            else if (stadium.equalsIgnoreCase("Select Stadium")){
                JOptionPane.showMessageDialog(this,"Please select stadium");
            }
            else {
                Password validPassword = new Password();
                try {
//                    System.out.println(fullName + "\n" + username + "\n" + password + "\n" + department + "\n" + stadium);
                    if (Registration.isRegisteredUser(username,password)){
                        JOptionPane.showMessageDialog(this,"Username already exists");
                    }
                    else if (!(validPassword.isValidPassword(password))){
                        JOptionPane.showMessageDialog(this, """
                                Password is not valid. Password must contain the following:\\n" +
                                                "A lowercase letter\\n" +
                                                "A capital(uppercase) letter\\n" +
                                                "A number\\n" +
                                                "Minimum 8 characters" +
                                                "No Spaces""");
                    }
                    else {
                        new Registration(fullName,username,password,department,stadium);
                        JOptionPane.showMessageDialog(this,"Athlete registered successfully. You can login now!","Login",JOptionPane.INFORMATION_MESSAGE);
                        setVisible(false);
                        textFieldFirstName.setText("First Name");
                        textFieldUsername.setText("Username");
                        textFieldLastName.setText("Last Name");
                        passwordField.setText("Password");
                        departmentCity.setValue("Select Department");
                        stadiumName.setValue("Select Stadium");
                        athleticPageLogin.setVisible(true);
                    }


                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }





        });













    }
}

package GUI;

import com.Admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import static GUI.Frame.adminLoginHomePage;

public class UpdateTicket extends JPanel {

//    admin.updateTicketData("2","Cricket","Islamabad","Abu bakr","Tuesday","10:00 PM");
    JTextField jTextFieldId, jTextFieldTitle;
    JSpinner jSpinnerStadium, jSpinnerDepartment, jSpinnerDay,jSpinnerTime;
    JLabel ticketName;
    JButton buttonSubmit, buttonBack;
    public UpdateTicket() {
        setVisible(true);
        setSize(500,500);
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        setBackground(new Color(0xFF6200));

        ticketName = new JLabel("Update Ticket");
        ticketName.setVisible(true);
        add(ticketName);
        ticketName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        ticketName.setForeground(Color.WHITE);
        ticketName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));

        String[] stadiumArray = {"Select Stadium","Islamabad", "KPK", "Karachi", "Baluchistan"};
        String[] departmentArray = {"Select Department","Cricket", "Football","Tennis","Volley Ball","Table Tennis"};
        JPanel panel1 = new JPanel();

        jSpinnerDepartment = new JSpinner(new SpinnerListModel(departmentArray));
        jSpinnerDepartment.setVisible(true);
        jSpinnerDepartment.setMinimumSize(new Dimension(180,40));
        jSpinnerDepartment.setMaximumSize(new Dimension(180,40));

        jSpinnerStadium = new JSpinner(new SpinnerListModel(stadiumArray));
        jSpinnerStadium.setVisible(true);
        jSpinnerStadium.setMinimumSize(new Dimension(180,40));
        jSpinnerStadium.setMaximumSize(new Dimension(180,40));

        panel1.add(jSpinnerDepartment);
        panel1.add(Box.createRigidArea(new Dimension(10,0)));
        panel1.add(jSpinnerStadium);
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
        panel1.setBackground(new Color(0xFF6200));
        add(panel1);
        panel1.setSize(180,40);
        panel1.setVisible(true);

        String[] day = {"Select Day","Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        add(Box.createRigidArea(new Dimension(0,10)));
        JPanel panel2 = new JPanel();
        add(panel2);
        panel2.setBackground(new Color(0xFF6200));
        panel2.setLayout(new BoxLayout(panel2,BoxLayout.X_AXIS));
        panel2.setVisible(true);

        jSpinnerDay = new JSpinner(new SpinnerListModel(day));
        jSpinnerDay.setVisible(true);
        jSpinnerDay.setMinimumSize(new Dimension(180,40));
        jSpinnerDay.setMaximumSize(new Dimension(180,40));

        panel2.add(jSpinnerDay);
        panel2.add(Box.createRigidArea(new Dimension(10,0)));

        String[] time = {"Select Time","1:00", "2:00", "3:00", "4:00", "5:00", "6:00","7:00","8:00","9:00","10::00",
                "11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00", "23:00","23:59"};

        jSpinnerTime = new JSpinner(new SpinnerListModel(time));
        jSpinnerTime.setVisible(true);
        jSpinnerTime.setMinimumSize(new Dimension(180,40));
        jSpinnerTime.setMaximumSize(new Dimension(180,40));
        panel2.add(jSpinnerTime);
        add(Box.createRigidArea(new Dimension(0,10)));

        JPanel panel3 = new JPanel();
        panel3.setLayout(new BoxLayout(panel3, BoxLayout.X_AXIS));
        panel3.setBackground(new Color(0xFF6200));
        jTextFieldTitle = new JTextField("Enter Title");
        jTextFieldTitle.setVisible(true);
        panel3.add(jTextFieldTitle);
        jTextFieldTitle.setMinimumSize(new Dimension(180,40));
        jTextFieldTitle.setMaximumSize(new Dimension(180,40));
        add(panel3);
        panel3.add(Box.createRigidArea(new Dimension(10,0)));

        jTextFieldId = new JTextField("Enter Id");
        jTextFieldId.setVisible(true);
        panel3.add(jTextFieldId);
        jTextFieldId.setMinimumSize(new Dimension(180,40));
        jTextFieldId.setMaximumSize(new Dimension(180,40));
        add(Box.createRigidArea(new Dimension(0,10)));


        jTextFieldId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldId.setText("");
            }
        });

        jTextFieldTitle.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldTitle.setText("");
            }
        });


        JPanel buttonPanel = new JPanel();
        add(buttonPanel);
        buttonPanel.setVisible(true);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(0xFF6200));

        buttonBack = new JButton("Back");
        buttonPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(90, 40));
        buttonBack.setMinimumSize(new Dimension(90, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
        buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));

        buttonSubmit = new JButton("Submit");
        buttonPanel.add(buttonSubmit);
        buttonSubmit.setVisible(true);
        buttonSubmit.setFont(new Font("Monotype Sott", Font.BOLD, 12));
        buttonSubmit.setMaximumSize(new Dimension(90, 40));
        buttonSubmit.setMinimumSize(new Dimension(90, 40));
        buttonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSubmit.setForeground(Color.white);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setBorderPainted(false);
        buttonSubmit.setFocusable(false);


        buttonSubmit.addActionListener(e-> {
//            "2","Cricket","Islamabad","Abu bakr","Tuesday","10:00 PM"
            String id = jTextFieldId.getText();
            String stadium = String.valueOf(jSpinnerStadium.getValue());
            String department = String.valueOf(jSpinnerDepartment.getValue());
            String title = jTextFieldTitle.getText();
            String dayS = String.valueOf(jSpinnerDay.getValue());
            String times = String.valueOf(jSpinnerTime.getValue());

            if (id.isEmpty() || id.equalsIgnoreCase("Enter id") || stadium.isEmpty() || stadium.equalsIgnoreCase("Enter Stadium") ||
                    department.isEmpty() || department.equalsIgnoreCase("Enter Department") || title.equalsIgnoreCase("Enter Title") ||
            title.isEmpty() || dayS.isEmpty() || dayS.equalsIgnoreCase("Enter Day") || times.isEmpty() || times.equalsIgnoreCase("Enter Time")) {
                JOptionPane.showMessageDialog(this,"Please fill all fields");
            }
            else {
                Admin admin = null;
                try {
                    admin = new Admin();
                    if (admin.showTicketData(stadium,department) && admin.getTicketData1d().size() <= Integer.parseInt(id)){
                        admin.updateTicketData(id,department,stadium,title,dayS,times);
                        JOptionPane.showMessageDialog(this,"Data Updated Successfully");
                    }
                    else {
                        JOptionPane.showMessageDialog(this,"No Record Found");
                    }
                    System.out.println(admin.getTicketData1d().size());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }


        });

        buttonBack.addActionListener(e->{
            setVisible(false);
            adminLoginHomePage.setVisible(true);
            jTextFieldTitle.setText("Enter Title");
            jTextFieldId.setText("Enter Id");
        });

    }
}

import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

import '../Models/dyslexia.dart';
import 'Mesages.dart';
import 'SightSaver.dart';

class Recents extends StatelessWidget {
  const Recents({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Recents",
          style: TextStyle(
              fontWeight: Dyslexia.on ? FontWeight.bold : FontWeight.normal,
              fontSize: 18),
        ),
        backgroundColor: Colors.deepOrange,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: 2, // Number of columns in the grid
              crossAxisSpacing: 16.0, // Spacing between columns
              mainAxisSpacing: 16.0, // Spacing between rows
              padding: EdgeInsets.all(16.0), // Padding around the grid

              children: [
                ...List.generate(20, (index) {
                  return InkWell(
                    onTap: () {},
                    child: Container(
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: Colors.red, // Border color
                          width: 2.0, // Border width
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0,
                                3), // Offset in the horizontal and vertical direction
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "This is title description",
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: Dyslexia.on
                                    ? FontWeight.bold
                                    : FontWeight.w400,
                                color: Colors.black),
                          ),
                          Text(
                            "This is sub title and its can be lengthy, see more",
                            style: TextStyle(
                                fontSize: 10,
                                fontWeight: Dyslexia.on
                                    ? FontWeight.bold
                                    : FontWeight.w400,
                                color: Colors.black),
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.navigate_next_outlined,
                                color: Colors.deepOrange,
                                size: 20,
                              ),
                              Text(
                                "More",
                                style: TextStyle(
                                    color: Colors.deepOrange,
                                    fontWeight: Dyslexia.on
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                    fontSize: 10),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                })
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: SpeedDial(
        backgroundColor: Colors.purpleAccent,
        foregroundColor: Colors.white,
        animatedIcon: AnimatedIcons.menu_close,
        children: [
          SpeedDialChild(
            child: Icon(Icons.view_list_outlined),
            label: 'Screen Reader',
            onTap: () {
              // Handle Email icon press
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.chat),
            label: 'Chat',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Messages(),
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.share_arrival_time_outlined),
            label: 'Read Aloud',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
          SpeedDialChild(
            child: Icon(Icons.insights),
            label: 'Sight Saver',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SightSaver();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
    ;
  }
}

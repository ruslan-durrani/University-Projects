package GUI;

import com.Admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import static GUI.Frame.adminLoginHomePage;

public class DeleteTicket extends JPanel {

    JLabel ticketName;
    JSpinner jSpinnerDepartment, jSpinnerStadium;
    JButton buttonSubmit, buttonBack;
    JTextField jTextFieldId;

    public DeleteTicket() {
        setVisible(true);
        setSize(500,500);
        setBackground(new Color(0xFF86200));
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

        ticketName = new JLabel("Delete Ticket");
        ticketName.setVisible(true);
        add(ticketName);
        ticketName.setFont(new Font("Monotype Sort", Font.BOLD, 32));
        ticketName.setForeground(Color.WHITE);
        ticketName.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 12)));


        String[] stadiumArray = {"Select Stadium","Islamabad", "KPK", "Karachi", "Baluchistan"};
        String[] departmentArray = {"Select Department","Cricket", "Football","Tennis","Volley Ball","Table Tennis"};
        JPanel panel1 = new JPanel();

        jSpinnerDepartment = new JSpinner(new SpinnerListModel(departmentArray));
        jSpinnerDepartment.setVisible(true);
        jSpinnerDepartment.setMinimumSize(new Dimension(180,40));
        jSpinnerDepartment.setMaximumSize(new Dimension(180,40));

        jSpinnerStadium = new JSpinner(new SpinnerListModel(stadiumArray));
        jSpinnerStadium.setVisible(true);
        jSpinnerStadium.setMinimumSize(new Dimension(180,40));
        jSpinnerStadium.setMaximumSize(new Dimension(180,40));

        panel1.add(jSpinnerDepartment);
        panel1.add(Box.createRigidArea(new Dimension(10,0)));
        panel1.add(jSpinnerStadium);
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
        panel1.setBackground(new Color(0xFF6200));
        add(panel1);
        panel1.setSize(180,40);
        panel1.setVisible(true);
        add(Box.createRigidArea(new Dimension(0,10)));

        jTextFieldId = new JTextField("Enter ID");
        jTextFieldId.setVisible(true);
        add(jTextFieldId);
        jTextFieldId.setMinimumSize(new Dimension(180,40));
        jTextFieldId.setMaximumSize(new Dimension(180,40));
        jTextFieldId.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0,10)));

        jTextFieldId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldId.setText("");
            }
        });

        JPanel buttonPanel = new JPanel();
        add(buttonPanel);
        buttonPanel.setVisible(true);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(0xFF6200));

        buttonBack = new JButton("Back");
        buttonPanel.add(buttonBack);
        buttonBack.setVisible(true);
        buttonBack.setFont(new Font("Monotype Sort", Font.BOLD, 12));
        buttonBack.setMaximumSize(new Dimension(90, 40));
        buttonBack.setMinimumSize(new Dimension(90, 40));
        buttonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonBack.setForeground(Color.white);
        buttonBack.setBackground(new Color(252, 69, 31));
        buttonBack.setBorderPainted(false);
        buttonBack.setFocusable(false);
        buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));

        buttonSubmit = new JButton("Submit");
        buttonPanel.add(buttonSubmit);
        buttonSubmit.setVisible(true);
        buttonSubmit.setFont(new Font("Monotype Sott", Font.BOLD, 12));
        buttonSubmit.setMaximumSize(new Dimension(90, 40));
        buttonSubmit.setMinimumSize(new Dimension(90, 40));
        buttonSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonSubmit.setForeground(Color.white);
        buttonSubmit.setBackground(new Color(252, 69, 31));
        buttonSubmit.setBorderPainted(false);
        buttonSubmit.setFocusable(false);

    buttonBack.addActionListener(e-> {
        setVisible(false);
        adminLoginHomePage.setVisible(true);
        jTextFieldId.setText("Enter ID");
    });


    buttonSubmit.addActionListener(e-> {
        String department = String.valueOf(jSpinnerDepartment.getValue());
        String stadium = String.valueOf(jSpinnerStadium.getValue());
        String id = jTextFieldId.getText();

        try {
            Admin admin = new Admin();
            admin.showTicketData(stadium,department);
            if (admin.getTicketData1d().size() >= Integer.parseInt(id)) {
                admin.deleteTicketData(id,stadium,department);
                JOptionPane.showMessageDialog(this,"Ticket deleted successfully.");
                jTextFieldId.setText("Enter ID");
            }
            else {
                JOptionPane.showMessageDialog(this,"Ticket was not deleted.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }



    });

    }


}

import 'package:flutter/material.dart';
import 'package:ardies_trivia_application/Constants/constants.dart';

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: Form(
          child: ListView(
              children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                      padding: EdgeInsets.only(
                          top: 32.0, right: 16.0, left: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Create New Account',
                            style: TextStyle(
                                color: Colors.deepOrangeAccent,
                                fontSize: 30.0,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 3,),
                          Text(
                            'Sign Up',
                            style: TextStyle(
                                color: Colors.grey,
                                fontSize: 25.0,
                                fontWeight: FontWeight.w300),
                          ),
                        ],
                      )
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      top: 32.0, right: 24.0, left: 24.0),
                  child: TextFormField(
                    textAlignVertical: TextAlignVertical.center,
                    textInputAction: TextInputAction.next,
                    style: const TextStyle(fontSize: 18.0),
                    keyboardType: TextInputType.emailAddress,
                    cursorColor: Colors.deepOrangeAccent,
                    decoration: InputDecoration(
                      hintText: "Full Name",
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      top: 32.0, right: 24.0, left: 24.0),
                  child: TextFormField(
                    textAlignVertical: TextAlignVertical.center,
                    textInputAction: TextInputAction.next,
                    style: const TextStyle(fontSize: 18.0),
                    keyboardType: TextInputType.emailAddress,
                    cursorColor: Colors.deepOrangeAccent,
                    decoration: InputDecoration(
                      hintText: "Your Email Address",
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      top: 32.0, right: 24.0, left: 24.0),
                  child: TextFormField(
                      textAlignVertical: TextAlignVertical.center,
                      obscureText: true,
                      style: const TextStyle(fontSize: 18.0),
                      cursorColor: Colors.deepOrangeAccent,
                      decoration: InputDecoration(
                        hintText: "Create Password",
                      )
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16, right: 24),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      child:  Text(
                        'Terms and conditions',
                        style: TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                            fontSize: 15,
                            letterSpacing: .8),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(
                      right: 40.0, left: 40.0, top: 40),
                  child: ElevatedButton(
                    onPressed: (){
                      Navigator.pushReplacementNamed(context, '/welcome');
                    },
                    style: ElevatedButton.styleFrom(

                      padding: const EdgeInsets.only(top: 12, bottom: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0),
                        side: const BorderSide(
                          color: Colors.deepOrangeAccent,
                        ),
                      ),
                      primary: Colors.deepOrangeAccent,
                    ),
                    child: const Text(
                      'Sign Up',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.normal,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                // Padding(
                //   padding: const EdgeInsets.all(32.0),
                //   child: Center(
                //     child: Text(
                //       'OR',
                //       style: TextStyle(
                //           color: Colors.black
                //       ),
                //     ),
                //   ),
                // ),
                // Padding(
                //   padding: const EdgeInsets.only(
                //       right: 40.0, left: 40.0, bottom: 20),
                //   child: ElevatedButton(
                //     onPressed: (){
                //       Navigator.pushReplacementNamed(context, '/signup');
                //     },
                //     child:  Text(
                //       'Sign up with Facebook',
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           fontSize: 20,
                //           fontWeight: FontWeight.normal,
                //           color: Colors.white),
                //     ),
                //
                //     style: ElevatedButton.styleFrom(
                //       padding: const EdgeInsets.symmetric(vertical: 12),
                //       primary: Colors.blueAccent,
                //       shape: RoundedRectangleBorder(
                //         borderRadius: BorderRadius.circular(25.0),
                //         side: const BorderSide(
                //           color: Colors.blueAccent,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
              ]
          ),
        )
    );
  }
}

/**
 *
 */
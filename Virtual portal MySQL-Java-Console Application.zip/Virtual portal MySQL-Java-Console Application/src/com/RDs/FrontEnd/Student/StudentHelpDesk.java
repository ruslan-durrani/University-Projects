package com.RDs.FrontEnd.Student;

import com.RDs.FrontEnd.StudentBackend;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import static com.RDs.FrontEnd.SplashScreen.studentHomePage;

public class StudentHelpDesk extends JPanel {

    JLabel jLabelMessage;
    JButton jButtonBack, jButtonPost;
    JTextField jTextFieldReply;


    StudentBackend studentBackend;

    {
        try {
            studentBackend = new StudentBackend();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public StudentHelpDesk() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setSize(1000, 800);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(Box.createRigidArea(new Dimension(0, 100)));

        jLabelMessage = new JLabel(studentBackend.studentHelpDesk());
        add(jLabelMessage);
        jLabelMessage.setForeground(Color.BLACK);
        jLabelMessage.setFont(new Font("Monotype Sort",Font.BOLD,12));

        JScrollPane scrollPaneNoticeboard = new JScrollPane(jLabelMessage,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPaneNoticeboard.setMaximumSize(new Dimension(1000, 300));
//        scrollPaneNoticeboard.setBackground(new Color(0, 0, 0, 65));

        add(scrollPaneNoticeboard);
        add(Box.createRigidArea(new Dimension(0, 10)));

        jTextFieldReply = new JTextField();
        add(jTextFieldReply);
        jTextFieldReply.setMaximumSize(new Dimension(1000,60));
        jTextFieldReply.setText("Enter Message: ");

        jTextFieldReply.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jTextFieldReply.setText("");
                super.mouseClicked(e);
            }
        });

        add(Box.createRigidArea(new Dimension(0, 10)));

        JPanel jPanelButton = new JPanel();
        jPanelButton.setLayout(new BoxLayout(jPanelButton, BoxLayout.X_AXIS));
        add(jPanelButton);

        jButtonPost = new JButton("POST");
        jButtonPost.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonPost.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonPost.setForeground(Color.GRAY);
        jButtonPost.setMaximumSize(new Dimension(180, 45));
        jButtonPost.setBorderPainted(false);
        jButtonPost.setBackground(Color.WHITE);
        jButtonPost.setFocusable(false);
        jPanelButton.add(jButtonPost);

        jButtonBack = new JButton("BACK");
        jButtonBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        jButtonBack.setFont(new Font("Monotype Sort", Font.BOLD, 14));
        jButtonBack.setForeground(Color.GRAY);
        jButtonBack.setMaximumSize(new Dimension(180, 45));
        jButtonBack.setBorderPainted(false);
        jButtonBack.setBackground(Color.WHITE);
        jButtonBack.setFocusable(false);

        jPanelButton.add(jButtonBack);

        add(Box.createRigidArea(new Dimension(0, 10)));

        jButtonBack.addActionListener(e-> {
            setVisible(false);
            studentHomePage.setVisible(true);
        });

        jButtonPost.addActionListener(e-> {

            if(studentBackend.postStudentMessage(jTextFieldReply.getText())){
                JOptionPane.showMessageDialog(this,"Message Posted Successfully");
                try {
                    jLabelMessage.setText(new StudentBackend().studentHelpDesk());
                    jTextFieldReply.setText("Enter Message: ");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

            }
            else JOptionPane.showMessageDialog(this,"Message Not Posted Successfully");
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = null;
        try {
            File input = new File("src/com/RDs/FrontEnd/FacultyPortal/facultyPanel.png");
            image = ImageIO.read(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(image, 0, 0, null);
    }

}
